import React, { useState } from 'react';
import {
  TrendingUp,
  Calendar,
  IndianRupee,
  ArrowDownLeft,
  ArrowUpRight,
  PieChart,
  DollarSign,
  Download,
  Fuel,
  Receipt,
  Scale,
} from 'lucide-react';
import {
  MachineSaleRecord,
  Voucher,
  CustomerLedgerEntry,
  Shift,
} from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';

interface DayBookAndPnLProps {
  salesRecords: MachineSaleRecord[];
  vouchers: Voucher[];
  customerLedger: CustomerLedgerEntry[];
  shifts: Shift[];
}

export const DayBookAndPnL: React.FC<DayBookAndPnLProps> = ({
  salesRecords,
  vouchers,
  customerLedger,
  shifts,
}) => {
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [viewMode, setViewMode] = useState<'daybook' | 'pnl'>('daybook');

  // Filter records for selected date
  const daySales = salesRecords.filter((s) => s.date === selectedDate);
  const dayVouchers = vouchers.filter((v) => v.date === selectedDate);
  const dayCustomerPayments = customerLedger.filter(
    (l) => l.date === selectedDate && l.type === 'PAYMENT_RECEIVED'
  );
  const dayShift = shifts.find((s) => s.date === selectedDate) || {
    openingCash: 15000,
  };

  // --- DAY BOOK (CASH IN & CASH OUT) CALCULATIONS ---
  // Cash Inflows:
  const openingCashFloat = dayShift.openingCash || 15000;
  const cashFuelSales = daySales.reduce((sum, s) => sum + (s.cashAmount || 0), 0);
  const creditRecoveriesCash = dayCustomerPayments
    .filter((p) => p.paymentMode === 'CASH' || !p.paymentMode)
    .reduce((sum, p) => sum + (p.amount || 0), 0);
  const totalCashIn = openingCashFloat + cashFuelSales + creditRecoveriesCash;

  // Cash Outflows:
  const dayExpenses = dayVouchers
    .filter((v) => v.type === 'EXPENSE' || v.type === 'SALARY' || v.type === 'OTHER')
    .reduce((sum, v) => sum + (v.amount || 0), 0);
  const dayBankDeposits = dayVouchers
    .filter((v) => v.type === 'BANK_DEPOSIT')
    .reduce((sum, v) => sum + (v.amount || 0), 0);
  const totalCashOut = dayExpenses + dayBankDeposits;

  // Net Cash Balance in Hand
  const netClosingCashInHand = totalCashIn - totalCashOut;

  // Digital Inflows (Non-Cash)
  const upiSales = daySales.reduce((sum, s) => sum + (s.upiAmount || 0), 0);
  const posSales = daySales.reduce((sum, s) => sum + (s.posAmount || 0), 0);
  const totalDigitalInflow = upiSales + posSales;

  // Credit Dispatched (Udhaar Sales)
  const udhaarGiven = daySales.reduce((sum, s) => sum + (s.creditAmount || 0), 0);

  // --- PROFIT & LOSS (P&L) ESTIMATIONS ---
  // Fuel Margins (Standard OMC Dealer Commission):
  // Approx ~₹3.65 / L for Petrol (MS) and ~₹2.45 / L for Diesel (HSD)
  const totalPetrolLitres = daySales.reduce((sum, s) => sum + (s.petrolLitres || 0), 0);
  const totalDieselLitres = daySales.reduce((sum, s) => sum + (s.dieselLitres || 0), 0);
  const totalLubeSales = daySales.reduce((sum, s) => sum + (s.lubeAmount || 0), 0);

  const petrolGrossCommission = totalPetrolLitres * 3.65;
  const dieselGrossCommission = totalDieselLitres * 2.45;
  const lubeEstimatedMargin = totalLubeSales * 0.22; // ~22% margin on engine oils

  const totalGrossProfit = petrolGrossCommission + dieselGrossCommission + lubeEstimatedMargin;
  const netOperatingProfit = totalGrossProfit - dayExpenses;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner & Date Navigation */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <TrendingUp className="w-5 h-5" />
            </span>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                ACCOUNTING & FINANCIAL STATEMENTS
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Day Book (Roznamcha) & Profit / Loss
              </h2>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Reconcile daily cash in/out, bank remittances, dealer fuel commissions, and net operating profit.
          </p>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {/* View Toggle */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setViewMode('daybook')}
              className={`px-3 py-1.5 rounded-lg font-bold transition ${
                viewMode === 'daybook'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Day Book (Roznamcha)
            </button>
            <button
              type="button"
              onClick={() => setViewMode('pnl')}
              className={`px-3 py-1.5 rounded-lg font-bold transition ${
                viewMode === 'pnl'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              P&L Statement
            </button>
          </div>

          {/* Date Picker */}
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* VIEW 1: DAY BOOK (ROZNAMCHA) */}
      {viewMode === 'daybook' && (
        <div className="space-y-6">
          {/* Key Day Book Balance Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Opening Cash Float</span>
              <p className="text-xl font-mono font-bold text-slate-200 mt-1">
                ₹{openingCashFloat.toLocaleString()}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/30">
              <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Total Cash Inflow</span>
              <p className="text-xl font-mono font-black text-emerald-400 mt-1">
                ₹{totalCashIn.toLocaleString()}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-rose-500/30">
              <span className="text-[10px] font-mono text-rose-400 uppercase font-bold">Total Cash Outflow</span>
              <p className="text-xl font-mono font-black text-rose-400 mt-1">
                ₹{totalCashOut.toLocaleString()}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/40">
              <span className="text-[10px] font-mono text-amber-300 uppercase font-bold">Closing Cash In Hand</span>
              <p className="text-2xl font-mono font-black text-amber-400 mt-1">
                ₹{netClosingCashInHand.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Two-Column Roznamcha Ledger: Jama (Inflow) vs Naam (Outflow) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* CASH INFLOWS (आवक / जमा) */}
            <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400">
                    <ArrowDownLeft className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base">Cash Receipts / Inflow (जमा)</h3>
                    <p className="text-[11px] text-slate-400">Cash fuel sales & credit recoveries</p>
                  </div>
                </div>
                <span className="text-sm font-mono font-bold text-emerald-400">
                  ₹{totalCashIn.toLocaleString()}
                </span>
              </div>

              <div className="space-y-2.5 text-xs font-mono">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center">
                  <div>
                    <p className="font-bold text-white">Opening Cash Float</p>
                    <span className="text-[10px] text-slate-500">Drawer float at shift start</span>
                  </div>
                  <span className="font-bold text-slate-200">₹{openingCashFloat.toLocaleString()}</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center">
                  <div>
                    <p className="font-bold text-emerald-400">Dispenser Cash Fuel Sales</p>
                    <span className="text-[10px] text-slate-500">{daySales.length} machine sale bills</span>
                  </div>
                  <span className="font-bold text-emerald-400">₹{cashFuelSales.toLocaleString()}</span>
                </div>

                {dayCustomerPayments.map((p, idx) => (
                  <div
                    key={p.id || idx}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center"
                  >
                    <div>
                      <p className="font-bold text-white">Khata Recovery: {p.customerName}</p>
                      <span className="text-[10px] text-slate-500">Payment received via {p.paymentMode || 'Cash'}</span>
                    </div>
                    <span className="font-bold text-emerald-400">+₹{p.amount.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CASH OUTFLOWS (जावक / नाम) */}
            <div className="bg-slate-900 border border-rose-500/30 rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-rose-500/15 text-rose-400">
                    <ArrowUpRight className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base">Cash Payments / Outflow (नाम)</h3>
                    <p className="text-[11px] text-slate-400">Expenses, bank deposits & advances</p>
                  </div>
                </div>
                <span className="text-sm font-mono font-bold text-rose-400">
                  ₹{totalCashOut.toLocaleString()}
                </span>
              </div>

              <div className="space-y-2.5 text-xs font-mono">
                {dayVouchers.map((v) => (
                  <div
                    key={v.id}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center"
                  >
                    <div>
                      <p className="font-bold text-white">
                        {v.title}{' '}
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                          {v.type}
                        </span>
                      </p>
                      <span className="text-[10px] text-slate-500">
                        Paid to: {v.paidTo || '-'} • Auth: {v.authorizedBy}
                      </span>
                    </div>
                    <span className="font-bold text-rose-400">-₹{v.amount.toLocaleString()}</span>
                  </div>
                ))}

                {dayVouchers.length === 0 && (
                  <p className="text-xs text-slate-500 italic py-8 text-center font-sans">
                    No expense or bank deposit vouchers for this date.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: PROFIT & LOSS (P&L) STATEMENT */}
      {viewMode === 'pnl' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-mono text-slate-400 uppercase">Total Fuel Dispensed</span>
              <p className="text-xl font-mono font-bold text-white mt-1">
                {(totalPetrolLitres + totalDieselLitres).toFixed(1)} Litres
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                MS: {totalPetrolLitres.toFixed(1)} L • HSD: {totalDieselLitres.toFixed(1)} L
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-emerald-500/30">
              <span className="text-xs font-mono text-emerald-400 uppercase font-bold">
                Estimated Gross Margin
              </span>
              <p className="text-2xl font-mono font-black text-emerald-400 mt-1">
                ₹{totalGrossProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Fuel commission + Lube margins
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-amber-500/40">
              <span className="text-xs font-mono text-amber-300 uppercase font-bold">
                Net Operating Profit (After Expenses)
              </span>
              <p
                className={`text-2xl font-mono font-black mt-1 ${
                  netOperatingProfit >= 0 ? 'text-amber-400' : 'text-rose-400'
                }`}
              >
                ₹{netOperatingProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Less ₹{dayExpenses.toLocaleString()} operational expenses
              </p>
            </div>
          </div>

          {/* Detailed Financial Breakdown Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="font-bold text-white text-base pb-3 border-b border-slate-800">
              Day&apos;s Income & Expense Breakdown Statement ({selectedDate})
            </h3>

            <div className="divide-y divide-slate-800 text-xs font-mono">
              <div className="py-2.5 flex justify-between items-center">
                <span>Motor Spirit (Petrol / MS) Commission (@ ₹3.65 / L on {totalPetrolLitres.toFixed(1)} L):</span>
                <span className="font-bold text-emerald-400">
                  +₹{petrolGrossCommission.toFixed(2)}
                </span>
              </div>

              <div className="py-2.5 flex justify-between items-center">
                <span>High Speed Diesel (HSD) Commission (@ ₹2.45 / L on {totalDieselLitres.toFixed(1)} L):</span>
                <span className="font-bold text-blue-400">
                  +₹{dieselGrossCommission.toFixed(2)}
                </span>
              </div>

              <div className="py-2.5 flex justify-between items-center">
                <span>Lubricants & Packaged Engine Oil Profit (@ ~22% on ₹{totalLubeSales.toLocaleString()}):</span>
                <span className="font-bold text-amber-400">
                  +₹{lubeEstimatedMargin.toFixed(2)}
                </span>
              </div>

              <div className="py-3 flex justify-between items-center font-bold text-sm text-white">
                <span>TOTAL GROSS DEALER OPERATING MARGIN:</span>
                <span className="text-emerald-400">
                  ₹{totalGrossProfit.toFixed(2)}
                </span>
              </div>

              <div className="py-2.5 flex justify-between items-center text-rose-400">
                <span>Less Pump Operating Expenses (Genset, Tea, Electricity, Sweeper, Wages):</span>
                <span className="font-bold">
                  -₹{dayExpenses.toFixed(2)}
                </span>
              </div>

              <div className="py-3.5 flex justify-between items-center font-black text-base text-amber-400 border-t-2 border-slate-700">
                <span>ESTIMATED NET STATION PROFIT (खालिस मुनाफा):</span>
                <span>
                  ₹{netOperatingProfit.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
