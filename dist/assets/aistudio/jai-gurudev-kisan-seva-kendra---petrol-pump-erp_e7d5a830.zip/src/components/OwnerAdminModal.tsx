import React, { useState } from 'react';
import {
  ShieldAlert,
  KeyRound,
  UserCheck,
  Edit2,
  Trash2,
  Plus,
  IndianRupee,
  Receipt,
  Gauge,
  Sliders,
  CheckCircle2,
  AlertCircle,
  X,
  Fuel,
} from 'lucide-react';
import {
  Staff,
  Product,
  Nozzle,
  MachineSaleRecord,
  Tank,
} from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import {
  saveStaff,
  deleteStaff,
  updateProduct,
  addProduct,
  deleteProduct,
  updateSaleRecord,
  deleteSaleRecord,
  updateNozzle,
  updateTankStock,
} from '../services/firestoreService';

interface OwnerAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  staffList: Staff[];
  products: Product[];
  nozzles: Nozzle[];
  salesRecords: MachineSaleRecord[];
  tanks: Tank[];
}

export const OwnerAdminModal: React.FC<OwnerAdminModalProps> = ({
  isOpen,
  onClose,
  staffList,
  products,
  nozzles,
  salesRecords,
  tanks,
}) => {
  // Verification Code state (Code: 331047)
  const [passcode, setPasscode] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [authError, setAuthError] = useState('');

  // Active sub-tab inside Owner Master CRUD Panel
  const [adminTab, setAdminTab] = useState<'rates' | 'staff' | 'sales_register' | 'nozzles' | 'tanks'>('rates');

  // Fuel Rates edit state
  const petrolProd = products.find((p) => p.fuelType === 'MS');
  const dieselProd = products.find((p) => p.fuelType === 'HSD');
  const [petrolRate, setPetrolRate] = useState<number>(petrolProd?.price || PUMP_CONFIG.defaultRates.petrol);
  const [dieselRate, setDieselRate] = useState<number>(dieselProd?.price || PUMP_CONFIG.defaultRates.diesel);

  // Staff CRUD state
  const [editingStaff, setEditingStaff] = useState<Staff | null>(null);
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [staffName, setStaffName] = useState('');
  const [staffRole, setStaffRole] = useState<'OWNER' | 'MANAGER' | 'SALESMAN'>('SALESMAN');
  const [staffPhone, setStaffPhone] = useState('');
  const [staffPin, setStaffPin] = useState('');

  // Sales Register edit state
  const [editingSale, setEditingSale] = useState<MachineSaleRecord | null>(null);

  // New Lubricant product
  const [showAddProd, setShowAddProd] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdPrice, setNewProdPrice] = useState(350);
  const [newProdUnit, setNewProdUnit] = useState('Bottle');
  const [newProdStock, setNewProdStock] = useState(25);

  const [notification, setNotification] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen) return null;

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode.trim() === PUMP_CONFIG.ownerPin) {
      setIsUnlocked(true);
      setAuthError('');
    } else {
      setAuthError('Incorrect Owner Passcode. Restricted to Ranjit Singh (Code: 331047)');
    }
  };

  const handleSaveFuelRates = async () => {
    try {
      if (petrolProd) {
        await updateProduct(petrolProd.id, { price: petrolRate });
      }
      if (dieselProd) {
        await updateProduct(dieselProd.id, { price: dieselRate });
      }
      setNotification({
        type: 'success',
        text: `Fuel prices updated in Firestore! MS: ₹${petrolRate}/L | HSD: ₹${dieselRate}/L`,
      });
    } catch {
      setNotification({ type: 'error', text: 'Failed to update rates.' });
    }
  };

  const handleSaveStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingStaff) {
        await saveStaff(
          {
            name: staffName,
            role: staffRole,
            phone: staffPhone,
            pin: staffPin,
            active: editingStaff.active,
          },
          editingStaff.id
        );
        setNotification({ type: 'success', text: `Staff ${staffName} updated!` });
      } else {
        await saveStaff({
          name: staffName,
          role: staffRole,
          phone: staffPhone,
          pin: staffPin,
          active: true,
        });
        setNotification({ type: 'success', text: `Staff ${staffName} registered!` });
      }
      setEditingStaff(null);
      setShowAddStaffModal(false);
      setStaffName('');
      setStaffPhone('');
      setStaffPin('');
    } catch {
      setNotification({ type: 'error', text: 'Error saving staff profile.' });
    }
  };

  const handleDeleteStaff = async (id: string, name: string) => {
    if (name === PUMP_CONFIG.owner) {
      alert('Cannot delete the primary Owner profile!');
      return;
    }
    if (!confirm(`Are you sure you want to remove staff member ${name}?`)) return;
    try {
      await deleteStaff(id);
      setNotification({ type: 'success', text: `Staff ${name} deleted from Firestore.` });
    } catch {
      setNotification({ type: 'error', text: 'Error deleting staff.' });
    }
  };

  const handleDeleteSale = async (saleId?: string) => {
    if (!saleId || !confirm('Are you sure you want to permanently delete this sales bill record?')) return;
    try {
      await deleteSaleRecord(saleId);
      setNotification({ type: 'success', text: 'Sales bill record removed from Firestore.' });
    } catch {
      setNotification({ type: 'error', text: 'Failed to delete sale bill.' });
    }
  };

  const handleAddProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addProduct({
        name: newProdName,
        category: 'LUBRICANT',
        price: Number(newProdPrice),
        unit: newProdUnit,
        stockQuantity: Number(newProdStock),
        minStockAlert: 5,
      });
      setNotification({ type: 'success', text: `Product ${newProdName} added to inventory!` });
      setShowAddProd(false);
      setNewProdName('');
    } catch {
      setNotification({ type: 'error', text: 'Failed to add product.' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl w-full max-w-5xl shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white">Owner Admin & Master CRUD Panel</h2>
                <span className="text-[10px] font-mono font-bold bg-amber-400 text-slate-950 px-2 py-0.5 rounded">
                  Restricted: Ranjit Singh
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Staff accounts, past bills register, nozzle calibrations, daily rates, and tank audits.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Locked state password prompt */}
        {!isUnlocked ? (
          <div className="p-8 sm:p-12 text-center max-w-md mx-auto my-auto space-y-5">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center mx-auto shadow-inner">
              <KeyRound className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-xl font-black text-white">Owner Verification Required</h3>
              <p className="text-xs text-slate-400 mt-1">
                Enter Pump Owner Passcode / Station PIN (<span className="text-amber-400 font-mono font-bold">331047</span>) to access master CRUD operations.
              </p>
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 justify-center">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            <form onSubmit={handleUnlock} className="space-y-3">
              <input
                type="password"
                maxLength={6}
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="Enter 331047..."
                className="w-full text-center text-2xl tracking-[0.4em] font-mono font-bold py-3 bg-slate-950 border border-slate-700 rounded-xl text-amber-400 focus:outline-none focus:border-amber-400"
                autoFocus
              />

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 transition"
              >
                Authenticate Owner Passcode
              </button>
            </form>
          </div>
        ) : (
          /* Unlocked Master Admin Controller */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Top Navigation Tabs */}
            <div className="flex items-center space-x-2 px-6 pt-4 border-b border-slate-800 bg-slate-950/40 overflow-x-auto">
              {[
                { id: 'rates', label: 'Fuel Rates & Lubes' },
                { id: 'staff', label: 'Staff & Salesmen CRUD' },
                { id: 'sales_register', label: 'Past Transaction Bills' },
                { id: 'nozzles', label: 'Nozzle Calibrations' },
                { id: 'tanks', label: 'Tank Storage & 20k L Guard' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setAdminTab(tab.id as any)}
                  className={`px-4 py-2 text-xs font-bold rounded-t-xl transition whitespace-nowrap ${
                    adminTab === tab.id
                      ? 'bg-slate-900 text-amber-400 border-t-2 border-amber-400'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Notification alert */}
            {notification && (
              <div
                className={`mx-6 mt-3 p-3 rounded-xl text-xs flex items-center justify-between ${
                  notification.type === 'success'
                    ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-500/15 border border-rose-500/40 text-rose-300'
                }`}
              >
                <span>{notification.text}</span>
                <button onClick={() => setNotification(null)} className="font-bold underline">
                  Dismiss
                </button>
              </div>
            )}

            {/* Sub-panel Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* 1. DYNAMIC FUEL RATES ADJUSTMENTS */}
              {adminTab === 'rates' && (
                <div className="space-y-6">
                  <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800">
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                      <IndianRupee className="w-4 h-4 text-amber-400" />
                      <span>Dynamic Daily Fuel Selling Rates (₹ per Litre)</span>
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl bg-slate-900 border border-emerald-900/40">
                        <label className="block text-xs font-mono text-emerald-400 uppercase font-bold mb-1">
                          Motor Spirit (Petrol / MS) Price
                        </label>
                        <div className="relative mt-2">
                          <span className="absolute left-3 top-2.5 text-slate-400 font-mono">₹</span>
                          <input
                            type="number"
                            step="0.01"
                            value={petrolRate}
                            onChange={(e) => setPetrolRate(parseFloat(e.target.value) || 0)}
                            className="w-full pl-7 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono font-bold text-white text-base focus:outline-none focus:border-emerald-400"
                          />
                        </div>
                      </div>

                      <div className="p-4 rounded-xl bg-slate-900 border border-blue-900/40">
                        <label className="block text-xs font-mono text-blue-400 uppercase font-bold mb-1">
                          High Speed Diesel (HSD) Price
                        </label>
                        <div className="relative mt-2">
                          <span className="absolute left-3 top-2.5 text-slate-400 font-mono">₹</span>
                          <input
                            type="number"
                            step="0.01"
                            value={dieselRate}
                            onChange={(e) => setDieselRate(parseFloat(e.target.value) || 0)}
                            className="w-full pl-7 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono font-bold text-white text-base focus:outline-none focus:border-blue-400"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 flex justify-end">
                      <button
                        type="button"
                        onClick={handleSaveFuelRates}
                        className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition"
                      >
                        Publish Today's Rates to Firestore
                      </button>
                    </div>
                  </div>

                  {/* Lubricant Products Catalog */}
                  <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-white">
                        Packaged Lubricants & Engine Oils Catalog
                      </h4>
                      <button
                        type="button"
                        onClick={() => setShowAddProd(true)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-xs flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Lubricant</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-4">
                      {products
                        .filter((p) => p.category === 'LUBRICANT')
                        .map((prod) => (
                          <div
                            key={prod.id}
                            className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs flex items-center justify-between"
                          >
                            <div>
                              <p className="font-bold text-white">{prod.name}</p>
                              <p className="text-[11px] font-mono text-amber-400 mt-0.5">
                                ₹{prod.price} / {prod.unit}
                              </p>
                              <span className="text-[10px] text-slate-500">Stock: {prod.stockQuantity} units</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => deleteProduct(prod.id)}
                              className="text-slate-500 hover:text-rose-400 p-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 2. STAFF & SALESMEN MANAGEMENT CRUD */}
              {adminTab === 'staff' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-white text-sm">Pump Personnel & Login PIN Roster</h3>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingStaff(null);
                        setStaffName('');
                        setStaffPhone('');
                        setStaffPin('');
                        setShowAddStaffModal(true);
                      }}
                      className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                      <span>Add Staff / Salesman</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {staffList.map((s) => (
                      <div
                        key={s.id}
                        className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-white text-sm">{s.name}</h4>
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                                s.role === 'OWNER'
                                  ? 'bg-amber-500/20 text-amber-300'
                                  : s.role === 'MANAGER'
                                  ? 'bg-blue-500/20 text-blue-300'
                                  : 'bg-emerald-500/20 text-emerald-300'
                              }`}
                            >
                              {s.role}
                            </span>
                          </div>
                          <p className="text-slate-400 font-mono mt-1">Phone: {s.phone}</p>
                          <p className="text-slate-400 font-mono text-[11px] mt-0.5">
                            Access PIN: <span className="font-bold tracking-widest text-amber-400">••••••</span>
                          </p>
                        </div>


                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingStaff(s);
                              setStaffName(s.name);
                              setStaffRole(s.role);
                              setStaffPhone(s.phone);
                              setStaffPin(s.pin);
                              setShowAddStaffModal(true);
                            }}
                            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition"
                            title="Edit staff"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          {s.role !== 'OWNER' && (
                            <button
                              type="button"
                              onClick={() => handleDeleteStaff(s.id, s.name)}
                              className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
                              title="Delete staff"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. PAST TRANSACTION SALE BILLS REGISTER */}
              {adminTab === 'sales_register' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-white text-sm">Past Transaction Bills Register</h3>
                      <p className="text-xs text-slate-400">
                        Audit, adjust quantities/rates, or remove inaccurate shift bill entries.
                      </p>
                    </div>
                    <span className="text-xs font-mono text-slate-400">{salesRecords.length} Saved Bills</span>
                  </div>

                  <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
                    {salesRecords.map((sale) => (
                      <div
                        key={sale.id}
                        className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-white">{sale.machineName}</span>
                            <span className="text-slate-500 font-mono text-[11px]">{sale.date}</span>
                            <span className="text-amber-400 text-[10px] font-mono font-bold bg-amber-400/10 px-1.5 py-0.5 rounded">
                              By {sale.salesmanName}
                            </span>
                          </div>
                          <div className="flex items-center gap-3 mt-1.5 text-slate-300 font-mono text-[11px] flex-wrap">
                            <span>MS: {sale.petrolLitres} L (₹{sale.petrolAmount})</span>
                            <span>•</span>
                            <span>HSD: {sale.dieselLitres} L (₹{sale.dieselAmount})</span>
                            {sale.lubeAmount > 0 && (
                              <>
                                <span>•</span>
                                <span>Lube: ₹{sale.lubeAmount}</span>
                              </>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-500 mt-1">
                            Breakdown: Cash: ₹{sale.cashAmount} | UPI: ₹{sale.upiAmount} | POS: ₹{sale.posAmount} | Credit: ₹{sale.creditAmount}{' '}
                            {sale.customerName && `(Udhaar to ${sale.customerName})`}
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                          <div className="text-right">
                            <span className="text-[10px] font-mono text-slate-500 uppercase">Grand Total</span>
                            <p className="font-mono font-black text-amber-400 text-base">
                              ₹{sale.grossTotal.toLocaleString()}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleDeleteSale(sale.id)}
                            className="p-2 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
                            title="Delete sale record"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}

                    {salesRecords.length === 0 && (
                      <p className="text-xs text-slate-500 italic py-10 text-center">
                        No machine sales recorded in Firestore yet.
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* 4. NOZZLE CALIBRATIONS */}
              {adminTab === 'nozzles' && (
                <div className="space-y-4">
                  <h3 className="font-bold text-white text-sm">Electronic Meter Totalizer Calibrations</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {nozzles.map((nz) => (
                      <div key={nz.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-sm">
                            Nozzle #{nz.nozzleNumber} ({nz.fuelType === 'MS' ? 'Petrol' : 'Diesel'})
                          </span>
                          <span className="font-mono text-slate-400">{nz.machineName}</span>
                        </div>
                        <p className="font-mono text-amber-400 font-bold text-lg">
                          Totalizer: {nz.lastTotalizer} L
                        </p>
                        <p className="text-[11px] text-slate-500">Last Calibrated: {nz.calibrationDate}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 5. TANKS STORAGE & 20K L GUARD */}
              {adminTab === 'tanks' && (
                <div className="space-y-4">
                  <h3 className="font-bold text-white text-sm">Underground Fuel Tank Stock Adjustments</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {tanks.map((t) => (
                      <div key={t.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-base">{t.fuelName}</span>
                          <span className="font-mono text-slate-400">Tank #{t.tankNumber}</span>
                        </div>

                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Capacity Limit:</span>
                          <span className="font-mono font-bold text-white">
                            {t.capacityLitres.toLocaleString()} Litres{' '}
                            {t.fuelType === 'HSD' && <span className="text-amber-400 font-bold">(STRICT GUARD)</span>}
                          </span>
                        </div>

                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Current Stock:</span>
                          <span className="font-mono font-black text-amber-400 text-lg">
                            {t.currentStockLitres.toLocaleString()} Litres
                          </span>
                        </div>

                        <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
                          <input
                            type="number"
                            id={`tank-input-${t.id}`}
                            defaultValue={t.currentStockLitres}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                          />
                          <button
                            type="button"
                            onClick={async () => {
                              const el = document.getElementById(`tank-input-${t.id}`) as HTMLInputElement;
                              const val = parseFloat(el?.value || '0');
                              try {
                                await updateTankStock(t.id, val);
                                setNotification({ type: 'success', text: `Tank ${t.tankNumber} stock updated to ${val} L!` });
                              } catch (err: any) {
                                setNotification({ type: 'error', text: err?.message || 'Error updating tank' });
                              }
                            }}
                            className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shrink-0"
                          >
                            Update
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* SUB-MODAL: ADD / EDIT STAFF */}
      {showAddStaffModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-base font-bold text-white mb-3">
              {editingStaff ? 'Edit Staff Account' : 'Add New Staff / Salesman'}
            </h3>

            <form onSubmit={handleSaveStaff} className="space-y-3.5">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={staffName}
                  onChange={(e) => setStaffName(e.target.value)}
                  placeholder="e.g. Gurpreet Singh"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Role</label>
                <select
                  value={staffRole}
                  onChange={(e) => setStaffRole(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="SALESMAN">Salesman / Fuel Attendant</option>
                  <option value="MANAGER">Shift Manager</option>
                  <option value="OWNER">Pump Owner</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Mobile Phone *</label>
                <input
                  type="tel"
                  required
                  value={staffPhone}
                  onChange={(e) => setStaffPhone(e.target.value)}
                  placeholder="10-digit mobile"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Login PIN (4-6 Digits) *</label>
                <input
                  type="password"
                  required
                  maxLength={6}
                  value={staffPin}
                  onChange={(e) => setStaffPin(e.target.value)}
                  placeholder="••••"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-amber-400 focus:outline-none focus:border-amber-400"
                />
              </div>


              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddStaffModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
                >
                  Save to Firestore
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SUB-MODAL: ADD LUBRICANT PRODUCT */}
      {showAddProd && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-base font-bold text-white mb-3">Add Lubricant Product</h3>
            <form onSubmit={handleAddProductSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Product Name *</label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="e.g. Castrol CRB Turbomax 15W-40 (5L)"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Selling Price (INR)</label>
                  <input
                    type="number"
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Unit</label>
                  <input
                    type="text"
                    value={newProdUnit}
                    onChange={(e) => setNewProdUnit(e.target.value)}
                    placeholder="Bottle / Can / Bucket"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Opening Stock Quantity</label>
                <input
                  type="number"
                  value={newProdStock}
                  onChange={(e) => setNewProdStock(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddProd(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
