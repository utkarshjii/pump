import React, { useState } from 'react';
import {
  Clock,
  UserCheck,
  CheckCircle2,
  AlertCircle,
  IndianRupee,
  Play,
  StopCircle,
  ShieldCheck,
  Fuel,
  Users,
} from 'lucide-react';
import { Shift, Staff, MachineSaleRecord, Nozzle } from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import { saveShift, closeShift } from '../services/firestoreService';

interface ShiftSalesmanProps {
  shifts: Shift[];
  staffList: Staff[];
  salesRecords: MachineSaleRecord[];
  nozzles: Nozzle[];
  currentStaff: Staff;
}

export const ShiftSalesmanManagement: React.FC<ShiftSalesmanProps> = ({
  shifts,
  staffList,
  salesRecords,
  nozzles,
  currentStaff,
}) => {
  const activeShift = shifts.find((s) => s.status === 'OPEN') || null;

  // New Shift form state
  const [showNewShiftModal, setShowNewShiftModal] = useState(false);
  const [shiftName, setShiftName] = useState('Day Shift (06:00 - 18:00)');
  const [cashierId, setCashierId] = useState(currentStaff.id);
  const [openingCash, setOpeningCash] = useState<number>(15000);

  // Close shift state
  const [showCloseShiftModal, setShowCloseShiftModal] = useState(false);
  const [actualClosingCash, setActualClosingCash] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Salesmen in current shift
  const salesmen = staffList.filter((s) => s.role === 'SALESMAN' && s.active);

  // Calculate stats for current open shift
  const currentShiftSales = activeShift
    ? salesRecords.filter((s) => s.shiftId === activeShift.id || s.date === activeShift.date)
    : [];

  const totalShiftGross = currentShiftSales.reduce((sum, s) => sum + s.grossTotal, 0);
  const totalShiftPhysicalCash = currentShiftSales.reduce((sum, s) => sum + s.cashAmount, 0);
  const totalShiftUpi = currentShiftSales.reduce((sum, s) => sum + s.upiAmount, 0);
  const totalShiftPos = currentShiftSales.reduce((sum, s) => sum + s.posAmount, 0);
  const totalShiftCredit = currentShiftSales.reduce((sum, s) => sum + s.creditAmount, 0);

  // Expected Cash in Drawer = Opening Float + Cash collected from sales
  const expectedCashInDrawer = (activeShift?.openingCash || 0) + totalShiftPhysicalCash;

  const handleStartShift = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setNotification(null);

    const cashier = staffList.find((s) => s.id === cashierId);

    try {
      await saveShift({
        shiftName,
        date: new Date().toISOString().split('T')[0],
        cashierId,
        cashierName: cashier?.name || currentStaff.name,
        status: 'OPEN',
        openingCash,
        startTime: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      });
      setNotification({ type: 'success', text: `${shiftName} started successfully!` });
      setShowNewShiftModal(false);
    } catch {
      setNotification({ type: 'error', text: 'Failed to start new shift.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCloseShift = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeShift) return;
    setIsSubmitting(true);
    setNotification(null);

    try {
      await closeShift(activeShift.id, actualClosingCash, totalShiftGross);
      setNotification({
        type: 'success',
        text: `Shift ${activeShift.shiftName} closed and tallied! Total Sales: ₹${totalShiftGross.toLocaleString()}`,
      });
      setShowCloseShiftModal(false);
    } catch {
      setNotification({ type: 'error', text: 'Failed to close shift.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner & Shift Status */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <Clock className="w-5 h-5" />
            </span>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                SHIFT OPERATIONS & CASHIER HANDOVER
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Shift & Salesman Management
              </h2>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Opening cash float, salesmen duty assignments, live shift collection, and closing cash tally.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {currentStaff.role !== 'SALESMAN' ? (
            activeShift ? (
              <button
                type="button"
                onClick={() => {
                  setActualClosingCash(expectedCashInDrawer);
                  setShowCloseShiftModal(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-600/20 transition"
              >
                <StopCircle className="w-4 h-4" />
                <span>Close Shift & Handover</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setShowNewShiftModal(true)}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition"
              >
                <Play className="w-4 h-4" />
                <span>Start New Shift</span>
              </button>
            )
          ) : (
            <span className="text-[11px] font-mono text-slate-500 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              Shift Actions: Manager & Owner Only
            </span>
          )}
        </div>
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between shadow-lg ${
            notification.type === 'success'
              ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
              : 'bg-rose-500/15 border border-rose-500/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold underline text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* Active Shift Overview Banner */}
      {activeShift ? (
        <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 shadow-xl relative overflow-hidden">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                  ACTIVE SHIFT IN PROGRESS
                </span>
              </div>
              <h3 className="text-xl font-black text-white mt-1">{activeShift.shiftName}</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Date: {activeShift.date} • In-Charge Manager: <strong className="text-slate-200">{activeShift.cashierName}</strong> • Started at: {activeShift.startTime}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-right">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Opening Cash Float</span>
                <p className="text-base font-mono font-black text-slate-200">
                  ₹{activeShift.openingCash.toLocaleString()}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950 border border-emerald-500/40 text-right">
                <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Total Expected Cash</span>
                <p className="text-lg font-mono font-black text-emerald-400">
                  ₹{expectedCashInDrawer.toLocaleString()}
                </p>
              </div>
            </div>
          </div>

          {/* Real-time Shift Payment Breakdown */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs font-mono">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase">Shift Physical Cash</span>
              <p className="text-sm font-bold text-emerald-400 mt-1">₹{totalShiftPhysicalCash.toLocaleString()}</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase">Shift UPI Online</span>
              <p className="text-sm font-bold text-blue-400 mt-1">₹{totalShiftUpi.toLocaleString()}</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase">Shift POS Card</span>
              <p className="text-sm font-bold text-slate-300 mt-1">₹{totalShiftPos.toLocaleString()}</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase">Shift Udhaar (Credit)</span>
              <p className="text-sm font-bold text-amber-400 mt-1">₹{totalShiftCredit.toLocaleString()}</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-6 rounded-3xl bg-slate-900 border border-dashed border-slate-800 text-center space-y-3">
          <Clock className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="font-bold text-white text-base">No Shift Open Currently</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Click &quot;Start New Shift&quot; above to declare the morning or night shift cashier and cash float.
          </p>
        </div>
      )}

      {/* Salesmen Duty Roster & Machine Assignment */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Users className="w-5 h-5 text-amber-400" />
              <span>Salesmen Duty Roster & Dispenser Nozzles</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Active salesmen assigned to Tokheim Front Bay DU-1 and Midco Rear Bay DU-2.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-5">
          {staffList.map((staff) => {
            const staffSales = salesRecords.filter((s) => s.salesmanId === staff.id);
            const staffLitres = staffSales.reduce((sum, s) => sum + s.petrolLitres + s.dieselLitres, 0);
            const staffAmount = staffSales.reduce((sum, s) => sum + s.grossTotal, 0);

            return (
              <div
                key={staff.id}
                className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">{staff.name}</span>
                    <span
                      className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        staff.role === 'OWNER'
                          ? 'bg-amber-500/20 text-amber-400'
                          : staff.role === 'MANAGER'
                          ? 'bg-blue-500/20 text-blue-400'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}
                    >
                      {staff.role}
                    </span>
                  </div>
                  <p className="text-slate-400 font-mono mt-1 text-[11px]">Phone: {staff.phone}</p>
                  <p className="text-slate-500 font-mono text-[10px]">PIN: {staff.pin}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 font-mono space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">Total Volume:</span>
                    <span className="text-slate-200 font-bold">{staffLitres.toFixed(1)} L</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">Total Billed:</span>
                    <span className="text-amber-400 font-bold">₹{staffAmount.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Shifts History Log */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <h3 className="font-bold text-white text-base pb-3 border-b border-slate-800">
          Recent Shift Logs & Cashier Handover Records
        </h3>

        <div className="divide-y divide-slate-800/60 mt-3">
          {shifts.map((shift) => (
            <div key={shift.id} className="py-3 flex items-center justify-between text-xs">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{shift.shiftName}</span>
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold ${
                      shift.status === 'OPEN'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {shift.status}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Date: {shift.date} • Cashier: {shift.cashierName} • Start: {shift.startTime}{' '}
                  {shift.endTime && `• Ended: ${shift.endTime}`}
                </p>
              </div>

              <div className="text-right font-mono">
                <span className="text-slate-400 text-[10px] uppercase">Opening Float</span>
                <p className="font-bold text-slate-200">₹{shift.openingCash.toLocaleString()}</p>
                {shift.closingCash !== undefined && (
                  <p className="text-[11px] text-emerald-400">
                    Handover Cash: ₹{shift.closingCash.toLocaleString()}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL: START NEW SHIFT */}
      {showNewShiftModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">Start New Work Shift</h3>
            <p className="text-xs text-slate-400 mb-4">
              Declare pump cashier, shift name, and opening drawer cash float.
            </p>

            <form onSubmit={handleStartShift} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Shift Name</label>
                <select
                  value={shiftName}
                  onChange={(e) => setShiftName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="Day Shift (06:00 - 18:00)">Day Shift (06:00 - 18:00)</option>
                  <option value="Night Shift (18:00 - 06:00)">Night Shift (18:00 - 06:00)</option>
                  <option value="General Shift">General Shift</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Cashier In-Charge</label>
                <select
                  value={cashierId}
                  onChange={(e) => setCashierId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  {staffList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  Opening Cash Float in Drawer (INR) *
                </label>
                <input
                  type="number"
                  step="100"
                  required
                  value={openingCash}
                  onChange={(e) => setOpeningCash(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-base font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowNewShiftModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Start Shift
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CLOSE SHIFT */}
      {showCloseShiftModal && activeShift && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">Close Shift & Cash Handover</h3>
            <p className="text-xs text-slate-400 mb-4">
              Tally collected cash against expected drawer total.
            </p>

            <form onSubmit={handleCloseShift} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Opening Cash Float:</span>
                  <span className="text-white">₹{activeShift.openingCash.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Cash Sales Collected:</span>
                  <span className="text-white">₹{totalShiftPhysicalCash.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold border-t border-slate-800 pt-1 text-emerald-400">
                  <span>Expected Drawer Cash:</span>
                  <span>₹{expectedCashInDrawer.toLocaleString()}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  Actual Physical Cash Counted (INR) *
                </label>
                <input
                  type="number"
                  step="1"
                  required
                  value={actualClosingCash}
                  onChange={(e) => setActualClosingCash(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-lg font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
                />
              </div>

              {actualClosingCash !== expectedCashInDrawer && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono flex justify-between">
                  <span>Cash Difference (Short / Excess):</span>
                  <span className="font-bold">
                    {actualClosingCash - expectedCashInDrawer > 0 ? '+' : ''}
                    ₹{(actualClosingCash - expectedCashInDrawer).toLocaleString()}
                  </span>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowCloseShiftModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md"
                >
                  Confirm Close Shift
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
