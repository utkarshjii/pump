import React, { useState } from 'react';
import {
  Thermometer,
  Truck,
  CheckCircle2,
  AlertTriangle,
  Plus,
  Scale,
  Calendar,
  Layers,
  Fuel,
  Droplet,
  Trash2,
} from 'lucide-react';
import { DensityRecord, TankerReceipt, Staff, Tank } from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import {
  addDensityRecord,
  deleteDensityRecord,
  addTankerReceipt,
} from '../services/firestoreService';

interface DensityDecantationProps {
  densityRecords: DensityRecord[];
  tankerReceipts: TankerReceipt[];
  tanks: Tank[];
  currentStaff: Staff;
}

export const DensityDecantation: React.FC<DensityDecantationProps> = ({
  densityRecords,
  tankerReceipts,
  tanks,
  currentStaff,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'density' | 'tanker'>('density');

  // New Density Test Form State
  const [showDensityModal, setShowDensityModal] = useState(false);
  const [testDate, setTestDate] = useState(new Date().toISOString().split('T')[0]);
  const [timeSlot, setTimeSlot] = useState<'MORNING' | 'EVENING'>('MORNING');
  const [fuelType, setFuelType] = useState<'MS' | 'HSD'>('HSD');
  const [observedDensity, setObservedDensity] = useState<number>(828.0);
  const [temperatureC, setTemperatureC] = useState<number>(29.5);
  const [invoiceDensity, setInvoiceDensity] = useState<number>(830.5);
  const [waterPasteTest, setWaterPasteTest] = useState<'NEGATIVE' | 'POSITIVE'>('NEGATIVE');
  const [remarks, setRemarks] = useState('');

  // New Tanker Decantation Modal State
  const [showTankerModal, setShowTankerModal] = useState(false);
  const [invoiceNo, setInvoiceNo] = useState('');
  const [tankerNo, setTankerNo] = useState('');
  const [company, setCompany] = useState<'IOCL' | 'BPCL' | 'HPCL' | 'OTHER'>('IOCL');
  const [decantFuelType, setDecantFuelType] = useState<'MS' | 'HSD'>('HSD');
  const [invoiceLitres, setInvoiceLitres] = useState<number>(12000);
  const [receivedLitres, setReceivedLitres] = useState<number>(11980);
  const [preDipCm, setPreDipCm] = useState<number>(60.0);
  const [postDipCm, setPostDipCm] = useState<number>(185.0);
  const [decantDensity15C, setDecantDensity15C] = useState<number>(829.0);
  const [decantWaterTest, setDecantWaterTest] = useState<'NEGATIVE' | 'POSITIVE'>('NEGATIVE');
  const [sealNotes, setSealNotes] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const dieselTank = tanks.find((t) => t.fuelType === 'HSD') || { currentStockLitres: 14800, capacityLitres: 20000 };

  // Calculate Converted Density to 15°C:
  // Standard ASTM Petroleum formula approximation:
  // For Diesel: temp coefficient ~ 0.70 kg/m3 per °C deviation from 15°C
  // For Petrol: temp coefficient ~ 0.85 kg/m3 per °C deviation from 15°C
  const tempDiff = temperatureC - 15.0;
  const tempCoeff = fuelType === 'HSD' ? 0.70 : 0.85;
  const convertedDensity15C = Number((observedDensity + tempDiff * tempCoeff).toFixed(1));
  const variation = Number(Math.abs(convertedDensity15C - invoiceDensity).toFixed(1));
  const isVariationPermissible = variation <= 3.0; // Statutory tolerance limit is ±3.0 kg/m3

  const handleSaveDensity = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setNotification(null);

    try {
      await addDensityRecord({
        date: testDate,
        timeSlot,
        fuelType,
        tankNumber: fuelType === 'MS' ? 1 : 2,
        observedDensity,
        temperatureC,
        convertedDensity15C,
        invoiceDensity,
        variation,
        waterPasteTest,
        testedBy: currentStaff.name,
        remarks,
        createdAt: new Date().toISOString(),
      });
      setNotification({
        type: 'success',
        text: `Density Test record for ${fuelType} (${timeSlot}) saved to Firestore! 15°C Density: ${convertedDensity15C} kg/m³ (Var: ${variation})`,
      });
      setShowDensityModal(false);
      setRemarks('');
    } catch {
      setNotification({ type: 'error', text: 'Failed to record density test.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteDensity = async (id?: string) => {
    if (!id || !confirm('Delete this density test log?')) return;
    try {
      await deleteDensityRecord(id);
    } catch {
      alert('Failed to delete density record');
    }
  };

  const handleSaveTanker = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setNotification(null);

    // Diesel Strict Guard check
    if (decantFuelType === 'HSD') {
      const projected = (dieselTank.currentStockLitres || 0) + receivedLitres;
      if (projected > 20000) {
        setNotification({
          type: 'error',
          text: `STRICT GUARD VIOLATION: Unloading ${receivedLitres.toLocaleString()} L into Diesel Tank 2 will result in ${projected.toLocaleString()} L, EXCEEDING the 20,000 Litres maximum capacity!`,
        });
        setIsSubmitting(false);
        return;
      }
    }

    try {
      await addTankerReceipt({
        date: testDate,
        invoiceNo,
        tankerNo,
        company,
        fuelType: decantFuelType,
        tankId: decantFuelType === 'MS' ? 'tank-1-petrol' : 'tank-2-diesel',
        invoiceLitres,
        preDipCm,
        postDipCm,
        receivedLitres,
        density15C: decantDensity15C,
        waterTestResult: decantWaterTest,
        receivedBy: currentStaff.name,
        notes: sealNotes,
        createdAt: new Date().toISOString(),
      });
      setNotification({
        type: 'success',
        text: `Tanker decantation receipt #${invoiceNo} posted and stock added to live Firestore tank!`,
      });
      setShowTankerModal(false);
      setInvoiceNo('');
      setTankerNo('');
      setSealNotes('');
    } catch {
      setNotification({ type: 'error', text: 'Failed to save tanker decantation.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <Thermometer className="w-5 h-5" />
            </span>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                QUALITY & STATUTORY HYDROMETER AUDIT
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Fuel Density Register & Decantation
              </h2>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Mandatory daily 15°C ASTM-53B hydrometer density testing, ±3.0 kg/m³ variation guard, and tanker unloading logs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Sub Tab Switcher */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setActiveSubTab('density')}
              className={`px-3 py-1.5 rounded-lg font-bold transition ${
                activeSubTab === 'density' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Daily Density Register
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab('tanker')}
              className={`px-3 py-1.5 rounded-lg font-bold transition ${
                activeSubTab === 'tanker' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Tanker Decantations
            </button>
          </div>

          <button
            type="button"
            onClick={() => (activeSubTab === 'density' ? setShowDensityModal(true) : setShowTankerModal(true))}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md transition"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>{activeSubTab === 'density' ? 'Record Density Test' : 'New Decantation'}</span>
          </button>
        </div>
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between shadow-lg ${
            notification.type === 'success'
              ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
              : 'bg-rose-500/15 border border-rose-500/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold underline text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* SUB-PANEL 1: DAILY DENSITY REGISTER */}
      {activeSubTab === 'density' && (
        <div className="space-y-6">
          {/* Statutory Density Norms Card */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
            <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/30">
              <span className="text-[10px] text-slate-400 uppercase">Petrol (MS) Range @ 15°C</span>
              <p className="text-lg font-bold text-emerald-400 mt-1">720.0 to 775.0 kg/m³</p>
              <span className="text-[10px] text-slate-500">Statutory Standard</span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-blue-500/30">
              <span className="text-[10px] text-slate-400 uppercase">Diesel (HSD) Range @ 15°C</span>
              <p className="text-lg font-bold text-blue-400 mt-1">820.0 to 860.0 kg/m³</p>
              <span className="text-[10px] text-slate-500">Statutory Standard</span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/30">
              <span className="text-[10px] text-slate-400 uppercase">Permissible Tolerance</span>
              <p className="text-lg font-bold text-amber-400 mt-1">Within ±3.0 kg/m³</p>
              <span className="text-[10px] text-slate-500">vs OMC TT Invoice Density</span>
            </div>
          </div>

          {/* Density Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
            <div className="pb-4 border-b border-slate-800 flex items-center justify-between">
              <h3 className="font-bold text-white text-base">Daily Hydrometer Density Test Register</h3>
              <span className="text-xs text-slate-400 font-mono">{densityRecords.length} Tests</span>
            </div>

            <div className="overflow-x-auto mt-4">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                    <th className="pb-3 pl-2">Date & Slot</th>
                    <th className="pb-3">Product</th>
                    <th className="pb-3 text-right">Observed Density</th>
                    <th className="pb-3 text-right">Temp (°C)</th>
                    <th className="pb-3 text-right">Converted @ 15°C</th>
                    <th className="pb-3 text-right">Challan Density</th>
                    <th className="pb-3 text-center">Variation</th>
                    <th className="pb-3 text-center">Water Test</th>
                    <th className="pb-3">Tested By</th>
                    <th className="pb-3 pr-2 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-sans">
                  {densityRecords.map((rec) => {
                    const isOk = rec.variation <= 3.0;
                    return (
                      <tr key={rec.id} className="hover:bg-slate-800/30 transition">
                        <td className="py-3 pl-2 font-mono">
                          <span className="font-bold text-white">{rec.date}</span>
                          <span className="text-[10px] ml-1.5 px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                            {rec.timeSlot}
                          </span>
                        </td>
                        <td className="py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                              rec.fuelType === 'MS'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-blue-500/20 text-blue-300'
                            }`}
                          >
                            {rec.fuelType === 'MS' ? 'Petrol' : 'Diesel'}
                          </span>
                        </td>
                        <td className="py-3 text-right font-mono text-slate-300">
                          {rec.observedDensity} kg/m³
                        </td>
                        <td className="py-3 text-right font-mono text-slate-300">
                          {rec.temperatureC}°C
                        </td>
                        <td className="py-3 text-right font-mono font-bold text-white">
                          {rec.convertedDensity15C} kg/m³
                        </td>
                        <td className="py-3 text-right font-mono text-slate-400">
                          {rec.invoiceDensity} kg/m³
                        </td>
                        <td className="py-3 text-center font-mono">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              isOk ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                            }`}
                          >
                            ±{rec.variation} kg/m³ {isOk ? '✓' : 'ALERT'}
                          </span>
                        </td>
                        <td className="py-3 text-center font-mono">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              rec.waterPasteTest === 'NEGATIVE'
                                ? 'bg-emerald-500/10 text-emerald-400'
                                : 'bg-rose-500/20 text-rose-400'
                            }`}
                          >
                            {rec.waterPasteTest}
                          </span>
                        </td>
                        <td className="py-3 text-slate-300">{rec.testedBy}</td>
                        <td className="py-3 pr-2 text-right">
                          <button
                            type="button"
                            onClick={() => handleDeleteDensity(rec.id)}
                            className="p-1 text-slate-500 hover:text-rose-400 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {densityRecords.length === 0 && (
                <div className="h-40 flex items-center justify-center text-xs text-slate-500 italic">
                  No daily density test records logged yet. Click &quot;Record Density Test&quot; to add.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUB-PANEL 2: TANKER DECANTATIONS */}
      {activeSubTab === 'tanker' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
          <div className="pb-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-white text-base">Tanker Inward Decantation & Seal Register</h3>
            <span className="text-xs text-slate-400 font-mono">{tankerReceipts.length} Decantations</span>
          </div>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                  <th className="pb-3 pl-2">Invoice / Date</th>
                  <th className="pb-3">Tanker No.</th>
                  <th className="pb-3">Company</th>
                  <th className="pb-3">Product</th>
                  <th className="pb-3 text-right">Challan Qty</th>
                  <th className="pb-3 text-right">Received Qty</th>
                  <th className="pb-3 text-center">Short / Gain</th>
                  <th className="pb-3 text-center">15°C Density</th>
                  <th className="pb-3 text-center">Water Test</th>
                  <th className="pb-3 pr-2 text-right">Received By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {tankerReceipts.map((r, idx) => {
                  const diff = r.receivedLitres - r.invoiceLitres;
                  return (
                    <tr key={r.id || idx} className="hover:bg-slate-800/30 transition">
                      <td className="py-3 pl-2 font-mono">
                        <span className="font-bold text-white">{r.invoiceNo}</span>
                        <p className="text-[10px] text-slate-500">{r.date}</p>
                      </td>
                      <td className="py-3 font-mono font-bold text-slate-200">{r.tankerNo}</td>
                      <td className="py-3 font-semibold text-slate-300">{r.company}</td>
                      <td className="py-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                            r.fuelType === 'MS'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-blue-500/20 text-blue-300'
                          }`}
                        >
                          {r.fuelType === 'MS' ? 'Petrol' : 'Diesel'}
                        </span>
                      </td>
                      <td className="py-3 text-right font-mono text-slate-400">{r.invoiceLitres.toLocaleString()} L</td>
                      <td className="py-3 text-right font-mono font-bold text-white">{r.receivedLitres.toLocaleString()} L</td>
                      <td className="py-3 text-center font-mono">
                        <span className={`font-bold ${diff < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                          {diff > 0 ? `+${diff}` : diff} L
                        </span>
                      </td>
                      <td className="py-3 text-center font-mono text-slate-200">{r.density15C} kg/m³</td>
                      <td className="py-3 text-center font-mono">
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400">
                          {r.waterTestResult}
                        </span>
                      </td>
                      <td className="py-3 pr-2 text-right text-slate-300">{r.receivedBy}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {tankerReceipts.length === 0 && (
              <div className="h-40 flex items-center justify-center text-xs text-slate-500 italic">
                No tanker decantations recorded yet.
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL: RECORD DENSITY TEST */}
      {showDensityModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">Record Daily Hydrometer Density</h3>
            <p className="text-xs text-slate-400 mb-4">
              Converts observed reading to 15°C and checks statutory ±3.0 kg/m³ variance.
            </p>

            <form onSubmit={handleSaveDensity} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Date</label>
                  <input
                    type="date"
                    value={testDate}
                    onChange={(e) => setTestDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Time Slot</label>
                  <select
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="MORNING">Morning (06:00 AM)</option>
                    <option value="EVENING">Evening (06:00 PM)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Fuel Product</label>
                <select
                  value={fuelType}
                  onChange={(e) => {
                    const f = e.target.value as 'MS' | 'HSD';
                    setFuelType(f);
                    if (f === 'MS') {
                      setObservedDensity(735.0);
                      setInvoiceDensity(742.0);
                    } else {
                      setObservedDensity(828.0);
                      setInvoiceDensity(830.5);
                    }
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="HSD">High Speed Diesel (HSD) - Tank 2</option>
                  <option value="MS">Motor Spirit (Petrol / MS) - Tank 1</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                    Observed Density (kg/m³) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={observedDensity}
                    onChange={(e) => setObservedDensity(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                    Temperature (°C) *
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={temperatureC}
                    onChange={(e) => setTemperatureC(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  Challan / Invoice Density @ 15°C *
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={invoiceDensity}
                  onChange={(e) => setInvoiceDensity(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-300 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Converted 15C preview & variance indicator */}
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Converted Density @ 15°C:</span>
                  <span className="font-bold text-white">{convertedDensity15C} kg/m³</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Statutory Variation:</span>
                  <span className={`font-bold ${isVariationPermissible ? 'text-emerald-400' : 'text-rose-400'}`}>
                    ±{variation} kg/m³ ({isVariationPermissible ? 'Pass' : 'Failed > 3.0'})
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Water Paste Test</label>
                <select
                  value={waterPasteTest}
                  onChange={(e) => setWaterPasteTest(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="NEGATIVE">NEGATIVE (No Water Detected - Passed)</option>
                  <option value="POSITIVE">POSITIVE (Water Detected - Alert)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowDensityModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Save Density Audit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: TANKER DECANTATION */}
      {showTankerModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-black text-white mb-1">Log Tanker Decantation</h3>
            <p className="text-xs text-slate-400 mb-4">
              Enter OMC invoice details, pre/post dip levels, and density.
            </p>

            <form onSubmit={handleSaveTanker} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Challan / Invoice No. *</label>
                  <input
                    type="text"
                    required
                    value={invoiceNo}
                    onChange={(e) => setInvoiceNo(e.target.value)}
                    placeholder="e.g. IOCL-99882"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Tanker Truck No. *</label>
                  <input
                    type="text"
                    required
                    value={tankerNo}
                    onChange={(e) => setTankerNo(e.target.value)}
                    placeholder="e.g. PB-10-XX-4411"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Company (OMC)</label>
                  <select
                    value={company}
                    onChange={(e) => setCompany(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="IOCL">Indian Oil (IOCL)</option>
                    <option value="BPCL">Bharat Petroleum (BPCL)</option>
                    <option value="HPCL">Hindustan Petroleum (HPCL)</option>
                    <option value="OTHER">Other OMC</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Product</label>
                  <select
                    value={decantFuelType}
                    onChange={(e) => setDecantFuelType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="HSD">High Speed Diesel (HSD)</option>
                    <option value="MS">Motor Spirit (Petrol / MS)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Invoice Litres *</label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={invoiceLitres}
                    onChange={(e) => setInvoiceLitres(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Received Litres (Dip Chart) *</label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={receivedLitres}
                    onChange={(e) => setReceivedLitres(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Pre-Dip Level (cm)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={preDipCm}
                    onChange={(e) => setPreDipCm(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Post-Dip Level (cm)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={postDipCm}
                    onChange={(e) => setPostDipCm(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Density @ 15°C (kg/m³)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={decantDensity15C}
                    onChange={(e) => setDecantDensity15C(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Water Test</label>
                  <select
                    value={decantWaterTest}
                    onChange={(e) => setDecantWaterTest(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="NEGATIVE">NEGATIVE (No Water)</option>
                    <option value="POSITIVE">POSITIVE (Water Detected)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowTankerModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Save Decantation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
