import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Trash2,
  Receipt,
  Landmark,
  IndianRupee,
  CheckCircle2,
} from 'lucide-react';
import { Voucher, Staff } from '../types/pump';
import { addVoucher, deleteVoucher } from '../services/firestoreService';

interface VouchersPanelProps {
  vouchers: Voucher[];
  currentStaff: Staff;
}

export const VouchersPanel: React.FC<VouchersPanelProps> = ({ vouchers, currentStaff }) => {
  const [showModal, setShowModal] = useState(false);
  const [voucherNumber, setVoucherNumber] = useState(`VCH-${Date.now().toString().slice(-5)}`);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [type, setType] = useState<'EXPENSE' | 'BANK_DEPOSIT' | 'SALARY' | 'OTHER'>('EXPENSE');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [paidTo, setPaidTo] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string>('');

  const totalExpense = vouchers
    .filter((v) => v.type === 'EXPENSE' || v.type === 'SALARY' || v.type === 'OTHER')
    .reduce((sum, v) => sum + v.amount, 0);

  const totalBankDeposit = vouchers
    .filter((v) => v.type === 'BANK_DEPOSIT')
    .reduce((sum, v) => sum + v.amount, 0);

  const handleCreateVoucher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || amount <= 0) return;

    try {
      setIsSubmitting(true);
      await addVoucher({
        voucherNumber,
        date,
        type,
        title,
        amount,
        paidTo,
        authorizedBy: currentStaff.name,
        notes,
        createdAt: new Date().toISOString(),
      });
      setStatusMsg(`Voucher ${voucherNumber} (₹${amount}) posted to Firestore!`);
      setShowModal(false);
      setTitle('');
      setAmount(0);
      setPaidTo('');
      setNotes('');
      setVoucherNumber(`VCH-${Date.now().toString().slice(-5)}`);
    } catch {
      setStatusMsg('Failed to create voucher.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id?: string) => {
    if (!id || !confirm('Are you sure you want to delete this voucher?')) return;
    try {
      await deleteVoucher(id);
    } catch {
      alert('Failed to delete voucher');
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner & Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <span className="text-[11px] font-mono uppercase text-slate-400">Total Vouchers</span>
          <p className="text-2xl font-black text-white mt-1">{vouchers.length} Records</p>
        </div>

        <div className="bg-slate-900 border border-rose-500/30 rounded-3xl p-5 shadow-xl">
          <span className="text-[11px] font-mono uppercase text-rose-400 font-bold">Total Pump Operational Expenses</span>
          <p className="text-2xl font-mono font-black text-rose-400 mt-1">
            ₹{totalExpense.toLocaleString()}
          </p>
        </div>

        <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-5 shadow-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono uppercase text-emerald-400 font-bold">Bank Cash Deposits</span>
            <p className="text-2xl font-mono font-black text-emerald-400 mt-1">
              ₹{totalBankDeposit.toLocaleString()}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowModal(true)}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-500/20 transition"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>New Voucher</span>
          </button>
        </div>
      </div>

      {statusMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* Vouchers Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="pb-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <span>Station Cash Expense & Bank Deposit Vouchers</span>
          </h3>
          <span className="text-xs text-slate-400">{vouchers.length} Items</span>
        </div>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                <th className="pb-3 pl-2">Voucher #</th>
                <th className="pb-3">Date</th>
                <th className="pb-3">Type</th>
                <th className="pb-3">Title / Purpose</th>
                <th className="pb-3">Paid To / Deposited In</th>
                <th className="pb-3">Authorized By</th>
                <th className="pb-3 text-right">Amount</th>
                <th className="pb-3 pr-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {vouchers.map((v) => (
                <tr key={v.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3 pl-2 font-mono font-bold text-white">{v.voucherNumber}</td>
                  <td className="py-3 text-slate-400 font-mono">{v.date}</td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        v.type === 'BANK_DEPOSIT'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : v.type === 'SALARY'
                          ? 'bg-purple-500/20 text-purple-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {v.type}
                    </span>
                  </td>
                  <td className="py-3 font-semibold text-slate-200">
                    {v.title}
                    {v.notes && <p className="text-[10px] text-slate-500 italic mt-0.5">{v.notes}</p>}
                  </td>
                  <td className="py-3 text-slate-300">{v.paidTo || '-'}</td>
                  <td className="py-3 text-slate-400">{v.authorizedBy}</td>
                  <td className="py-3 text-right font-mono font-bold text-base text-amber-400">
                    ₹{v.amount.toLocaleString()}
                  </td>
                  <td className="py-3 pr-2 text-right">
                    <button
                      type="button"
                      onClick={() => handleDelete(v.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition"
                      title="Delete voucher"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {vouchers.length === 0 && (
            <div className="h-48 flex items-center justify-center text-xs text-slate-500 italic">
              No operational vouchers recorded yet.
            </div>
          )}
        </div>
      </div>

      {/* MODAL: CREATE VOUCHER */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">Create Station Voucher</h3>
            <p className="text-xs text-slate-400 mb-4">
              Log pump operational expenses, Genset diesel, maintenance, or bank deposits.
            </p>

            <form onSubmit={handleCreateVoucher} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Voucher No.</label>
                  <input
                    type="text"
                    value={voucherNumber}
                    onChange={(e) => setVoucherNumber(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Date</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Voucher Category</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="EXPENSE">Pump Operational Expense (Genset / Tea / Sweeper)</option>
                  <option value="BANK_DEPOSIT">Bank Cash Deposit (SBI / HDFC / PNB)</option>
                  <option value="SALARY">Salesman / Staff Salary Advance</option>
                  <option value="OTHER">Electricity / Maintenance / Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Title / Purpose *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Genset Diesel (20L) / Electricity Bill"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Amount (INR) *</label>
                  <input
                    type="number"
                    step="1"
                    min="1"
                    required
                    placeholder="0"
                    value={amount || ''}
                    onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Paid To / Recipient</label>
                  <input
                    type="text"
                    placeholder="e.g. State Bank of India / Ramesh"
                    value={paidTo}
                    onChange={(e) => setPaidTo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Remarks / Slip Details</label>
                <input
                  type="text"
                  placeholder="Optional details..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || amount <= 0}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Save Voucher to Firestore
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
