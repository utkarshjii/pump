import React from 'react';
import { Fuel, ShieldCheck, UserCheck, AlertTriangle } from 'lucide-react';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import { Staff } from '../types/pump';

interface HeaderProps {
  currentStaff: Staff | null;
  onLogout: () => void;
  onOpenOwnerModal: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  dieselStock: number;
}

export const StationHeader: React.FC<HeaderProps> = ({
  currentStaff,
  onLogout,
  onOpenOwnerModal,
  activeTab,
  setActiveTab,
  dieselStock,
}) => {
  const isDieselNearLimit = dieselStock >= 19000;
  const isDieselExceeded = dieselStock > 20000;

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-xl">
      {/* Top Warning Banner if Diesel approaches or breaches 20k L */}
      {(isDieselNearLimit || isDieselExceeded) && (
        <div
          className={`px-4 py-1.5 text-xs font-semibold flex items-center justify-center gap-2 ${
            isDieselExceeded
              ? 'bg-rose-600 text-white animate-pulse'
              : 'bg-amber-500/20 text-amber-300 border-b border-amber-500/30'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>
            {isDieselExceeded
              ? `CRITICAL WARNING: Diesel (HSD) Stock is ${dieselStock.toLocaleString()} L — EXCEEDS 20,000 L TANK CAPACITY!`
              : `ALERT: Diesel (HSD) Stock is ${dieselStock.toLocaleString()} L — Approaching 20,000 L Maximum Guard Limit.`}
          </span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Station Brand Info */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center shadow-lg shadow-amber-500/20 text-slate-950">
              <Fuel className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-base sm:text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                  {PUMP_CONFIG.name}
                </h1>
                <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-amber-400 text-slate-950 uppercase tracking-wider">
                  Pump Code: {PUMP_CONFIG.code}
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:flex items-center gap-3 mt-0.5 font-medium">
                <span>
                  Owner:{' '}
                  <strong className="text-slate-200 font-semibold">{PUMP_CONFIG.owner}</strong>
                </span>
                <span className="text-slate-600">•</span>
                <span>
                  Manager:{' '}
                  <strong className="text-slate-200 font-semibold">{PUMP_CONFIG.manager}</strong>
                </span>
                <span className="text-slate-600">•</span>
                <span className="text-emerald-400 font-mono text-[11px] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Firestore Live Cloud
                </span>
              </p>
            </div>
          </div>

          {/* User Profile & Owner Admin Lock */}
          <div className="flex items-center gap-2 sm:gap-3">
            {currentStaff ? (
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-semibold text-slate-200">{currentStaff.name}</p>
                  <span
                    className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                      currentStaff.role === 'OWNER'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : currentStaff.role === 'MANAGER'
                        ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    }`}
                  >
                    {currentStaff.role}
                  </span>
                </div>

                {/* Owner Admin Quick Access - restricted to Owner & Manager */}
                {currentStaff.role !== 'SALESMAN' && (
                  <button
                    type="button"
                    onClick={onOpenOwnerModal}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all shadow-sm ${
                      currentStaff.role === 'OWNER'
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                    }`}
                    title="Owner Master CRUD Panel (Code: 331047)"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span className="hidden sm:inline">Owner Master</span>
                  </button>
                )}

                {/* Logout */}
                <button
                  type="button"
                  onClick={onLogout}
                  className="px-2.5 py-1.5 rounded-lg text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 border border-rose-500/20 transition-colors"
                >
                  Logout
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <UserCheck className="w-4 h-4 text-amber-400" />
                <span>Station Login</span>
              </div>
            )}
          </div>
        </div>

        {/* Navigation Tabs - Strict RBAC Enforcement */}
        {currentStaff && (
          <nav className="flex space-x-1 sm:space-x-1.5 overflow-x-auto py-2.5 border-t border-slate-800/80 scrollbar-none text-xs font-semibold">
            {[
              { id: 'dashboard', label: 'Dashboard', roles: ['OWNER', 'MANAGER', 'SALESMAN'] },
              { id: 'daily-sales', label: 'Daily Sales Entry', roles: ['OWNER', 'MANAGER', 'SALESMAN'] },
              { id: 'stock-dips', label: 'Stock and Dips', roles: ['OWNER', 'MANAGER'] },
              { id: 'sales-billing', label: 'Sales & Billing', roles: ['OWNER', 'MANAGER'] },
              { id: 'shift-salesman', label: 'Shift & Salesman', roles: ['OWNER', 'MANAGER', 'SALESMAN'] },
              { id: 'khata-udhar', label: 'Khata / Udhar', roles: ['OWNER', 'MANAGER'] },
              { id: 'voucher-rates', label: 'Voucher & Rates', roles: ['OWNER', 'MANAGER'] },
              { id: 'day-book-pnl', label: 'Day Book & P&L', roles: ['OWNER', 'MANAGER'] },
              { id: 'density-decantation', label: 'Density & Tankers', roles: ['OWNER', 'MANAGER'] },
              { id: 'backup-masters', label: 'Backup & Masters', roles: ['OWNER', 'MANAGER'] },
              { id: 'owner-admin', label: 'Owner / Admin CRUD', roles: ['OWNER'] },
            ]
              .filter((tab) => tab.roles.includes(currentStaff.role))
              .map((tab) => {
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => {
                      if (tab.id === 'owner-admin') {
                        onOpenOwnerModal();
                      } else {
                        setActiveTab(tab.id);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
                      isActive
                        ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/25 ring-1 ring-amber-400'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/70 border border-transparent'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
          </nav>
        )}
      </div>
    </header>
  );
};
