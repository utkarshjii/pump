import React, { useState, useEffect, useMemo } from 'react';
import {
  Fuel,
  Droplet,
  Calculator,
  CheckCircle2,
  AlertTriangle,
  Receipt,
  User,
  Plus,
  Trash2,
  Package,
} from 'lucide-react';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import {
  Staff,
  Tank,
  Product,
  Customer,
  MachineSaleRecord,
  Nozzle,
} from '../types/pump';
import { submitMachineSale } from '../services/firestoreService';

interface UnifiedSalesEntryProps {
  currentStaff: Staff;
  tanks: Tank[];
  products: Product[];
  customers: Customer[];
  nozzles?: Nozzle[];
  salesRecords?: MachineSaleRecord[];
  onSaleSaved?: () => void;
}

export const UnifiedSalesEntry: React.FC<UnifiedSalesEntryProps> = ({
  currentStaff,
  tanks,
  products,
  customers,
  nozzles = [],
  salesRecords = [],
  onSaleSaved,
}) => {
  // Machine Selection: Tokheim DU-1 or Midco DU-2
  const [selectedMachineId, setSelectedMachineId] = useState<'tokheim-du1' | 'midco-du2'>('tokheim-du1');
  const [entryMode, setEntryMode] = useState<'meter' | 'direct'>('meter');
  const [saleDate, setSaleDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Rates from Firestore Products
  const petrolProduct = products.find((p) => p.fuelType === 'MS') || { price: PUMP_CONFIG.defaultRates.petrol };
  const dieselProduct = products.find((p) => p.fuelType === 'HSD') || { price: PUMP_CONFIG.defaultRates.diesel };
  const lubeProducts = products.filter((p) => p.category === 'LUBRICANT');

  // Diesel Tank for STRICT GUARD check
  const dieselTank = tanks.find((t) => t.fuelType === 'HSD') || { currentStockLitres: 14800, capacityLitres: 20000 };
  const petrolTank = tanks.find((t) => t.fuelType === 'MS') || { currentStockLitres: 11250, capacityLitres: 15000 };

  // SHIFT METER AUTO-ROLLOVER:
  // Find the most recent shift sale record for this dispenser machine in Firestore
  const previousMachineSale = useMemo(() => {
    if (!salesRecords || salesRecords.length === 0) return null;
    const recordsForMachine = salesRecords.filter(
      (s) =>
        s.machineId === selectedMachineId &&
        ((s.petrolClosing && s.petrolClosing > 0) || (s.dieselClosing && s.dieselClosing > 0))
    );
    if (recordsForMachine.length === 0) return null;

    // Sort descending by createdAt or date
    return [...recordsForMachine].sort((a, b) => {
      const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return timeB - timeA;
    })[0];
  }, [salesRecords, selectedMachineId]);

  // Find corresponding nozzle totalizers as second fallback
  const msNozzle = nozzles.find((n) => n.machineId === selectedMachineId && n.fuelType === 'MS');
  const hsdNozzle = nozzles.find((n) => n.machineId === selectedMachineId && n.fuelType === 'HSD');

  // Rollover status info
  const [rolloverMeta, setRolloverMeta] = useState<{
    source: string;
    prevShiftSlip?: string;
    prevDate?: string;
    prevSalesman?: string;
  }>({
    source: 'Calibrated System Baseline',
  });

  // Petrol (MS) State
  const [petrolOpening, setPetrolOpening] = useState<number>(412580.4);
  const [petrolClosing, setPetrolClosing] = useState<number>(413125.8);
  const [petrolTesting, setPetrolTesting] = useState<number>(5.0); // 5L testing
  const [petrolDirectLitres, setPetrolDirectLitres] = useState<number>(0);
  const [petrolRate, setPetrolRate] = useState<number>(petrolProduct.price);

  // Diesel (HSD) State
  const [dieselOpening, setDieselOpening] = useState<number>(893420.2);
  const [dieselClosing, setDieselClosing] = useState<number>(894670.6);
  const [dieselTesting, setDieselTesting] = useState<number>(5.0); // 5L testing
  const [dieselDirectLitres, setDieselDirectLitres] = useState<number>(0);
  const [dieselRate, setDieselRate] = useState<number>(dieselProduct.price);

  // Update rates when products load
  useEffect(() => {
    if (petrolProduct.price) setPetrolRate(petrolProduct.price);
    if (dieselProduct.price) setDieselRate(dieselProduct.price);
  }, [petrolProduct.price, dieselProduct.price]);

  // Automatic Shift Meter Rollover on Machine Change / Sales Records Load
  useEffect(() => {
    let openingMS = selectedMachineId === 'tokheim-du1' ? 412580.4 : 284190.8;
    let openingHSD = selectedMachineId === 'tokheim-du1' ? 893420.2 : 671230.5;
    let sourceText = 'Calibrated Station Baseline';
    let prevSlip: string | undefined;
    let prevDateStr: string | undefined;
    let prevStaff: string | undefined;

    if (previousMachineSale) {
      if (previousMachineSale.petrolClosing && previousMachineSale.petrolClosing > 0) {
        openingMS = previousMachineSale.petrolClosing;
      }
      if (previousMachineSale.dieselClosing && previousMachineSale.dieselClosing > 0) {
        openingHSD = previousMachineSale.dieselClosing;
      }
      sourceText = `Previous Shift Bill (${previousMachineSale.date} - ${previousMachineSale.salesmanName})`;
      prevSlip = previousMachineSale.slipNo;
      prevDateStr = previousMachineSale.date;
      prevStaff = previousMachineSale.salesmanName;
    } else {
      if (msNozzle && msNozzle.lastTotalizer > 0) {
        openingMS = msNozzle.lastTotalizer;
        sourceText = 'Dispenser Nozzle Cumulative Totalizer';
      }
      if (hsdNozzle && hsdNozzle.lastTotalizer > 0) {
        openingHSD = hsdNozzle.lastTotalizer;
        sourceText = 'Dispenser Nozzle Cumulative Totalizer';
      }
    }

    setPetrolOpening(openingMS);
    setDieselOpening(openingHSD);
    // Initialize closing meter to opening meter + estimated active sales or match opening
    setPetrolClosing(Number((openingMS + 450.0).toFixed(2)));
    setDieselClosing(Number((openingHSD + 1100.0).toFixed(2)));

    setRolloverMeta({
      source: sourceText,
      prevShiftSlip: prevSlip,
      prevDate: prevDateStr,
      prevSalesman: prevStaff,
    });
  }, [selectedMachineId, previousMachineSale, msNozzle?.lastTotalizer, hsdNozzle?.lastTotalizer]);

  // Lubricant Sales Sub-items
  const [selectedLubes, setSelectedLubes] = useState<
    { productId: string; productName: string; quantity: number; rate: number; amount: number }[]
  >([]);

  // Payment Breakdown - SMART PLUS-MINUS LOGIC
  // Grand total automatically defaults to 100% Cash. As user fills UPI, POS, or Credit, Cash is reduced.
  const [upiAmount, setUpiAmount] = useState<number>(0);
  const [posAmount, setPosAmount] = useState<number>(0);
  const [creditAmount, setCreditAmount] = useState<number>(0);

  // Customer Credit Khata link
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [vehicleNo, setVehicleNo] = useState<string>('');
  const [slipNo, setSlipNo] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  // 1. Calculate Fuel Volumes: Automatically compute (Closing Meter - Opening Meter)
  const petrolGrossLitres = useMemo(() => {
    return Number((petrolClosing - petrolOpening).toFixed(2));
  }, [petrolClosing, petrolOpening]);

  const petrolLitres = useMemo(() => {
    if (entryMode === 'direct') {
      return Math.max(0, petrolDirectLitres);
    }
    const net = petrolGrossLitres - petrolTesting;
    return Number(Math.max(0, net).toFixed(2));
  }, [entryMode, petrolDirectLitres, petrolGrossLitres, petrolTesting]);

  const petrolAmount = useMemo(() => {
    return Number((petrolLitres * petrolRate).toFixed(2));
  }, [petrolLitres, petrolRate]);

  const dieselGrossLitres = useMemo(() => {
    return Number((dieselClosing - dieselOpening).toFixed(2));
  }, [dieselClosing, dieselOpening]);

  const dieselLitres = useMemo(() => {
    if (entryMode === 'direct') {
      return Math.max(0, dieselDirectLitres);
    }
    const net = dieselGrossLitres - dieselTesting;
    return Number(Math.max(0, net).toFixed(2));
  }, [entryMode, dieselDirectLitres, dieselGrossLitres, dieselTesting]);

  const dieselAmount = useMemo(() => {
    return Number((dieselLitres * dieselRate).toFixed(2));
  }, [dieselLitres, dieselRate]);

  // 2. Lubricant Sub-total
  const lubeTotalAmount = useMemo(() => {
    return selectedLubes.reduce((sum, item) => sum + item.amount, 0);
  }, [selectedLubes]);

  // 3. Combined Grand Total
  const grandTotal = useMemo(() => {
    return Number((petrolAmount + dieselAmount + lubeTotalAmount).toFixed(2));
  }, [petrolAmount, dieselAmount, lubeTotalAmount]);

  // 4. SMART PLUS-MINUS PAYMENT CALCULATION:
  // Grand Total initially shows 100% in Cash. Subtract UPI, POS, and Credit.
  const cashAmount = useMemo(() => {
    const nonCash = (upiAmount || 0) + (posAmount || 0) + (creditAmount || 0);
    const balance = grandTotal - nonCash;
    return Number(Math.max(0, balance).toFixed(2));
  }, [grandTotal, upiAmount, posAmount, creditAmount]);

  const totalCollected = useMemo(() => {
    return Number((cashAmount + upiAmount + posAmount + creditAmount).toFixed(2));
  }, [cashAmount, upiAmount, posAmount, creditAmount]);

  // 5. Diesel Tank Strict Guard Verification
  // Check if current diesel stock exceeds 20,000L or if remaining would be affected
  const isDieselOver20000 = dieselTank.currentStockLitres > 20000;
  const isDieselNearLimit = dieselTank.currentStockLitres >= 19000;

  // Add Lube Item
  const handleAddLube = (prodId: string) => {
    const prod = lubeProducts.find((p) => p.id === prodId);
    if (!prod) return;
    const existingIndex = selectedLubes.findIndex((l) => l.productId === prodId);
    if (existingIndex > -1) {
      const copy = [...selectedLubes];
      copy[existingIndex].quantity += 1;
      copy[existingIndex].amount = copy[existingIndex].quantity * copy[existingIndex].rate;
      setSelectedLubes(copy);
    } else {
      setSelectedLubes([
        ...selectedLubes,
        {
          productId: prod.id,
          productName: prod.name,
          quantity: 1,
          rate: prod.price,
          amount: prod.price,
        },
      ]);
    }
  };

  const handleRemoveLube = (index: number) => {
    setSelectedLubes((prev) => prev.filter((_, i) => i !== index));
  };

  // Submit Sale Form to Firebase Firestore
  const handleSubmitSale = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (grandTotal <= 0) {
      setErrorMessage('Total sale amount must be greater than zero.');
      return;
    }

    if (creditAmount > 0 && !selectedCustomerId) {
      setErrorMessage('Khata Customer must be selected when Credit (Udhaar) amount is greater than zero.');
      return;
    }

    // Check Diesel stock
    if (dieselLitres > dieselTank.currentStockLitres) {
      setErrorMessage(
        `Insufficient Diesel (HSD) stock in Tank 2. Available: ${dieselTank.currentStockLitres} L, Requested: ${dieselLitres} L`
      );
      return;
    }

    const machineMeta = PUMP_CONFIG.dispensers.find((d) => d.id === selectedMachineId);
    const chosenCustomer = customers.find((c) => c.id === selectedCustomerId);

    const salePayload: Omit<MachineSaleRecord, 'id'> = {
      machineId: selectedMachineId,
      machineName: machineMeta?.name || 'Dispenser',
      date: saleDate,
      shiftId: 'shift-current',
      salesmanId: currentStaff.id,
      salesmanName: currentStaff.name,
      entryMode,

      // Petrol
      petrolOpening,
      petrolClosing: entryMode === 'meter' ? petrolClosing : 0,
      petrolTesting: entryMode === 'meter' ? petrolTesting : 0,
      petrolLitres,
      petrolRate,
      petrolAmount,

      // Diesel
      dieselOpening,
      dieselClosing: entryMode === 'meter' ? dieselClosing : 0,
      dieselTesting: entryMode === 'meter' ? dieselTesting : 0,
      dieselLitres,
      dieselRate,
      dieselAmount,

      // Lubes
      lubeAmount: lubeTotalAmount,
      lubeDetails: selectedLubes,

      // Grand Total & Smart Payment
      grossTotal: grandTotal,
      cashAmount,
      upiAmount,
      posAmount,
      creditAmount,

      // Khata link
      customerId: selectedCustomerId || undefined,
      customerName: chosenCustomer?.name,
      customerPhone: chosenCustomer?.phone,
      vehicleNo: vehicleNo || undefined,
      slipNo: slipNo || undefined,

      notes: notes || undefined,
      createdAt: new Date().toISOString(),
    };

    try {
      setIsSubmitting(true);
      await submitMachineSale(salePayload);
      setSuccessMessage(
        `Sale recorded successfully! Grand Total: ₹${grandTotal.toLocaleString()} saved to Firestore and updated Tank Stock & Customer Khata.`
      );

      // Reset payment amounts
      setUpiAmount(0);
      setPosAmount(0);
      setCreditAmount(0);
      setSelectedCustomerId('');
      setVehicleNo('');
      setSlipNo('');
      setNotes('');
      setSelectedLubes([]);

      if (onSaleSaved) onSaleSaved();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error submitting machine sale';
      setErrorMessage(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* STRICT DIESEL TANK GUARD BANNER */}
      {isDieselOver20000 && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border-2 border-rose-500 text-rose-300 flex items-start gap-3 shadow-lg">
          <AlertTriangle className="w-6 h-6 shrink-0 mt-0.5 text-rose-400 animate-bounce" />
          <div>
            <h3 className="font-black text-sm uppercase tracking-wider text-rose-200">
              STRICT GUARD VIOLATION: Diesel (HSD) Tank Limit Exceeded
            </h3>
            <p className="text-xs mt-1 text-rose-300">
              Current Diesel tank stock is <strong>{dieselTank.currentStockLitres.toLocaleString()} Litres</strong>, which
              exceeds the strict maximum capacity of <strong>20,000 Litres</strong> for Tank 2! Please verify dip readings or decantation logs immediately.
            </p>
          </div>
        </div>
      )}

      {isDieselNearLimit && !isDieselOver20000 && (
        <div className="p-3.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-200 text-xs flex items-center gap-2.5">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
          <span>
            <strong>Diesel Tank Guard Alert:</strong> Tank 2 is at {dieselTank.currentStockLitres.toLocaleString()} L / 20,000 L ({(dieselTank.currentStockLitres / 200).toFixed(1)}% full).
          </span>
        </div>
      )}

      {/* Notifications */}
      {successMessage && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs sm:text-sm flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button
            onClick={() => setSuccessMessage('')}
            className="text-emerald-400 hover:text-emerald-200 text-xs font-bold underline ml-4"
          >
            Dismiss
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs sm:text-sm flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            onClick={() => setErrorMessage('')}
            className="text-rose-400 hover:text-rose-200 text-xs font-bold underline ml-4"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Unified Sale Form */}
      <form onSubmit={handleSubmitSale} className="space-y-6">
        {/* Machine Selector & Entry Mode Header */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                DUAL DISPENSER UNIT CONTROLLER
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2 mt-0.5">
                Unified Machine Sales Entry
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Enter Motor Spirit (Petrol) & High Speed Diesel (HSD) simultaneously with 5L Weights & Measures testing deduction.
              </p>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              {/* Date Input */}
              <input
                type="date"
                value={saleDate}
                onChange={(e) => setSaleDate(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              />

              {/* Mode Toggle: Meter vs Direct Litres */}
              <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setEntryMode('meter')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    entryMode === 'meter'
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Meter Reading Mode
                </button>
                <button
                  type="button"
                  onClick={() => setEntryMode('direct')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    entryMode === 'direct'
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Direct Litres Mode
                </button>
              </div>
            </div>
          </div>

          {/* Machine Selection Radio Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5">
            {PUMP_CONFIG.dispensers.map((dispenser) => {
              const isSelected = selectedMachineId === dispenser.id;
              return (
                <button
                  key={dispenser.id}
                  type="button"
                  onClick={() => setSelectedMachineId(dispenser.id)}
                  className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden flex items-center justify-between ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-400 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400'
                      : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs px-2 py-0.5 rounded font-bold bg-slate-800 text-amber-300">
                        {dispenser.code}
                      </span>
                      <h4 className="font-bold text-sm sm:text-base text-white">{dispenser.name}</h4>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Model: {dispenser.model} • Nozzle 1 (Petrol) & Nozzle 2 (Diesel)
                    </p>
                  </div>
                  <div
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      isSelected
                        ? 'border-amber-400 bg-amber-400 text-slate-950'
                        : 'border-slate-700'
                    }`}
                  >
                    {isSelected && <CheckCircle2 className="w-4 h-4 stroke-[3]" />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* SHIFT METER AUTO-ROLLOVER BANNER */}
        <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <span className="flex h-3 w-3 relative shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
            </span>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-mono font-bold text-xs uppercase text-amber-400">
                  Shift Meter Auto-Rollover Active
                </span>
                <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                  {rolloverMeta.source}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Previous shift closing meter has automatically rolled over into this shift's opening meter.
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right text-xs">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">Attendant In-Charge</span>
            <span className="font-bold text-white flex items-center gap-1.5 mt-0.5">
              <User className="w-3.5 h-3.5 text-amber-400" />
              {currentStaff.name} ({currentStaff.role})
            </span>
          </div>
        </div>

        {/* Simultaneous MS (Petrol) & HSD (Diesel) Entry Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 1. MOTOR SPIRIT (PETROL - MS) CARD */}
          <div className="bg-slate-900 border border-emerald-900/40 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <Fuel className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Motor Spirit (Petrol / MS)</h3>
                  <p className="text-[11px] text-slate-400">
                    Tank 1 Live Stock: {petrolTank.currentStockLitres.toLocaleString()} L
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase font-mono text-slate-400">Rate / L</span>
                <p className="font-mono font-bold text-emerald-400 text-sm sm:text-base">
                  ₹{petrolRate.toFixed(2)}
                </p>
              </div>
            </div>

            {/* Input Form Fields */}
            {entryMode === 'meter' ? (
              <div className="mt-4 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-mono text-slate-400 uppercase">
                        Opening Meter
                      </label>
                      <span className="text-[9px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1 py-0.5 rounded font-bold">
                        Auto-Rolled
                      </span>
                    </div>
                    <input
                      type="number"
                      step="0.01"
                      value={petrolOpening}
                      onChange={(e) => setPetrolOpening(parseFloat(e.target.value) || 0)}
                      className="w-full font-mono font-bold text-sm bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                      Closing Meter
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={petrolClosing}
                      onChange={(e) => setPetrolClosing(parseFloat(e.target.value) || 0)}
                      className="w-full font-mono font-bold text-sm bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                      5L Testing Deduct
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={petrolTesting}
                      onChange={(e) => setPetrolTesting(parseFloat(e.target.value) || 0)}
                      className="w-full font-mono font-bold text-sm bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-amber-300 focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>

                {/* Explicit Closing - Opening Calculation Breakdown */}
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 text-[11px] font-mono space-y-1">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Sales Calculation Formula:</span>
                    <span className="text-amber-400 font-bold">Closing Meter - Opening Meter</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-200">
                    <span>Meter Difference (Gross):</span>
                    <span className={`font-bold ${petrolGrossLitres < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {petrolClosing.toFixed(2)} - {petrolOpening.toFixed(2)} = {petrolGrossLitres.toFixed(2)} L
                    </span>
                  </div>
                  {petrolTesting > 0 && (
                    <div className="flex items-center justify-between text-amber-400/90 text-[10px]">
                      <span>Less 5L W&M Testing Deduction:</span>
                      <span>- {petrolTesting.toFixed(1)} L</span>
                    </div>
                  )}
                  {petrolGrossLitres < 0 && (
                    <div className="text-rose-400 text-[10px] font-sans font-semibold pt-1">
                      ⚠️ Warning: Closing Meter is less than Opening Meter!
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="mt-4">
                <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                  Direct Litres Sold
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={petrolDirectLitres || ''}
                  placeholder="0.00"
                  onChange={(e) => setPetrolDirectLitres(parseFloat(e.target.value) || 0)}
                  className="w-full font-mono font-bold text-base bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            )}

            {/* Petrol Output Totals */}
            <div className="mt-5 p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400">Net Petrol Sold</span>
                <p className="text-lg font-mono font-black text-white">{petrolLitres.toFixed(2)} L</p>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-mono uppercase text-slate-400">Petrol Amount</span>
                <p className="text-lg font-mono font-black text-emerald-400">₹{petrolAmount.toLocaleString()}</p>
              </div>
            </div>
          </div>

          {/* 2. HIGH SPEED DIESEL (HSD) CARD */}
          <div className="bg-slate-900 border border-blue-900/40 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-blue-500/15 text-blue-400 border border-blue-500/30">
                  <Droplet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">High Speed Diesel (HSD)</h3>
                  <p className="text-[11px] text-slate-400">
                    Tank 2 Live Stock: {dieselTank.currentStockLitres.toLocaleString()} L / 20,000 L
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase font-mono text-slate-400">Rate / L</span>
                <p className="font-mono font-bold text-blue-400 text-sm sm:text-base">
                  ₹{dieselRate.toFixed(2)}
                </p>
              </div>
            </div>

            {/* Input Form Fields */}
            {entryMode === 'meter' ? (
              <div className="mt-4 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-mono text-slate-400 uppercase">
                        Opening Meter
                      </label>
                      <span className="text-[9px] font-mono bg-blue-500/20 text-blue-300 border border-blue-500/30 px-1 py-0.5 rounded font-bold">
                        Auto-Rolled
                      </span>
                    </div>
                    <input
                      type="number"
                      step="0.01"
                      value={dieselOpening}
                      onChange={(e) => setDieselOpening(parseFloat(e.target.value) || 0)}
                      className="w-full font-mono font-bold text-sm bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                      Closing Meter
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={dieselClosing}
                      onChange={(e) => setDieselClosing(parseFloat(e.target.value) || 0)}
                      className="w-full font-mono font-bold text-sm bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                      5L Testing Deduct
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={dieselTesting}
                      onChange={(e) => setDieselTesting(parseFloat(e.target.value) || 0)}
                      className="w-full font-mono font-bold text-sm bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-amber-300 focus:outline-none focus:border-blue-400"
                    />
                  </div>
                </div>

                {/* Explicit Closing - Opening Calculation Breakdown */}
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 text-[11px] font-mono space-y-1">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Sales Calculation Formula:</span>
                    <span className="text-amber-400 font-bold">Closing Meter - Opening Meter</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-200">
                    <span>Meter Difference (Gross):</span>
                    <span className={`font-bold ${dieselGrossLitres < 0 ? 'text-rose-400' : 'text-blue-400'}`}>
                      {dieselClosing.toFixed(2)} - {dieselOpening.toFixed(2)} = {dieselGrossLitres.toFixed(2)} L
                    </span>
                  </div>
                  {dieselTesting > 0 && (
                    <div className="flex items-center justify-between text-amber-400/90 text-[10px]">
                      <span>Less 5L W&M Testing Deduction:</span>
                      <span>- {dieselTesting.toFixed(1)} L</span>
                    </div>
                  )}
                  {dieselGrossLitres < 0 && (
                    <div className="text-rose-400 text-[10px] font-sans font-semibold pt-1">
                      ⚠️ Warning: Closing Meter is less than Opening Meter!
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="mt-4">
                <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                  Direct Litres Sold
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={dieselDirectLitres || ''}
                  placeholder="0.00"
                  onChange={(e) => setDieselDirectLitres(parseFloat(e.target.value) || 0)}
                  className="w-full font-mono font-bold text-base bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-blue-400"
                />
              </div>
            )}

            {/* Diesel Output Totals */}
            <div className="mt-5 p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400">Net Diesel Sold</span>
                <p className="text-lg font-mono font-black text-white">{dieselLitres.toFixed(2)} L</p>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-mono uppercase text-slate-400">Diesel Amount</span>
                <p className="text-lg font-mono font-black text-blue-400">₹{dieselAmount.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>

        {/* 3. LUBRICANT / ENGINE OIL SALES SUB-TOTALS LINKED TO INVENTORY */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
                <Package className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-base">Lubricants & Packaged Engine Oil Sales</h3>
                <p className="text-xs text-slate-400">
                  Select lubricants sold during shift to link with stock inventory.
                </p>
              </div>
            </div>

            {/* Quick add dropdown */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                onChange={(e) => {
                  if (e.target.value) {
                    handleAddLube(e.target.value);
                    e.target.value = '';
                  }
                }}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400 w-full sm:w-64"
                defaultValue=""
              >
                <option value="" disabled>
                  + Add Lubricant / 2T / 4T / Coolant...
                </option>
                {lubeProducts.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} (₹{p.price} / {p.unit}) - In Stock: {p.stockQuantity}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Selected Lube List */}
          {selectedLubes.length > 0 ? (
            <div className="mt-4 space-y-2">
              {selectedLubes.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-medium text-white">{item.productName}</span>
                    <span className="font-mono text-slate-400">@ ₹{item.rate}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400">Qty:</span>
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => {
                          const q = parseInt(e.target.value) || 1;
                          const copy = [...selectedLubes];
                          copy[idx].quantity = q;
                          copy[idx].amount = q * copy[idx].rate;
                          setSelectedLubes(copy);
                        }}
                        className="w-16 font-mono text-center bg-slate-900 border border-slate-700 rounded-lg py-1 text-white"
                      />
                    </div>
                    <span className="font-mono font-bold text-amber-400 min-w-16 text-right">
                      ₹{item.amount.toLocaleString()}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRemoveLube(idx)}
                      className="text-rose-400 hover:text-rose-300 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
              <div className="text-right pt-2 font-mono text-xs text-slate-300">
                Lubricants Subtotal:{' '}
                <strong className="text-amber-400 font-bold text-sm">
                  ₹{lubeTotalAmount.toLocaleString()}
                </strong>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic mt-3">
              No lubricants added to this shift bill yet. Select from the dropdown above if any engine oil was sold.
            </p>
          )}
        </div>

        {/* 4. SMART PLUS-MINUS PAYMENT DEDUCTION MODULE */}
        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <Calculator className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-white text-base sm:text-lg">
                  Smart Payment Deduction (Plus-Minus Logic)
                </h3>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Grand Total initially defaults to 100% Cash. Entering UPI, POS, or Credit auto-reduces Cash in real-time.
              </p>
            </div>

            {/* Grand Total Highlight Badge */}
            <div className="bg-slate-950 px-4 py-2.5 rounded-2xl border border-amber-400/40 text-right w-full sm:w-auto">
              <span className="text-[10px] font-mono uppercase text-slate-400">Combined Grand Total</span>
              <p className="text-xl sm:text-2xl font-mono font-black text-amber-400">
                ₹{grandTotal.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Payment Fields Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-5">
            {/* 1. AUTO CALCULATED CASH FIELD */}
            <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 relative">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                  Cash (Auto-Balanced)
                </label>
                <span className="text-[10px] font-mono text-emerald-400 font-bold">100% - Other</span>
              </div>
              <div className="text-2xl font-mono font-black text-white py-1">
                ₹{cashAmount.toLocaleString()}
              </div>
              <p className="text-[10px] text-emerald-400/80 mt-1">
                Net remaining physical cash to collect in drawer
              </p>
            </div>

            {/* 2. UPI FIELD */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                UPI / QR Pay (PhonePe / GPay)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-mono font-bold">₹</span>
                <input
                  type="number"
                  step="1"
                  min="0"
                  value={upiAmount || ''}
                  placeholder="0"
                  onChange={(e) => setUpiAmount(parseFloat(e.target.value) || 0)}
                  className="w-full pl-7 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl font-mono font-bold text-white text-base focus:outline-none focus:border-amber-400"
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-1">Deducts immediately from cash</p>
            </div>

            {/* 3. POS CARD SWIPE FIELD */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                POS EDC Card Swipe
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-mono font-bold">₹</span>
                <input
                  type="number"
                  step="1"
                  min="0"
                  value={posAmount || ''}
                  placeholder="0"
                  onChange={(e) => setPosAmount(parseFloat(e.target.value) || 0)}
                  className="w-full pl-7 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl font-mono font-bold text-white text-base focus:outline-none focus:border-amber-400"
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-1">Debit / Credit card receipts</p>
            </div>

            {/* 4. CREDIT (UDHAAR) FIELD */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/40">
              <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider mb-1.5">
                Credit (Udhaar Khata)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-amber-400 font-mono font-bold">₹</span>
                <input
                  type="number"
                  step="1"
                  min="0"
                  value={creditAmount || ''}
                  placeholder="0"
                  onChange={(e) => setCreditAmount(parseFloat(e.target.value) || 0)}
                  className="w-full pl-7 pr-3 py-2 bg-slate-900 border border-amber-500/50 rounded-xl font-mono font-bold text-amber-300 text-base focus:outline-none focus:border-amber-400"
                />
              </div>
              <p className="text-[10px] text-amber-400/80 mt-1">Prompts Khata selection below</p>
            </div>
          </div>

          {/* Prompt Khata Customer If Credit > 0 */}
          {creditAmount > 0 && (
            <div className="mt-5 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-3">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-amber-400" />
                <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Select Khata Credit Customer (Required for Udhaar ₹{creditAmount.toLocaleString()})
                </h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                    Customer Account *
                  </label>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => {
                      setSelectedCustomerId(e.target.value);
                      const cust = customers.find((c) => c.id === e.target.value);
                      if (cust?.vehicleNumbers) {
                        setVehicleNo(cust.vehicleNumbers.split(',')[0].trim());
                      }
                    }}
                    required
                    className="w-full bg-slate-950 border border-amber-500/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="">-- Choose Credit Customer --</option>
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} (Due: ₹{c.currentBalance.toLocaleString()} / Limit: ₹{c.creditLimit.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                    Vehicle Number (Tractor / Truck / Car)
                  </label>
                  <input
                    type="text"
                    value={vehicleNo}
                    placeholder="e.g. PB-10-AB-4455"
                    onChange={(e) => setVehicleNo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                    Credit Memo / Slip No.
                  </label>
                  <input
                    type="text"
                    value={slipNo}
                    placeholder="e.g. SLIP-1042"
                    onChange={(e) => setSlipNo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Notes */}
          <div className="mt-4">
            <input
              type="text"
              value={notes}
              placeholder="Remarks / Shift handover notes (optional)..."
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Submission bar */}
          <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-400">
              Total Breakdown:{' '}
              <span className="font-mono font-bold text-slate-200">
                ₹{totalCollected.toLocaleString()}
              </span>{' '}
              {totalCollected === grandTotal ? (
                <span className="text-emerald-400 font-bold ml-1">✓ Balanced with Grand Total</span>
              ) : (
                <span className="text-rose-400 font-bold ml-1">⚠ Difference Detected</span>
              )}
            </div>

            <button
              type="submit"
              disabled={isSubmitting || grandTotal <= 0}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm tracking-wide shadow-xl shadow-amber-500/20 transition active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <span>Writing to Cloud Firestore...</span>
              ) : (
                <>
                  <Receipt className="w-4 h-4" />
                  <span>Submit Machine Shift Sale Bill</span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
