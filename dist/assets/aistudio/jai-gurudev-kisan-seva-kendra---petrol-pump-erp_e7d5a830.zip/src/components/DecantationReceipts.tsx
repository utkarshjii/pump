import React, { useState } from 'react';
import {
  Truck,
  FileCheck,
  AlertTriangle,
  Plus,
  CheckCircle2,
  Calendar,
  Layers,
  Thermometer,
} from 'lucide-react';
import { TankerReceipt, Tank, Staff } from '../types/pump';
import { addTankerReceipt } from '../services/firestoreService';

interface DecantationReceiptsProps {
  receipts: TankerReceipt[];
  tanks: Tank[];
  currentStaff: Staff;
}

export const DecantationReceipts: React.FC<DecantationReceiptsProps> = ({
  receipts,
  tanks,
  currentStaff,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [invoiceNo, setInvoiceNo] = useState('');
  const [tankerNo, setTankerNo] = useState('');
  const [company, setCompany] = useState<'IOCL' | 'BPCL' | 'HPCL' | 'OTHER'>('IOCL');
  const [fuelType, setFuelType] = useState<'MS' | 'HSD'>('HSD');
  const [invoiceLitres, setInvoiceLitres] = useState<number>(12000);
  const [preDipCm, setPreDipCm] = useState<number>(60.0);
  const [postDipCm, setPostDipCm] = useState<number>(185.0);
  const [receivedLitres, setReceivedLitres] = useState<number>(11980);
  const [density15C, setDensity15C] = useState<number>(828.5); // Standard HSD density
  const [waterTestResult, setWaterTestResult] = useState<'NEGATIVE' | 'POSITIVE'>('NEGATIVE');
  const [notes, setNotes] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const dieselTank = tanks.find((t) => t.fuelType === 'HSD') || { currentStockLitres: 14800, capacityLitres: 20000 };

  const handleAddReceipt = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setNotification(null);

    // Diesel Strict Guard check
    if (fuelType === 'HSD') {
      const projected = (dieselTank.currentStockLitres || 0) + receivedLitres;
      if (projected > 20000) {
        setNotification({
          type: 'error',
          text: `STRICT GUARD VIOLATION: Decanting ${receivedLitres.toLocaleString()} L will raise Diesel Tank 2 stock to ${projected.toLocaleString()} L, which EXCEEDS the 20,000 Litres maximum limit!`,
        });
        setIsSubmitting(false);
        return;
      }
    }

    try {
      await addTankerReceipt({
        date: new Date().toISOString().split('T')[0],
        invoiceNo,
        tankerNo,
        company,
        fuelType,
        tankId: fuelType === 'MS' ? 'tank-1-petrol' : 'tank-2-diesel',
        invoiceLitres,
        preDipCm,
        postDipCm,
        receivedLitres,
        density15C,
        waterTestResult,
        receivedBy: currentStaff.name,
        notes,
        createdAt: new Date().toISOString(),
      });
      setNotification({
        type: 'success',
        text: `Tanker decantation receipt #${invoiceNo} recorded and stock added to Firestore tank!`,
      });
      setShowModal(false);
      setInvoiceNo('');
      setTankerNo('');
      setNotes('');
    } catch {
      setNotification({ type: 'error', text: 'Failed to record tanker receipt.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner & Decantation Action */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <Truck className="w-5 h-5" />
            </span>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                STOCK INWARD REGISTER
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Tanker Decantation & Quality Checks
              </h2>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Challan invoice logs, pre/post dip measurement, density test at 15°C, and water paste inspection.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowModal(true)}
          className="px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wide shadow-lg shadow-amber-500/20 transition flex items-center gap-2"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Record New Decantation</span>
        </button>
      </div>

      {notification && (
        <div
          className={`p-4 rounded-2xl text-xs flex items-center justify-between shadow-lg ${
            notification.type === 'success'
              ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
              : 'bg-rose-500/20 border-2 border-rose-500 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold underline text-xs ml-4">
            Dismiss
          </button>
        </div>
      )}

      {/* Receipts Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="pb-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-white text-base">Decantation History & Density Logs</h3>
          <span className="text-xs text-slate-400">{receipts.length} Tankers Received</span>
        </div>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                <th className="pb-3 pl-2">Date & Challan</th>
                <th className="pb-3">Tanker No.</th>
                <th className="pb-3">Company</th>
                <th className="pb-3">Fuel</th>
                <th className="pb-3 text-right">Invoice Qty</th>
                <th className="pb-3 text-right">Received Qty</th>
                <th className="pb-3 text-center">Shortage / Gain</th>
                <th className="pb-3 text-center">Density @ 15°C</th>
                <th className="pb-3 text-center">Water Test</th>
                <th className="pb-3 pr-2 text-right">Received By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {receipts.map((r, idx) => {
                const diff = r.receivedLitres - r.invoiceLitres;
                return (
                  <tr key={r.id || idx} className="hover:bg-slate-800/30 transition">
                    <td className="py-3 pl-2 font-mono">
                      <span className="font-bold text-white">{r.invoiceNo}</span>
                      <p className="text-[10px] text-slate-400">{r.date}</p>
                    </td>
                    <td className="py-3 font-mono font-bold text-slate-300">{r.tankerNo}</td>
                    <td className="py-3 font-semibold text-slate-300">{r.company}</td>
                    <td className="py-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          r.fuelType === 'MS'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-blue-500/20 text-blue-300'
                        }`}
                      >
                        {r.fuelType === 'MS' ? 'Petrol' : 'Diesel'}
                      </span>
                    </td>
                    <td className="py-3 text-right font-mono text-slate-300">
                      {r.invoiceLitres.toLocaleString()} L
                    </td>
                    <td className="py-3 text-right font-mono font-bold text-white">
                      {r.receivedLitres.toLocaleString()} L
                    </td>
                    <td className="py-3 text-center font-mono">
                      <span
                        className={`font-bold ${
                          diff < 0 ? 'text-rose-400' : diff > 0 ? 'text-emerald-400' : 'text-slate-400'
                        }`}
                      >
                        {diff > 0 ? `+${diff}` : diff} L
                      </span>
                    </td>
                    <td className="py-3 text-center font-mono text-slate-200">
                      {r.density15C} kg/m³
                    </td>
                    <td className="py-3 text-center">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                          r.waterTestResult === 'NEGATIVE'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-rose-500/20 text-rose-400'
                        }`}
                      >
                        {r.waterTestResult}
                      </span>
                    </td>
                    <td className="py-3 pr-2 text-right text-slate-300">{r.receivedBy}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {receipts.length === 0 && (
            <div className="h-48 flex items-center justify-center text-xs text-slate-500 italic">
              No tanker decantations recorded yet. Click above to log invoice and dip gauge.
            </div>
          )}
        </div>
      </div>

      {/* MODAL: RECORD DECANTATION */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-black text-white mb-1">Record Tanker Decantation</h3>
            <p className="text-xs text-slate-400 mb-4">
              Enter OMC invoice details, density, and pre/post tank dip readings.
            </p>

            <form onSubmit={handleAddReceipt} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Invoice / Challan No. *</label>
                  <input
                    type="text"
                    required
                    value={invoiceNo}
                    onChange={(e) => setInvoiceNo(e.target.value)}
                    placeholder="e.g. IOCL-88421"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Tanker Truck No. *</label>
                  <input
                    type="text"
                    required
                    value={tankerNo}
                    onChange={(e) => setTankerNo(e.target.value)}
                    placeholder="e.g. PB-08-AU-9911"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Company (OMC)</label>
                  <select
                    value={company}
                    onChange={(e) => setCompany(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="IOCL">Indian Oil (IOCL)</option>
                    <option value="BPCL">Bharat Petroleum (BPCL)</option>
                    <option value="HPCL">Hindustan Petroleum (HPCL)</option>
                    <option value="OTHER">Other OMC</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Fuel Product</label>
                  <select
                    value={fuelType}
                    onChange={(e) => setFuelType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="HSD">High Speed Diesel (HSD)</option>
                    <option value="MS">Motor Spirit (Petrol / MS)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Invoice Billed Litres *</label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={invoiceLitres}
                    onChange={(e) => setInvoiceLitres(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Received Litres (Dip Chart) *</label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={receivedLitres}
                    onChange={(e) => setReceivedLitres(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Pre-Dip Level (cm)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={preDipCm}
                    onChange={(e) => setPreDipCm(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Post-Dip Level (cm)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={postDipCm}
                    onChange={(e) => setPostDipCm(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Density @ 15°C (kg/m³)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={density15C}
                    onChange={(e) => setDensity15C(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Water Test Result</label>
                  <select
                    value={waterTestResult}
                    onChange={(e) => setWaterTestResult(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="NEGATIVE">Negative (No Water Passed)</option>
                    <option value="POSITIVE">Positive (Water Detected)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Seal Numbers & Notes</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Security seal numbers / driver name..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Save Decantation & Update Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
