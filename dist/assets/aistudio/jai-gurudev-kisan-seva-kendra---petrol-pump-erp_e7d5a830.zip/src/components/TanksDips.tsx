import React, { useState } from 'react';
import {
  Fuel,
  Droplet,
  Gauge,
  AlertTriangle,
  Plus,
  Scale,
  Calendar,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Tank, Nozzle, DailyDip, Staff } from '../types/pump';
import { addDailyDip, updateNozzle } from '../services/firestoreService';

interface TanksDipsProps {
  tanks: Tank[];
  nozzles: Nozzle[];
  dailyDips: DailyDip[];
  currentStaff: Staff;
}

export const TanksDips: React.FC<TanksDipsProps> = ({
  tanks,
  nozzles,
  dailyDips,
  currentStaff,
}) => {
  const [selectedTankForDip, setSelectedTankForDip] = useState<number>(2); // Default Diesel
  const [timeSlot, setTimeSlot] = useState<'MORNING' | 'EVENING'>('MORNING');
  const [dipCm, setDipCm] = useState<number>(168.0);
  const [physicalLitres, setPhysicalLitres] = useState<number>(14800);
  const [bookStockLitres, setBookStockLitres] = useState<number>(14820);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Calibration edit modal/state
  const [editingNozzle, setEditingNozzle] = useState<Nozzle | null>(null);
  const [newTotalizer, setNewTotalizer] = useState<number>(0);

  const dieselTank = tanks.find((t) => t.fuelType === 'HSD') || {
    capacityLitres: 20000,
    currentStockLitres: 14800,
    currentDipCm: 168.0,
    fuelName: 'High Speed Diesel (HSD)',
  };

  const petrolTank = tanks.find((t) => t.fuelType === 'MS') || {
    capacityLitres: 15000,
    currentStockLitres: 11250,
    currentDipCm: 142.5,
    fuelName: 'Motor Spirit (Petrol / MS)',
  };

  const isDieselExceeded = (dieselTank.currentStockLitres || 0) > 20000;
  const isDieselWarning = (dieselTank.currentStockLitres || 0) >= 19000;

  // Simple dip conversion calculation helper (approx 88 L per cm for 20k L tank)
  const handleDipCmChange = (cm: number) => {
    setDipCm(cm);
    const est = selectedTankForDip === 2 ? Math.round(cm * 88.1) : Math.round(cm * 79.2);
    setPhysicalLitres(est);
  };

  const varianceLitres = physicalLitres - bookStockLitres;

  const handleRecordDip = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setStatusMsg(null);

    try {
      await addDailyDip({
        date: new Date().toISOString().split('T')[0],
        timeSlot,
        tankNumber: selectedTankForDip,
        fuelType: selectedTankForDip === 1 ? 'MS' : 'HSD',
        dipCm,
        physicalLitres,
        bookStockLitres,
        varianceLitres,
        auditedBy: currentStaff.name,
        createdAt: new Date().toISOString(),
      });
      setStatusMsg({
        type: 'success',
        text: `Daily Dip Audit recorded successfully for Tank ${selectedTankForDip} (${timeSlot})!`,
      });
    } catch {
      setStatusMsg({ type: 'error', text: 'Failed to record daily dip audit.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveCalibration = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingNozzle) return;
    try {
      await updateNozzle(editingNozzle.id, {
        lastTotalizer: newTotalizer,
        calibrationDate: new Date().toISOString().split('T')[0],
      });
      setStatusMsg({
        type: 'success',
        text: `Nozzle ${editingNozzle.nozzleNumber} totalizer calibrated to ${newTotalizer}!`,
      });
      setEditingNozzle(null);
    } catch {
      setStatusMsg({ type: 'error', text: 'Failed to update nozzle calibration.' });
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* STRICT DIESEL GUARD ALERT */}
      {isDieselExceeded && (
        <div className="p-4 rounded-3xl bg-rose-500/20 border-2 border-rose-500 text-rose-200 flex items-start gap-3 shadow-xl">
          <AlertTriangle className="w-6 h-6 text-rose-400 shrink-0 animate-bounce mt-0.5" />
          <div>
            <h3 className="font-black text-sm uppercase tracking-wider text-white">
              STRICT GUARD VIOLATION: Diesel (HSD) Tank 2 Capacity Exceeded!
            </h3>
            <p className="text-xs text-rose-200 mt-1">
              Current recorded Diesel stock is <strong>{dieselTank.currentStockLitres.toLocaleString()} L</strong>, which breaches the strict limit of <strong>20,000 Litres</strong>. Decantation or dispensing calibration audit required!
            </p>
          </div>
        </div>
      )}

      {statusMsg && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between shadow-lg ${
            statusMsg.type === 'success'
              ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
              : 'bg-rose-500/15 border border-rose-500/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{statusMsg.text}</span>
          </div>
          <button onClick={() => setStatusMsg(null)} className="font-bold underline text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* Visual Tank Telemetry Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* TANK 1: PETROL */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                <Fuel className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-bold">
                  Underground Tank 1
                </span>
                <h3 className="text-lg font-black text-white">{petrolTank.fuelName}</h3>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Dip Level</span>
              <p className="text-lg font-mono font-black text-emerald-400">{petrolTank.currentDipCm} cm</p>
            </div>
          </div>

          {/* Progress Bar & Volume Gauge */}
          <div className="mt-5 space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Current Stock:</span>
              <span className="text-white font-bold">
                {petrolTank.currentStockLitres.toLocaleString()} L / {petrolTank.capacityLitres.toLocaleString()} L
              </span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-4 p-0.5 border border-slate-800 overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-600 to-emerald-400 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, ((petrolTank.currentStockLitres || 0) / petrolTank.capacityLitres) * 100)}%`,
                }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-500">
              <span>0 L</span>
              <span>{(((petrolTank.currentStockLitres || 0) / petrolTank.capacityLitres) * 100).toFixed(1)}% Full</span>
              <span>Max: 15,000 L</span>
            </div>
          </div>
        </div>

        {/* TANK 2: DIESEL (WITH 20K L GUARD) */}
        <div
          className={`bg-slate-900 border rounded-3xl p-6 shadow-xl relative overflow-hidden transition-all ${
            isDieselExceeded
              ? 'border-rose-500 ring-2 ring-rose-500/50'
              : isDieselWarning
              ? 'border-amber-500/50'
              : 'border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-blue-500/15 text-blue-400 border border-blue-500/30">
                <Droplet className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-blue-400 font-bold">
                    Underground Tank 2
                  </span>
                  <span className="text-[9px] font-mono font-black bg-rose-500/20 text-rose-300 border border-rose-500/30 px-1.5 py-0.5 rounded">
                    STRICT GUARD: 20k L MAX
                  </span>
                </div>
                <h3 className="text-lg font-black text-white">{dieselTank.fuelName}</h3>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Dip Level</span>
              <p className="text-lg font-mono font-black text-blue-400">{dieselTank.currentDipCm} cm</p>
            </div>
          </div>

          {/* Progress Bar & Volume Gauge */}
          <div className="mt-5 space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Current Stock:</span>
              <span
                className={`font-bold ${
                  isDieselExceeded ? 'text-rose-400 font-black animate-pulse' : 'text-white'
                }`}
              >
                {dieselTank.currentStockLitres.toLocaleString()} L / 20,000 L
              </span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-4 p-0.5 border border-slate-800 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  isDieselExceeded
                    ? 'bg-rose-500'
                    : isDieselWarning
                    ? 'bg-gradient-to-r from-amber-500 to-rose-400'
                    : 'bg-gradient-to-r from-blue-600 to-blue-400'
                }`}
                style={{
                  width: `${Math.min(100, ((dieselTank.currentStockLitres || 0) / 20000) * 100)}%`,
                }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-500">
              <span>0 L</span>
              <span>{(((dieselTank.currentStockLitres || 0) / 20000) * 100).toFixed(1)}% Capacity</span>
              <span className="text-amber-400 font-bold">Strict Max: 20,000 L</span>
            </div>
          </div>
        </div>
      </div>

      {/* Nozzles Totalizer Calibrations */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Gauge className="w-5 h-5 text-amber-400" />
              <span>Dispenser Nozzle Totalizers & Calibrations</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Cumulative electronic meter readings across Tokheim Front Bay DU-1 and Midco Rear Bay DU-2.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-5">
          {nozzles.map((nz) => (
            <div
              key={nz.id}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded text-[11px]">
                    Nozzle #{nz.nozzleNumber}
                  </span>
                  <span
                    className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      nz.fuelType === 'MS'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-blue-500/20 text-blue-300'
                    }`}
                  >
                    {nz.fuelType === 'MS' ? 'Petrol' : 'Diesel'}
                  </span>
                </div>
                <h4 className="font-bold text-slate-200 text-sm">{nz.machineName}</h4>
                <div className="mt-3">
                  <span className="text-[10px] font-mono text-slate-500 uppercase">Closing Cumulative</span>
                  <p className="text-lg font-mono font-black text-white">{nz.lastTotalizer.toFixed(1)} L</p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                <span>Calib: {nz.calibrationDate}</span>
                <button
                  type="button"
                  onClick={() => {
                    setEditingNozzle(nz);
                    setNewTotalizer(nz.lastTotalizer);
                  }}
                  className="text-amber-400 hover:text-amber-300 font-bold underline"
                >
                  Calibrate
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Daily Dip Audit Entry & History */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Dip Entry Form (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
          <div className="pb-4 border-b border-slate-800">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Scale className="w-5 h-5 text-amber-400" />
              <span>Record Daily Dip Audit</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Physical dip tape measurement vs pump book stock reconciliation.
            </p>
          </div>

          <form onSubmit={handleRecordDip} className="space-y-4 mt-5">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                  Select Tank
                </label>
                <select
                  value={selectedTankForDip}
                  onChange={(e) => {
                    const tNum = parseInt(e.target.value);
                    setSelectedTankForDip(tNum);
                    handleDipCmChange(tNum === 2 ? 168.0 : 142.5);
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value={1}>Tank 1 - Petrol (MS)</option>
                  <option value={2}>Tank 2 - Diesel (HSD)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                  Time Slot
                </label>
                <select
                  value={timeSlot}
                  onChange={(e) => setTimeSlot(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="MORNING">Morning (06:00 AM)</option>
                  <option value="EVENING">Evening (06:00 PM)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                Dip Rod Reading (cm) *
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={dipCm}
                onChange={(e) => handleDipCmChange(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-base font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                  Physical Litres (Chart)
                </label>
                <input
                  type="number"
                  step="1"
                  value={physicalLitres}
                  onChange={(e) => setPhysicalLitres(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                  Book Stock Litres
                </label>
                <input
                  type="number"
                  step="1"
                  value={bookStockLitres}
                  onChange={(e) => setBookStockLitres(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Calculated Stock Variance */}
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">Stock Variance (Physical - Book):</span>
              <span
                className={`font-mono font-black text-sm ${
                  varianceLitres >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {varianceLitres >= 0 ? `+${varianceLitres}` : varianceLitres} Litres
              </span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition"
            >
              Save Dip Audit to Firestore
            </button>
          </form>
        </div>

        {/* Dip Audit History (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col h-[520px]">
          <div className="pb-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-white text-base">Recent Dip Audit Logs</h3>
            <span className="text-xs text-slate-400">{dailyDips.length} Entries</span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pt-3 pr-1">
            {dailyDips.map((d, i) => (
              <div
                key={d.id || i}
                className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 text-xs flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">
                      Tank {d.tankNumber} ({d.fuelType === 'MS' ? 'Petrol' : 'Diesel'})
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                      {d.timeSlot}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Date: {d.date} • Dip: {d.dipCm} cm • Audited by: {d.auditedBy}
                  </p>
                </div>

                <div className="text-right">
                  <p className="font-mono font-bold text-white">{d.physicalLitres.toLocaleString()} L</p>
                  <span
                    className={`text-[10px] font-mono font-bold ${
                      d.varianceLitres >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    Var: {d.varianceLitres >= 0 ? `+${d.varianceLitres}` : d.varianceLitres} L
                  </span>
                </div>
              </div>
            ))}

            {dailyDips.length === 0 && (
              <div className="h-48 flex items-center justify-center text-xs text-slate-500 italic">
                No dip records entered yet. Submit morning or evening gauge reading on the left.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* MODAL: CALIBRATE NOZZLE */}
      {editingNozzle && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">
              Calibrate Nozzle #{editingNozzle.nozzleNumber} ({editingNozzle.fuelType})
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              {editingNozzle.machineName} • Current totalizer: {editingNozzle.lastTotalizer} L
            </p>

            <form onSubmit={handleSaveCalibration} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  New Totalizer Meter Reading *
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={newTotalizer}
                  onChange={(e) => setNewTotalizer(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-base font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingNozzle(null)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Save Calibration to Firestore
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
