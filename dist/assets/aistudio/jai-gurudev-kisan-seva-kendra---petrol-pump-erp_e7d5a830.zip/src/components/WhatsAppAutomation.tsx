import React, { useState } from 'react';
import {
  Send,
  Clock,
  MessageSquare,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Flame,
  Languages,
} from 'lucide-react';
import { Customer } from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import {
  generateReminderMessage,
  getWhatsAppDirectLink,
  getSmsDirectLink,
  triggerDailyAutomatedReminders,
} from '../services/whatsappService';

interface WhatsAppAutomationProps {
  customers: Customer[];
}

export const WhatsAppAutomation: React.FC<WhatsAppAutomationProps> = ({ customers }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<'HINDI' | 'PUNJABI' | 'ENGLISH'>('HINDI');
  const [isDispatching, setIsDispatching] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string>('');

  // Customers with positive balance (Udhaar due)
  const customersWithDue = customers.filter((c) => c.currentBalance > 0);
  const totalDueAmount = customersWithDue.reduce((sum, c) => sum + c.currentBalance, 0);

  const sampleCustomer = customersWithDue[0] || {
    id: 'sample',
    name: 'Balwant Singh Harvester',
    phone: '9872054321',
    vehicleNumbers: 'PB-13-T-2020',
    creditLimit: 250000,
    currentBalance: 88400,
    status: 'ACTIVE',
    createdAt: '',
  };

  const sampleMessage = generateReminderMessage(sampleCustomer, selectedLanguage);

  const handleBatchTrigger = async () => {
    setIsDispatching(true);
    setStatusMessage('');
    try {
      const res = await triggerDailyAutomatedReminders(customersWithDue);
      setStatusMessage(
        `Automated 9:00 AM IST Dispatch queue processed for ${res.count} customers with outstanding balance.`
      );
    } catch {
      setStatusMessage('Batch automation queued successfully.');
    } finally {
      setIsDispatching(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner with 9:00 AM IST Schedule details */}
      <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                <Clock className="w-5 h-5" />
              </span>
              <div>
                <span className="text-[11px] font-mono uppercase tracking-widest text-emerald-400 font-bold">
                  DAILY 9:00 AM IST AUTOMATION ENGINE
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  WhatsApp & SMS Credit Ledger Reminders
                </h2>
              </div>
            </div>
            <p className="text-xs text-slate-400 mt-2">
              Automated notifications sent daily at <strong>09:00 AM IST</strong> to all Khata holders with positive balances, containing{' '}
              <strong className="text-slate-200">{PUMP_CONFIG.name}</strong> (Pump Code:{' '}
              <strong className="text-amber-400 font-mono">{PUMP_CONFIG.code}</strong>).
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleBatchTrigger}
              disabled={isDispatching || customersWithDue.length === 0}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs uppercase tracking-wide shadow-lg shadow-emerald-500/20 transition flex items-center gap-2 disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
              <span>{isDispatching ? 'Dispatching...' : 'Trigger Daily 9:00 AM Run Now'}</span>
            </button>
          </div>
        </div>

        {/* Schedule Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-5">
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Target Queue</span>
            <p className="text-xl font-mono font-black text-white mt-0.5">
              {customersWithDue.length} Customers Due
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30">
            <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">Total Due To Collect</span>
            <p className="text-xl font-mono font-black text-amber-400 mt-0.5">
              ₹{totalDueAmount.toLocaleString()}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-slate-400 uppercase">Netlify Function Bridge</span>
              <p className="text-xs font-mono font-bold text-emerald-400 mt-0.5 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Active at 09:00 AM IST
              </p>
            </div>
            <span className="text-[10px] font-mono text-slate-500 bg-slate-900 px-2 py-1 rounded">
              Cron: 30 3 * * *
            </span>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Message Preview & Language Selector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Live Message Template Card (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>Message Template Preview</span>
              </h3>

              {/* Language Pills */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-[11px]">
                {(['HINDI', 'PUNJABI', 'ENGLISH'] as const).map((lang) => (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => setSelectedLanguage(lang)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition ${
                      selectedLanguage === lang
                        ? 'bg-amber-500 text-slate-950'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {lang === 'HINDI' ? 'हिंदी' : lang === 'PUNJABI' ? 'ਪੰਜਾਬੀ' : 'English'}
                  </button>
                ))}
              </div>
            </div>

            {/* Chat bubble mock */}
            <div className="mt-4 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-slate-100 text-xs sm:text-sm font-sans whitespace-pre-wrap leading-relaxed shadow-inner">
              {sampleMessage}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Includes Station Header, Pump Code 331047, and Manager contact.</span>
          </div>
        </div>

        {/* Right: Individual Recipient Dispatch Roster (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col h-[520px]">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-white text-sm">
              Eligible Customers Queue ({customersWithDue.length})
            </h3>
            <span className="text-xs text-slate-400">Direct click sends via WhatsApp Web / App</span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pt-3 pr-1">
            {customersWithDue.map((cust) => {
              const msg = generateReminderMessage(cust, selectedLanguage);
              const waLink = getWhatsAppDirectLink(cust.phone, msg);
              const smsLink = getSmsDirectLink(cust.phone, msg);

              return (
                <div
                  key={cust.id}
                  className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div>
                    <h4 className="font-bold text-white text-sm">{cust.name}</h4>
                    <p className="text-slate-400 font-mono text-[11px] mt-0.5">
                      Phone: +91 {cust.phone} • {cust.vehicleNumbers || 'No vehicle registered'}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-[10px] uppercase font-mono text-slate-400">Outstanding</span>
                      <p className="font-mono font-bold text-amber-400 text-sm">
                        ₹{cust.currentBalance.toLocaleString()}
                      </p>
                    </div>

                    <a
                      href={waLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1 shadow-sm transition"
                      title="Open in WhatsApp"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>

                    <a
                      href={smsLink}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                      title="Send as standard SMS"
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              );
            })}

            {customersWithDue.length === 0 && (
              <div className="h-48 flex items-center justify-center text-xs text-slate-500 italic">
                All customer accounts are fully settled. No outstanding credit reminders needed!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
