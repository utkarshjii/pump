import React, { useState } from 'react';
import {
  IndianRupee,
  Plus,
  Trash2,
  FileText,
  Landmark,
  CheckCircle2,
  AlertCircle,
  Fuel,
  Droplet,
  Package,
} from 'lucide-react';
import { Voucher, Product, Staff } from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import {
  addVoucher,
  deleteVoucher,
  updateProduct,
  addProduct,
  deleteProduct,
} from '../services/firestoreService';

interface VoucherAndRatesProps {
  vouchers: Voucher[];
  products: Product[];
  currentStaff: Staff;
}

export const VoucherAndRates: React.FC<VoucherAndRatesProps> = ({
  vouchers,
  products,
  currentStaff,
}) => {
  // Fuel Rates
  const msProduct = products.find((p) => p.fuelType === 'MS');
  const hsdProduct = products.find((p) => p.fuelType === 'HSD');

  const [petrolPrice, setPetrolPrice] = useState<number>(msProduct?.price || PUMP_CONFIG.defaultRates.petrol);
  const [dieselPrice, setDieselPrice] = useState<number>(hsdProduct?.price || PUMP_CONFIG.defaultRates.diesel);
  const [ratesSuccess, setRatesSuccess] = useState('');

  // Voucher Form State
  const [showVoucherModal, setShowVoucherModal] = useState(false);
  const [voucherNumber, setVoucherNumber] = useState(`VCH-${Date.now().toString().slice(-5)}`);
  const [voucherDate, setVoucherDate] = useState(new Date().toISOString().split('T')[0]);
  const [voucherType, setVoucherType] = useState<'EXPENSE' | 'BANK_DEPOSIT' | 'SALARY' | 'OTHER'>('EXPENSE');
  const [voucherTitle, setVoucherTitle] = useState('');
  const [voucherAmount, setVoucherAmount] = useState<number>(0);
  const [paidTo, setPaidTo] = useState('');
  const [notes, setNotes] = useState('');

  // Add Lubricant Product Modal
  const [showAddProdModal, setShowAddProdModal] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdPrice, setNewProdPrice] = useState(350);
  const [newProdUnit, setNewProdUnit] = useState('Bottle');
  const [newProdStock, setNewProdStock] = useState(25);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const lubeProducts = products.filter((p) => p.category === 'LUBRICANT');

  const totalExpense = vouchers
    .filter((v) => v.type === 'EXPENSE' || v.type === 'SALARY' || v.type === 'OTHER')
    .reduce((sum, v) => sum + v.amount, 0);

  const totalBankDeposit = vouchers
    .filter((v) => v.type === 'BANK_DEPOSIT')
    .reduce((sum, v) => sum + v.amount, 0);

  const handleUpdateRates = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (msProduct) {
        await updateProduct(msProduct.id, { price: petrolPrice });
      }
      if (hsdProduct) {
        await updateProduct(hsdProduct.id, { price: dieselPrice });
      }
      setRatesSuccess(`Fuel rates updated in Firestore: Petrol ₹${petrolPrice}/L, Diesel ₹${dieselPrice}/L`);
      setTimeout(() => setRatesSuccess(''), 4000);
    } catch {
      alert('Failed to update fuel rates');
    }
  };

  const handleCreateVoucher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!voucherTitle || voucherAmount <= 0) return;
    setIsSubmitting(true);

    try {
      await addVoucher({
        voucherNumber,
        date: voucherDate,
        type: voucherType,
        title: voucherTitle,
        amount: voucherAmount,
        paidTo,
        authorizedBy: currentStaff.name,
        notes,
        createdAt: new Date().toISOString(),
      });
      setNotification({
        type: 'success',
        text: `Voucher #${voucherNumber} for ₹${voucherAmount.toLocaleString()} saved!`,
      });
      setShowVoucherModal(false);
      setVoucherTitle('');
      setVoucherAmount(0);
      setPaidTo('');
      setNotes('');
      setVoucherNumber(`VCH-${Date.now().toString().slice(-5)}`);
    } catch {
      setNotification({ type: 'error', text: 'Failed to record voucher.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteVoucher = async (id?: string) => {
    if (!id || !confirm('Are you sure you want to delete this voucher?')) return;
    try {
      await deleteVoucher(id);
      setNotification({ type: 'success', text: 'Voucher removed from Firestore.' });
    } catch {
      setNotification({ type: 'error', text: 'Error deleting voucher.' });
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addProduct({
        name: newProdName,
        category: 'LUBRICANT',
        price: Number(newProdPrice),
        unit: newProdUnit,
        stockQuantity: Number(newProdStock),
        minStockAlert: 5,
      });
      setNotification({ type: 'success', text: `Product ${newProdName} added!` });
      setShowAddProdModal(false);
      setNewProdName('');
    } catch {
      setNotification({ type: 'error', text: 'Failed to add product.' });
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <IndianRupee className="w-5 h-5" />
            </span>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                PRICING & EXPENSE CONTROLLER
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Vouchers & Daily Fuel Rates
              </h2>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Publish daily fuel rates, manage engine oils pricing, and log pump operational cash vouchers.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowVoucherModal(true)}
          className="px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wide shadow-lg shadow-amber-500/20 transition flex items-center gap-2"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>New Expense / Bank Voucher</span>
        </button>
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between shadow-lg ${
            notification.type === 'success'
              ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
              : 'bg-rose-500/15 border border-rose-500/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold underline text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* SECTION 1: DYNAMIC DAILY FUEL RATES */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-white text-base">Dynamic Daily Fuel Selling Rates (₹ per Litre)</h3>
            <p className="text-xs text-slate-400">
              Changes reflect immediately across all machine dispensers and shift bill calculations.
            </p>
          </div>
          {ratesSuccess && (
            <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/30">
              ✓ {ratesSuccess}
            </span>
          )}
        </div>

        <form onSubmit={handleUpdateRates} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-5">
          {/* Petrol Rate */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-bold text-emerald-400 uppercase">Motor Spirit (Petrol / MS)</span>
              <Fuel className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 font-mono text-slate-400 font-bold">₹</span>
              <input
                type="number"
                step="0.01"
                required
                value={petrolPrice}
                onChange={(e) => setPetrolPrice(parseFloat(e.target.value) || 0)}
                className="w-full pl-7 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl font-mono font-bold text-white text-lg focus:outline-none focus:border-emerald-400"
              />
            </div>
          </div>

          {/* Diesel Rate */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-blue-500/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-bold text-blue-400 uppercase">High Speed Diesel (HSD)</span>
              <Droplet className="w-4 h-4 text-blue-400" />
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 font-mono text-slate-400 font-bold">₹</span>
              <input
                type="number"
                step="0.01"
                required
                value={dieselPrice}
                onChange={(e) => setDieselPrice(parseFloat(e.target.value) || 0)}
                className="w-full pl-7 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl font-mono font-bold text-white text-lg focus:outline-none focus:border-blue-400"
              />
            </div>
          </div>

          {/* Update Action */}
          <div className="flex items-end">
            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wide shadow-md transition"
            >
              Publish Updated Rates to Cloud
            </button>
          </div>
        </form>
      </div>

      {/* SECTION 2: EXPENSE & BANK VOUCHERS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-rose-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-rose-400 uppercase font-bold">
              Total Pump Operational Expenses
            </span>
            <p className="text-2xl font-mono font-black text-rose-400 mt-1">
              ₹{totalExpense.toLocaleString()}
            </p>
          </div>
          <FileText className="w-8 h-8 text-rose-400/40" />
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">
              Bank Cash Deposits
            </span>
            <p className="text-2xl font-mono font-black text-emerald-400 mt-1">
              ₹{totalBankDeposit.toLocaleString()}
            </p>
          </div>
          <Landmark className="w-8 h-8 text-emerald-400/40" />
        </div>
      </div>

      {/* Vouchers Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="pb-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-white text-base">Expense & Bank Deposit Register</h3>
          <span className="text-xs text-slate-400 font-mono">{vouchers.length} Vouchers</span>
        </div>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                <th className="pb-3 pl-2">Voucher #</th>
                <th className="pb-3">Date</th>
                <th className="pb-3">Type</th>
                <th className="pb-3">Purpose / Particulars</th>
                <th className="pb-3">Recipient / Bank</th>
                <th className="pb-3">Authorized By</th>
                <th className="pb-3 text-right">Amount</th>
                <th className="pb-3 pr-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {vouchers.map((v) => (
                <tr key={v.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3 pl-2 font-mono font-bold text-white">{v.voucherNumber}</td>
                  <td className="py-3 text-slate-400 font-mono">{v.date}</td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        v.type === 'BANK_DEPOSIT'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : v.type === 'SALARY'
                          ? 'bg-purple-500/20 text-purple-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {v.type}
                    </span>
                  </td>
                  <td className="py-3 font-semibold text-slate-200">
                    {v.title}
                    {v.notes && <p className="text-[10px] text-slate-500 italic mt-0.5">{v.notes}</p>}
                  </td>
                  <td className="py-3 text-slate-300">{v.paidTo || '-'}</td>
                  <td className="py-3 text-slate-400">{v.authorizedBy}</td>
                  <td className="py-3 text-right font-mono font-bold text-base text-amber-400">
                    ₹{v.amount.toLocaleString()}
                  </td>
                  <td className="py-3 pr-2 text-right">
                    <button
                      type="button"
                      onClick={() => handleDeleteVoucher(v.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition"
                      title="Delete voucher"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {vouchers.length === 0 && (
            <div className="h-40 flex items-center justify-center text-xs text-slate-500 italic">
              No expense or deposit vouchers recorded yet.
            </div>
          )}
        </div>
      </div>

      {/* SECTION 3: LUBRICANTS INVENTORY CATALOG */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-white text-base">Packaged Lubricants & Engine Oil Pricing</h3>
          </div>
          <button
            type="button"
            onClick={() => setShowAddProdModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs flex items-center gap-1.5 border border-slate-700"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Lubricant Product</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-4">
          {lubeProducts.map((p) => (
            <div
              key={p.id}
              className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between"
            >
              <div>
                <p className="font-bold text-white">{p.name}</p>
                <p className="text-[11px] font-mono text-amber-400 mt-0.5">
                  ₹{p.price} / {p.unit}
                </p>
                <span className="text-[10px] text-slate-500">In Stock: {p.stockQuantity}</span>
              </div>
              <button
                type="button"
                onClick={() => deleteProduct(p.id)}
                className="text-slate-500 hover:text-rose-400 p-1"
                title="Delete product"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL: CREATE VOUCHER */}
      {showVoucherModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">Create Station Voucher</h3>
            <p className="text-xs text-slate-400 mb-4">
              Operational expenses, Genset diesel, staff salary advances, or bank deposits.
            </p>

            <form onSubmit={handleCreateVoucher} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Voucher No.</label>
                  <input
                    type="text"
                    value={voucherNumber}
                    onChange={(e) => setVoucherNumber(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Date</label>
                  <input
                    type="date"
                    value={voucherDate}
                    onChange={(e) => setVoucherDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Category</label>
                <select
                  value={voucherType}
                  onChange={(e) => setVoucherType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="EXPENSE">Pump Operational Expense (Genset / Tea / Sweeper)</option>
                  <option value="BANK_DEPOSIT">Bank Cash Deposit (SBI / HDFC / PNB)</option>
                  <option value="SALARY">Salesman Salary Advance</option>
                  <option value="OTHER">Electricity / Maintenance / Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Particulars / Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Genset Diesel (20L) / Sweeper Monthly"
                  value={voucherTitle}
                  onChange={(e) => setVoucherTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Amount (INR) *</label>
                  <input
                    type="number"
                    step="1"
                    min="1"
                    required
                    value={voucherAmount || ''}
                    placeholder="0"
                    onChange={(e) => setVoucherAmount(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Paid To / Deposited In</label>
                  <input
                    type="text"
                    placeholder="Payee name / Bank"
                    value={paidTo}
                    onChange={(e) => setPaidTo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Remarks</label>
                <input
                  type="text"
                  placeholder="Slip reference or notes..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowVoucherModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || voucherAmount <= 0}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Save Voucher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD LUBRICANT PRODUCT */}
      {showAddProdModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-base font-bold text-white mb-3">Add Lubricant Product</h3>
            <form onSubmit={handleAddProduct} className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Product Name *</label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="e.g. Servo 4T Super (1L)"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Selling Price (INR)</label>
                  <input
                    type="number"
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Packaging Unit</label>
                  <input
                    type="text"
                    value={newProdUnit}
                    onChange={(e) => setNewProdUnit(e.target.value)}
                    placeholder="Bottle / Can / Bucket"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Stock Quantity</label>
                <input
                  type="number"
                  value={newProdStock}
                  onChange={(e) => setNewProdStock(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddProdModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
