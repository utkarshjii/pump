import React, { useState, useEffect } from 'react';
import { Shield, KeyRound, AlertCircle, CheckCircle2, Lock } from 'lucide-react';
import { Staff } from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';

interface LoginScreenProps {
  staffList: Staff[];
  onLoginSuccess: (staff: Staff) => void;
  isLoading: boolean;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  staffList,
  onLoginSuccess,
  isLoading,
}) => {
  // Use passed staffList, or fall back to defaultStaff so it is NEVER empty
  const availableStaff = staffList && staffList.length > 0 ? staffList : PUMP_CONFIG.defaultStaff;
  const activeStaff = availableStaff.filter((s) => s.active);

  // Selected staff member
  const [selectedStaffId, setSelectedStaffId] = useState<string>(activeStaff[0]?.id || 'staff-ranjit');
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [attempts, setAttempts] = useState<number>(0);

  // Keep selectedStaffId valid if staffList updates
  useEffect(() => {
    if (!selectedStaffId && activeStaff.length > 0) {
      setSelectedStaffId(activeStaff[0].id);
    }
  }, [activeStaff, selectedStaffId]);

  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError('');

    if (!selectedStaffId) {
      setError('कृपया पहले अपना नाम चुनें (Please select your staff profile)');
      return;
    }

    const member = activeStaff.find((s) => s.id === selectedStaffId);
    if (!member) {
      setError('स्टाफ रिकॉर्ड नहीं मिला (Staff profile not found)');
      return;
    }

    if (!pin || pin.length < 4) {
      setError('कृपया कम से कम 4 अंकों का पिन दर्ज करें (Please enter at least 4-digit PIN)');
      return;
    }

    // STRICT SECURE VERIFICATION: Only authenticate if entered PIN exactly matches the profile's secret PIN
    if (member.pin !== pin) {
      setAttempts((prev) => prev + 1);
      setError('गलत गोपनीय पिन! कृपया अपना सही व्यक्तिगत पिन दर्ज करें। (Incorrect PIN. Please enter your confidential staff PIN)');
      setPin('');
      return;
    }

    // Authentication Success
    setError('');
    onLoginSuccess(member);
  };

  const handleKeypadPress = (digit: string) => {
    if (pin.length < 6) {
      setPin((prev) => prev + digit);
      setError('');
    }
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
  };

  const handleClear = () => {
    setPin('');
    setError('');
  };

  const selectedMember = activeStaff.find((s) => s.id === selectedStaffId);

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-5 sm:p-7 backdrop-blur-xl relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute -top-24 -right-24 w-52 h-52 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-52 h-52 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="text-center mb-5">
          <div className="inline-flex p-3 rounded-2xl bg-amber-500/15 text-amber-400 border border-amber-500/30 mb-2.5 shadow-inner">
            <Shield className="w-7 h-7 sm:w-8 sm:h-8" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            Station Security Login
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {PUMP_CONFIG.name} • <span className="text-amber-400 font-mono font-bold">Code: {PUMP_CONFIG.code}</span>
          </p>
          <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-400">
            <Lock className="w-3 h-3 text-emerald-400" />
            <span>Strict Confidential PIN Verification Required</span>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handlePinSubmit} className="space-y-4">
          {/* Step 1: Select Staff Member */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                1. Select Staff Member (अपना नाम चुनें)
              </label>
              {selectedMember && (
                <span className="text-[11px] font-mono text-slate-400">
                  Selected: <strong className="text-white">{selectedMember.name}</strong>
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 max-h-44 overflow-y-auto pr-1">
              {activeStaff.map((s) => {
                const isSelected = selectedStaffId === s.id;
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => {
                      setSelectedStaffId(s.id);
                      setPin(''); // Reset PIN when changing person
                      setError('');
                    }}
                    className={`p-2.5 rounded-xl text-left border transition-all text-xs flex flex-col justify-between ${
                      isSelected
                        ? 'border-amber-400 bg-amber-500/15 text-white shadow-md shadow-amber-500/10 ring-1 ring-amber-400'
                        : 'border-slate-800 bg-slate-950/60 hover:bg-slate-800/60 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold truncate">{s.name}</span>
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                    </div>
                    <div className="flex items-center justify-between mt-1 text-[10px] font-mono">
                      <span
                        className={
                          s.role === 'OWNER'
                            ? 'text-amber-400 font-bold'
                            : s.role === 'MANAGER'
                            ? 'text-blue-400 font-bold'
                            : 'text-emerald-400'
                        }
                      >
                        {s.role}
                      </span>
                      <span className="text-slate-500 flex items-center gap-1">
                        <Lock className="w-2.5 h-2.5" /> PIN Protected
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Masked PIN Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                2. Enter Secret PIN (गोपनीय पासवर्ड दर्ज करें)
              </label>
              {selectedMember && (
                <span className="text-[10px] text-slate-500 font-mono">
                  For: {selectedMember.name}
                </span>
              )}
            </div>

            <div className="relative">
              <input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                value={pin}
                autoFocus
                autoComplete="current-password"
                onChange={(e) => {
                  const cleaned = e.target.value.replace(/[^0-9]/g, '');
                  if (cleaned.length <= 6) setPin(cleaned);
                  setError('');
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handlePinSubmit();
                  }
                }}
                placeholder="••••"
                className="w-full text-center text-xl sm:text-2xl tracking-[0.4em] font-mono font-black py-3 rounded-xl bg-slate-950 border border-slate-700 text-amber-400 placeholder:text-slate-600 placeholder:text-base placeholder:tracking-normal focus:outline-none focus:border-amber-400 transition"
              />
              <KeyRound className="absolute right-3.5 top-3.5 w-5 h-5 text-slate-500 pointer-events-none" />
            </div>
            <p className="text-[10px] text-slate-500 mt-1 text-center font-mono">
              Never share your confidential PIN with other pump staff.
            </p>
          </div>

          {/* On-screen Numeric Keypad for Touch / Mobile Screens */}
          <div className="grid grid-cols-3 gap-2 pt-0.5">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((key) => {
              const isAction = key === 'C' || key === '⌫';
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    if (key === 'C') handleClear();
                    else if (key === '⌫') handleBackspace();
                    else handleKeypadPress(key);
                  }}
                  className={`h-10 sm:h-11 rounded-xl text-sm font-mono font-bold transition active:scale-95 flex items-center justify-center ${
                    isAction
                      ? 'bg-slate-800/80 text-rose-400 hover:bg-slate-700/80'
                      : 'bg-slate-800 text-slate-100 hover:bg-slate-700 border border-slate-700/50'
                  }`}
                >
                  {key}
                </button>
              );
            })}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading || !selectedStaffId || pin.length < 4}
            className="w-full mt-2 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm tracking-wide shadow-lg shadow-amber-500/25 transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <span className="animate-spin text-slate-950">⌛ Verifying...</span>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Verify PIN & Login (सत्यापित करें और लॉगिन करें)</span>
              </>
            )}
          </button>
        </form>

        {/* Security Notice */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 text-center">
          <p className="text-[11px] text-slate-500 font-mono">
            Jai Gurudev Kisan Seva Kendra ERP • Security Audit Active
          </p>
          <p className="text-[10px] text-slate-600 mt-0.5">
            Role privileges: Owner & Manager (Full Admin) • Salesman (Sales Logging Only)
          </p>
        </div>
      </div>
    </div>
  );
};
