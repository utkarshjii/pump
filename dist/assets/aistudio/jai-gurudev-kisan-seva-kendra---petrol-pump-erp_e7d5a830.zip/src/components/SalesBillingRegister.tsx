import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Search,
  Printer,
  Calendar,
  Filter,
  Trash2,
  Eye,
  IndianRupee,
  CheckCircle2,
  X,
  Fuel,
  Download,
} from 'lucide-react';
import { MachineSaleRecord, Staff } from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import { deleteSaleRecord } from '../services/firestoreService';

interface SalesBillingRegisterProps {
  salesRecords: MachineSaleRecord[];
  currentStaff: Staff;
}

export const SalesBillingRegister: React.FC<SalesBillingRegisterProps> = ({
  salesRecords,
  currentStaff,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMachine, setSelectedMachine] = useState<string>('ALL');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [viewingSale, setViewingSale] = useState<MachineSaleRecord | null>(null);

  // Filtered sales list
  const filteredSales = salesRecords.filter((sale) => {
    const matchesSearch =
      sale.salesmanName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.machineName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (sale.customerName && sale.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (sale.vehicleNo && sale.vehicleNo.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (sale.slipNo && sale.slipNo.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesMachine =
      selectedMachine === 'ALL' || sale.machineId === selectedMachine;

    const matchesDate = !selectedDate || sale.date === selectedDate;

    return matchesSearch && matchesMachine && matchesDate;
  });

  const totalFilteredRevenue = filteredSales.reduce((sum, s) => sum + s.grossTotal, 0);
  const totalFilteredPetrol = filteredSales.reduce((sum, s) => sum + s.petrolLitres, 0);
  const totalFilteredDiesel = filteredSales.reduce((sum, s) => sum + s.dieselLitres, 0);

  const handleDelete = async (id?: string) => {
    if (!id || !confirm('Are you sure you want to delete this bill record from Firestore?')) return;
    try {
      await deleteSaleRecord(id);
    } catch {
      alert('Failed to delete sale record');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const headers = [
      'Date',
      'Slip/Memo No',
      'Machine',
      'Salesman',
      'Petrol Litres',
      'Petrol Amount',
      'Diesel Litres',
      'Diesel Amount',
      'Lube Amount',
      'Gross Total',
      'Cash',
      'UPI',
      'POS',
      'Credit (Udhaar)',
      'Customer',
      'Vehicle',
    ];

    const rows = filteredSales.map((s) => [
      s.date,
      s.slipNo || '-',
      s.machineName,
      s.salesmanName,
      s.petrolLitres,
      s.petrolAmount,
      s.dieselLitres,
      s.dieselAmount,
      s.lubeAmount,
      s.grossTotal,
      s.cashAmount,
      s.upiAmount,
      s.posAmount,
      s.creditAmount,
      s.customerName || '-',
      s.vehicleNo || '-',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Pump_Sales_${PUMP_CONFIG.code}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner & Summary */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <FileSpreadsheet className="w-5 h-5" />
            </span>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                SALES REGISTER & INVOICES
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Sales & Billing Management
              </h2>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Complete transaction history, dispenser shift bills, thermal receipt printing, and CSV export.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-2 border border-slate-700 transition"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            placeholder="Search salesman, customer, vehicle, slip #..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Machine Filter */}
        <div>
          <select
            value={selectedMachine}
            onChange={(e) => setSelectedMachine(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option value="ALL">All Dispenser Machines</option>
            <option value="tokheim-du1">Tokheim (Front Bay DU-1)</option>
            <option value="midco-du2">Midco (Rear Bay DU-2)</option>
          </select>
        </div>

        {/* Date Filter */}
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
          />
          {selectedDate && (
            <button
              type="button"
              onClick={() => setSelectedDate('')}
              className="p-2 text-slate-400 hover:text-white"
              title="Clear date filter"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Aggregated Totals Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400 font-mono uppercase">Filtered Records</span>
          <span className="font-mono font-bold text-white text-base">{filteredSales.length} Bills</span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400 font-mono uppercase">Total Fuel Dispensed</span>
          <span className="font-mono font-bold text-slate-200 text-sm">
            MS: {totalFilteredPetrol.toFixed(1)} L | HSD: {totalFilteredDiesel.toFixed(1)} L
          </span>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/30 flex items-center justify-between">
          <span className="text-xs text-amber-400 font-mono uppercase font-bold">Filtered Revenue</span>
          <span className="font-mono font-black text-amber-400 text-lg">
            ₹{totalFilteredRevenue.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Sales Bills Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                <th className="pb-3 pl-2">Date & Memo</th>
                <th className="pb-3">Dispenser</th>
                <th className="pb-3">Salesman</th>
                <th className="pb-3 text-right">Petrol (MS)</th>
                <th className="pb-3 text-right">Diesel (HSD)</th>
                <th className="pb-3 text-right">Lubes</th>
                <th className="pb-3 text-right">Gross Total</th>
                <th className="pb-3">Payment Split</th>
                <th className="pb-3 pr-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredSales.map((sale) => (
                <tr key={sale.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3 pl-2 font-mono">
                    <span className="font-bold text-white">{sale.date}</span>
                    <p className="text-[10px] text-amber-400">{sale.slipNo || 'NO-SLIP'}</p>
                  </td>
                  <td className="py-3 font-semibold text-slate-200">{sale.machineName}</td>
                  <td className="py-3 font-medium text-slate-300">{sale.salesmanName}</td>
                  <td className="py-3 text-right font-mono text-emerald-400 font-semibold">
                    {sale.petrolLitres > 0 ? `${sale.petrolLitres} L (₹${sale.petrolAmount})` : '-'}
                  </td>
                  <td className="py-3 text-right font-mono text-blue-400 font-semibold">
                    {sale.dieselLitres > 0 ? `${sale.dieselLitres} L (₹${sale.dieselAmount})` : '-'}
                  </td>
                  <td className="py-3 text-right font-mono text-slate-300">
                    {sale.lubeAmount > 0 ? `₹${sale.lubeAmount}` : '-'}
                  </td>
                  <td className="py-3 text-right font-mono font-black text-amber-400 text-sm">
                    ₹{sale.grossTotal.toLocaleString()}
                  </td>
                  <td className="py-3">
                    <div className="text-[10px] font-mono text-slate-400 space-y-0.5">
                      <div>Cash: ₹{sale.cashAmount.toLocaleString()}</div>
                      {(sale.upiAmount > 0 || sale.posAmount > 0) && (
                        <div className="text-blue-400">
                          Digital: ₹{(sale.upiAmount + sale.posAmount).toLocaleString()}
                        </div>
                      )}
                      {sale.creditAmount > 0 && (
                        <div className="text-amber-300 font-bold">
                          Udhaar: ₹{sale.creditAmount.toLocaleString()}{' '}
                          {sale.customerName && `(${sale.customerName})`}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="py-3 pr-2 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        type="button"
                        onClick={() => setViewingSale(sale)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                        title="View & Print Bill Memo"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      {currentStaff.role !== 'SALESMAN' && (
                        <button
                          type="button"
                          onClick={() => handleDelete(sale.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                          title="Delete bill record (Manager & Owner Only)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredSales.length === 0 && (
            <div className="h-48 flex items-center justify-center text-xs text-slate-500 italic">
              No sales records matched the search criteria.
            </div>
          )}
        </div>
      </div>

      {/* MODAL: VIEW & PRINT BILL MEMO */}
      {viewingSale && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 w-full max-w-md shadow-2xl relative">
            <button
              onClick={() => setViewingSale(null)}
              className="absolute right-4 top-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Printable Thermal Receipt Container */}
            <div id="printable-bill" className="bg-white text-slate-950 p-5 rounded-2xl font-mono text-xs shadow-inner">
              <div className="text-center border-b border-dashed border-slate-400 pb-3">
                <h3 className="font-black text-sm uppercase tracking-tight">{PUMP_CONFIG.name}</h3>
                <p className="text-[10px] font-bold text-slate-700">PUMP CODE: {PUMP_CONFIG.code}</p>
                <p className="text-[9px] text-slate-600 mt-0.5">{PUMP_CONFIG.location}</p>
                <p className="text-[9px] text-slate-600">
                  Owner: {PUMP_CONFIG.owner} • Manager: {PUMP_CONFIG.manager}
                </p>
              </div>

              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span>Memo No:</span>
                  <span className="font-bold">{viewingSale.slipNo || 'BILL-' + Date.now().toString().slice(-6)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Date & Time:</span>
                  <span>{viewingSale.date}</span>
                </div>
                <div className="flex justify-between">
                  <span>Dispenser:</span>
                  <span>{viewingSale.machineName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Attendant:</span>
                  <span>{viewingSale.salesmanName}</span>
                </div>
                {viewingSale.customerName && (
                  <div className="flex justify-between">
                    <span>Customer:</span>
                    <span className="font-bold">{viewingSale.customerName}</span>
                  </div>
                )}
                {viewingSale.vehicleNo && (
                  <div className="flex justify-between">
                    <span>Vehicle No:</span>
                    <span className="font-bold">{viewingSale.vehicleNo}</span>
                  </div>
                )}
              </div>

              {/* Items Table */}
              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
                <div className="flex justify-between font-bold text-[10px] border-b pb-1">
                  <span>PRODUCT</span>
                  <span>QTY</span>
                  <span>RATE</span>
                  <span>AMOUNT</span>
                </div>

                {viewingSale.petrolLitres > 0 && (
                  <div className="flex justify-between">
                    <span>Petrol (MS)</span>
                    <span>{viewingSale.petrolLitres} L</span>
                    <span>₹{viewingSale.petrolRate}</span>
                    <span className="font-bold">₹{viewingSale.petrolAmount}</span>
                  </div>
                )}

                {viewingSale.dieselLitres > 0 && (
                  <div className="flex justify-between">
                    <span>Diesel (HSD)</span>
                    <span>{viewingSale.dieselLitres} L</span>
                    <span>₹{viewingSale.dieselRate}</span>
                    <span className="font-bold">₹{viewingSale.dieselAmount}</span>
                  </div>
                )}

                {viewingSale.lubeAmount > 0 && (
                  <div className="flex justify-between">
                    <span>Lubricants</span>
                    <span>-</span>
                    <span>-</span>
                    <span className="font-bold">₹{viewingSale.lubeAmount}</span>
                  </div>
                )}
              </div>

              {/* Grand Total & Payment Method */}
              <div className="pt-2.5 space-y-1">
                <div className="flex justify-between text-sm font-black border-b pb-1.5">
                  <span>GRAND TOTAL:</span>
                  <span>₹{viewingSale.grossTotal.toLocaleString()}</span>
                </div>

                <div className="text-[10px] space-y-0.5 pt-1 text-slate-700">
                  {viewingSale.cashAmount > 0 && (
                    <div className="flex justify-between">
                      <span>Cash Paid:</span>
                      <span>₹{viewingSale.cashAmount}</span>
                    </div>
                  )}
                  {viewingSale.upiAmount > 0 && (
                    <div className="flex justify-between">
                      <span>UPI Paid:</span>
                      <span>₹{viewingSale.upiAmount}</span>
                    </div>
                  )}
                  {viewingSale.posAmount > 0 && (
                    <div className="flex justify-between">
                      <span>POS Card Paid:</span>
                      <span>₹{viewingSale.posAmount}</span>
                    </div>
                  )}
                  {viewingSale.creditAmount > 0 && (
                    <div className="flex justify-between font-bold text-amber-700">
                      <span>Credit (Udhaar):</span>
                      <span>₹{viewingSale.creditAmount}</span>
                    </div>
                  )}
                </div>

                <p className="text-center text-[9px] text-slate-500 pt-3 italic">
                  Thank You! Visit Again • Jai Gurudev Kisan Seva Kendra
                </p>
              </div>
            </div>

            {/* Print button */}
            <div className="mt-4 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setViewingSale(null)}
                className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
              >
                Close
              </button>
              <button
                type="button"
                onClick={handlePrint}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md"
              >
                <Printer className="w-4 h-4" />
                <span>Print Bill Slip</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
