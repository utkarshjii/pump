import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  ArrowDownLeft,
  ArrowUpRight,
  Send,
  History,
  Phone,
  Truck,
  IndianRupee,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
} from 'lucide-react';
import { Customer, CustomerLedgerEntry, Staff } from '../types/pump';
import { saveCustomer, recordCustomerPayment } from '../services/firestoreService';
import { generateReminderMessage, getWhatsAppDirectLink } from '../services/whatsappService';

interface KhataLedgerProps {
  customers: Customer[];
  ledgerEntries: CustomerLedgerEntry[];
  currentStaff: Staff;
}

export const KhataLedger: React.FC<KhataLedgerProps> = ({
  customers,
  ledgerEntries,
  currentStaff,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  // New Customer Form
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustVehicles, setNewCustVehicles] = useState('');
  const [newCustLimit, setNewCustLimit] = useState(100000);
  const [newCustAddress, setNewCustAddress] = useState('');

  // Payment Form
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<'CASH' | 'UPI' | 'CHEQUE' | 'BANK_TRANSFER'>('CASH');
  const [paymentNotes, setPaymentNotes] = useState('');

  const [notification, setNotification] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filter customers
  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.includes(searchTerm) ||
      c.vehicleNumbers?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalOutstanding = customers.reduce((sum, c) => sum + (c.currentBalance || 0), 0);

  // Filter ledger for currently selected customer
  const customerLedger = selectedCustomer
    ? ledgerEntries.filter((l) => l.customerId === selectedCustomer.id)
    : [];

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName || !newCustPhone) return;

    try {
      setIsSubmitting(true);
      await saveCustomer({
        name: newCustName,
        phone: newCustPhone,
        vehicleNumbers: newCustVehicles,
        creditLimit: Number(newCustLimit),
        currentBalance: 0,
        address: newCustAddress,
        status: 'ACTIVE',
        createdAt: new Date().toISOString(),
      });
      setNotification({ type: 'success', text: `Khata account created for ${newCustName}!` });
      setShowAddCustomerModal(false);
      setNewCustName('');
      setNewCustPhone('');
      setNewCustVehicles('');
      setNewCustAddress('');
    } catch {
      setNotification({ type: 'error', text: 'Failed to create customer account' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer || paymentAmount <= 0) return;

    try {
      setIsSubmitting(true);
      await recordCustomerPayment(
        selectedCustomer.id,
        paymentAmount,
        paymentMode,
        paymentNotes,
        currentStaff.name
      );
      setNotification({
        type: 'success',
        text: `Settlement of ₹${paymentAmount.toLocaleString()} recorded for ${selectedCustomer.name}!`,
      });
      setShowPaymentModal(false);
      setPaymentAmount(0);
      setPaymentNotes('');
    } catch {
      setNotification({ type: 'error', text: 'Failed to record settlement payment' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Khata Metrics & Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <span className="text-[11px] font-mono uppercase text-slate-400">Total Khata Credit Accounts</span>
          <p className="text-2xl font-black text-white mt-1">{customers.length} Accounts</p>
        </div>

        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 shadow-xl">
          <span className="text-[11px] font-mono uppercase text-amber-400 font-bold">Total Pump Outstanding Balance</span>
          <p className="text-2xl font-mono font-black text-amber-400 mt-1">
            ₹{totalOutstanding.toLocaleString()}
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono uppercase text-slate-400">New Khata</span>
            <p className="text-xs text-slate-400 mt-0.5">Register Farmer / Transporter</p>
          </div>
          <button
            type="button"
            onClick={() => setShowAddCustomerModal(true)}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-500/20 transition"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Add Customer</span>
          </button>
        </div>
      </div>

      {notification && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between shadow-lg ${
            notification.type === 'success'
              ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
              : 'bg-rose-500/15 border border-rose-500/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{notification.text}</span>
          </div>
          <button onClick={() => setNotification(null)} className="font-bold underline text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* Main Split View: Customer Directory & Customer Statement */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Customers Directory (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col h-[750px]">
          <div className="pb-4 border-b border-slate-800">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Users className="w-5 h-5 text-amber-400" />
              <span>Customer Khata Accounts</span>
            </h3>

            {/* Search Input */}
            <div className="relative mt-3">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                placeholder="Search by customer name, phone, or vehicle..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Customer Scroll List */}
          <div className="flex-1 overflow-y-auto space-y-2 pt-3 pr-1">
            {filteredCustomers.map((cust) => {
              const isSelected = selectedCustomer?.id === cust.id;
              const isOverLimit = cust.currentBalance > cust.creditLimit;
              return (
                <button
                  key={cust.id}
                  type="button"
                  onClick={() => setSelectedCustomer(cust)}
                  className={`w-full p-3.5 rounded-2xl border text-left transition-all ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-400 shadow-md shadow-amber-500/5'
                      : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-white">{cust.name}</h4>
                      <p className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <Phone className="w-3 h-3 text-slate-500" />
                        <span>{cust.phone}</span>
                      </p>
                      {cust.vehicleNumbers && (
                        <p className="text-[10px] text-slate-500 flex items-center gap-1.5 mt-0.5 truncate max-w-[240px]">
                          <Truck className="w-3 h-3 text-slate-600" />
                          <span>{cust.vehicleNumbers}</span>
                        </p>
                      )}
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] uppercase font-mono text-slate-400">Balance Due</span>
                      <p
                        className={`text-sm font-mono font-black ${
                          cust.currentBalance > 0 ? 'text-amber-400' : 'text-emerald-400'
                        }`}
                      >
                        ₹{cust.currentBalance.toLocaleString()}
                      </p>
                      {isOverLimit && (
                        <span className="text-[9px] font-bold text-rose-400 uppercase bg-rose-500/20 px-1 py-0.5 rounded">
                          Limit Exceeded
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Side: Ledger Detail & History Statement (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col h-[750px]">
          {selectedCustomer ? (
            <>
              {/* Selected Customer Header Banner */}
              <div className="pb-4 border-b border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-black text-lg text-white">{selectedCustomer.name}</h3>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        selectedCustomer.status === 'ACTIVE'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-rose-500/20 text-rose-400'
                      }`}
                    >
                      {selectedCustomer.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Phone: <strong className="text-slate-200">{selectedCustomer.phone}</strong> • Credit Limit: ₹{selectedCustomer.creditLimit.toLocaleString()}
                  </p>
                  {selectedCustomer.address && (
                    <p className="text-[11px] text-slate-500 mt-0.5">Address: {selectedCustomer.address}</p>
                  )}
                </div>

                {/* Action Buttons: Record Payment & WhatsApp Reminder */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowPaymentModal(true)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition"
                  >
                    <IndianRupee className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Receive Payment</span>
                  </button>

                  {selectedCustomer.currentBalance > 0 && (
                    <a
                      href={getWhatsAppDirectLink(
                        selectedCustomer.phone,
                        generateReminderMessage(selectedCustomer, 'HINDI')
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition"
                      title="Send WhatsApp Balance Notice"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                  )}
                </div>
              </div>

              {/* Running Balance Banner */}
              <div className="my-3 p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase text-slate-400">Net Outstanding Balance</span>
                  <p className="text-xl font-mono font-black text-amber-400">
                    ₹{selectedCustomer.currentBalance.toLocaleString()}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono uppercase text-slate-400">Available Limit</span>
                  <p className="text-sm font-mono font-bold text-slate-300">
                    ₹{Math.max(0, selectedCustomer.creditLimit - selectedCustomer.currentBalance).toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Transactions Ledger Table */}
              <div className="flex-1 overflow-y-auto pr-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
                  <History className="w-3.5 h-3.5 text-amber-400" />
                  <span>Statement & Ledger History</span>
                </h4>

                {customerLedger.length > 0 ? (
                  <div className="space-y-2">
                    {customerLedger.map((entry, idx) => {
                      const isSale = entry.type === 'CREDIT_SALE';
                      const isPayment = entry.type === 'PAYMENT_RECEIVED';
                      return (
                        <div
                          key={entry.id || idx}
                          className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs flex items-center justify-between"
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`p-2 rounded-lg ${
                                isSale
                                  ? 'bg-rose-500/15 text-rose-400'
                                  : isPayment
                                  ? 'bg-emerald-500/15 text-emerald-400'
                                  : 'bg-blue-500/15 text-blue-400'
                              }`}
                            >
                              {isSale ? (
                                <ArrowUpRight className="w-4 h-4" />
                              ) : (
                                <ArrowDownLeft className="w-4 h-4" />
                              )}
                            </div>
                            <div>
                              <p className="font-bold text-white">
                                {isSale
                                  ? `Fuel Credit Sale (${entry.fuelType || 'Fuel'})`
                                  : isPayment
                                  ? `Payment Settlement (${entry.paymentMode || 'Cash'})`
                                  : 'Khata Adjustment'}
                              </p>
                              <p className="text-[11px] text-slate-400 mt-0.5">
                                {entry.date} {entry.slipNo && `• Memo: ${entry.slipNo}`}{' '}
                                {entry.vehicleNo && `• Veh: ${entry.vehicleNo}`}
                              </p>
                              {entry.notes && (
                                <p className="text-[10px] text-slate-500 italic mt-0.5">{entry.notes}</p>
                              )}
                            </div>
                          </div>

                          <div className="text-right">
                            <p
                              className={`font-mono font-bold text-sm ${
                                isSale ? 'text-rose-400' : 'text-emerald-400'
                              }`}
                            >
                              {isSale ? '+' : '-'}₹{entry.amount.toLocaleString()}
                            </p>
                            <span className="text-[10px] font-mono text-slate-400">
                              Bal: ₹{entry.balanceAfter.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="h-48 flex items-center justify-center text-xs text-slate-500 italic">
                    No transactions recorded for this customer yet.
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
              <FileSpreadsheet className="w-12 h-12 stroke-[1.2] text-slate-700 mb-3" />
              <h4 className="text-sm font-bold text-slate-400">Select a Customer Khata</h4>
              <p className="text-xs max-w-sm mt-1">
                Choose a customer account from the left directory to view full credit statements, post settlements, or trigger WhatsApp balance reminders.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* MODAL: ADD CUSTOMER */}
      {showAddCustomerModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">Create Customer Khata</h3>
            <p className="text-xs text-slate-400 mb-4">
              Register a customer or transport firm for credit fuel dispensing.
            </p>

            <form onSubmit={handleCreateCustomer} className="space-y-3.5">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Customer / Firm Name *</label>
                <input
                  type="text"
                  required
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  placeholder="e.g. Jaswant Singh (Harvester)"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Mobile Phone (WhatsApp) *</label>
                <input
                  type="tel"
                  required
                  value={newCustPhone}
                  onChange={(e) => setNewCustPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Vehicle Numbers (Comma separated)</label>
                <input
                  type="text"
                  value={newCustVehicles}
                  onChange={(e) => setNewCustVehicles(e.target.value)}
                  placeholder="e.g. PB-10-XX-1234, PB-10-YY-5678"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Approved Credit Limit (INR)</label>
                <input
                  type="number"
                  step="1000"
                  value={newCustLimit}
                  onChange={(e) => setNewCustLimit(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Address / Village / Notes</label>
                <input
                  type="text"
                  value={newCustAddress}
                  onChange={(e) => setNewCustAddress(e.target.value)}
                  placeholder="Village / Farm location"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddCustomerModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Save to Firestore
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: RECEIVE PAYMENT */}
      {showPaymentModal && selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">Receive Khata Settlement</h3>
            <p className="text-xs text-slate-400 mb-4">
              Customer: <strong className="text-amber-400">{selectedCustomer.name}</strong> • Due: ₹{selectedCustomer.currentBalance.toLocaleString()}
            </p>

            <form onSubmit={handleRecordPayment} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Amount to Settle (INR) *</label>
                <input
                  type="number"
                  step="1"
                  required
                  min="1"
                  max={selectedCustomer.currentBalance * 2}
                  value={paymentAmount || ''}
                  placeholder="Enter amount..."
                  onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-base font-mono font-bold text-white focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Payment Mode</label>
                <select
                  value={paymentMode}
                  onChange={(e) => setPaymentMode(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400"
                >
                  <option value="CASH">Cash in Hand</option>
                  <option value="UPI">UPI / PhonePe / GPay</option>
                  <option value="CHEQUE">Bank Cheque</option>
                  <option value="BANK_TRANSFER">NEFT / RTGS Transfer</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">Notes / Receipt Reference</label>
                <input
                  type="text"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  placeholder="e.g. Received at pump counter / Cheque #5544"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || paymentAmount <= 0}
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Confirm & Update Balance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
