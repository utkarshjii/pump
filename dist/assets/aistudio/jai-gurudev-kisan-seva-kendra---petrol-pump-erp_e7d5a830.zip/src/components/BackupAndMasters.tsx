import React, { useState } from 'react';
import {
  Download,
  Upload,
  Layers,
  Database,
  Gauge,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  HardDrive,
  FileCode,
  ShieldCheck,
  Edit2,
} from 'lucide-react';
import { Nozzle, Tank, Staff } from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import {
  exportAllFirestoreData,
  importFirestoreData,
  updateNozzle,
  updateTankStock,
  bootstrapFirestoreIfEmpty,
} from '../services/firestoreService';

interface BackupAndMastersProps {
  nozzles: Nozzle[];
  tanks: Tank[];
  currentStaff: Staff;
}

export const BackupAndMasters: React.FC<BackupAndMastersProps> = ({
  nozzles,
  tanks,
  currentStaff,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Nozzle calibration edit state
  const [editingNozzle, setEditingNozzle] = useState<Nozzle | null>(null);
  const [newTotalizer, setNewTotalizer] = useState<number>(0);

  const handleExportBackup = async () => {
    setIsExporting(true);
    setStatusMsg(null);
    try {
      const data = await exportAllFirestoreData();
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `JAI_GURUDEV_PUMP_${PUMP_CONFIG.code}_BACKUP_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setStatusMsg({
        type: 'success',
        text: 'Full Cloud Firestore JSON Backup exported and downloaded successfully!',
      });
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: 'Failed to export backup: ' + err.message });
    } finally {
      setIsExporting(false);
    }
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm('Warning: Restoring from JSON backup will merge records into Cloud Firestore. Proceed?')) {
      return;
    }

    setIsImporting(true);
    setStatusMsg(null);
    try {
      const text = await file.text();
      const jsonData = JSON.parse(text);
      await importFirestoreData(jsonData);
      setStatusMsg({
        type: 'success',
        text: 'Backup restored successfully into Cloud Firestore!',
      });
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: 'Error restoring backup: ' + err.message });
    } finally {
      setIsImporting(false);
      e.target.value = '';
    }
  };

  const handleSaveCalibration = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingNozzle) return;
    try {
      await updateNozzle(editingNozzle.id, {
        lastTotalizer: newTotalizer,
        calibrationDate: new Date().toISOString().split('T')[0],
      });
      setStatusMsg({
        type: 'success',
        text: `Nozzle ${editingNozzle.nozzleNumber} calibrated to ${newTotalizer} L in Firestore!`,
      });
      setEditingNozzle(null);
    } catch {
      setStatusMsg({ type: 'error', text: 'Failed to update nozzle totalizer.' });
    }
  };

  const handleReseedDefaults = async () => {
    if (!confirm('Reseed empty collections with station master records?')) return;
    try {
      await bootstrapFirestoreIfEmpty();
      setStatusMsg({ type: 'success', text: 'Firestore collections verified and reseeded!' });
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message });
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <Database className="w-5 h-5" />
            </span>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                SYSTEM CONFIGURATION & CLOUD ARCHIVE
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Backup, Restore & Dispenser Masters
              </h2>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Export JSON database snapshots, calibrate electronic nozzle totalizers, and review master parameters.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportBackup}
            disabled={isExporting}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-md transition disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Exporting...' : 'Export JSON Backup'}</span>
          </button>
        </div>
      </div>

      {statusMsg && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between shadow-lg ${
            statusMsg.type === 'success'
              ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
              : 'bg-rose-500/15 border border-rose-500/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
            <span>{statusMsg.text}</span>
          </div>
          <button onClick={() => setStatusMsg(null)} className="font-bold underline text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* SECTION 1: DATABASE BACKUP & RESTORE */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Export Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <Download className="w-5 h-5 text-amber-400" />
              <span>Full Database JSON Export</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Downloads a timestamped JSON snapshot of all 12 Cloud Firestore collections (`machine_sales`, `tanks`, `nozzles`, `customers`, `customer_ledger`, `vouchers`, `daily_dips`, `density_records`, `shifts`, `staff`).
            </p>
          </div>

          <button
            type="button"
            onClick={handleExportBackup}
            disabled={isExporting}
            className="w-full py-3 rounded-xl bg-slate-950 border border-slate-700 hover:border-amber-400 text-amber-400 font-bold text-xs flex items-center justify-center gap-2 transition"
          >
            <HardDrive className="w-4 h-4" />
            <span>Download Offline Backup File (.json)</span>
          </button>
        </div>

        {/* Restore Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <Upload className="w-5 h-5 text-blue-400" />
              <span>Restore Database from Backup</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Upload a previously exported JSON backup file to merge and restore customer accounts, bills, and stock records to Cloud Firestore.
            </p>
          </div>

          <label className="w-full py-3 rounded-xl bg-slate-950 border border-slate-700 hover:border-blue-400 text-blue-400 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer">
            <FileCode className="w-4 h-4" />
            <span>{isImporting ? 'Restoring to Cloud...' : 'Choose JSON Backup File to Restore'}</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportFile}
              disabled={isImporting}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* SECTION 2: NOZZLE ELECTRONIC TOTALIZER MASTERS & CALIBRATION */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Gauge className="w-5 h-5 text-amber-400" />
              <span>Dispenser Nozzle Totalizer Masters</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Electronic cumulative meter readings across Tokheim Front Bay DU-1 and Midco Rear Bay DU-2.
            </p>
          </div>
          <button
            type="button"
            onClick={handleReseedDefaults}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-mono"
            title="Check database seeds"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Verify Seeds</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {nozzles.map((nz) => (
            <div
              key={nz.id}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded text-[11px]">
                    Nozzle #{nz.nozzleNumber}
                  </span>
                  <span
                    className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      nz.fuelType === 'MS'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-blue-500/20 text-blue-300'
                    }`}
                  >
                    {nz.fuelType === 'MS' ? 'Petrol' : 'Diesel'}
                  </span>
                </div>
                <h4 className="font-bold text-white text-sm">{nz.machineName}</h4>
                <div className="mt-3">
                  <span className="text-[10px] font-mono text-slate-500 uppercase">Cumulative Totalizer</span>
                  <p className="text-lg font-mono font-black text-white">{nz.lastTotalizer.toFixed(1)} L</p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                <span>Calib: {nz.calibrationDate}</span>
                <button
                  type="button"
                  onClick={() => {
                    setEditingNozzle(nz);
                    setNewTotalizer(nz.lastTotalizer);
                  }}
                  className="text-amber-400 hover:text-amber-300 font-bold underline flex items-center gap-1"
                >
                  <Edit2 className="w-3 h-3" />
                  <span>Calibrate</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 3: TANK STORAGE MASTERS (STRICT 20k L DIESEL GUARD) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <h3 className="font-bold text-white text-base pb-3 border-b border-slate-800">
          Underground Fuel Tank Masters
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {tanks.map((tank) => (
            <div key={tank.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-base">{tank.fuelName}</span>
                <span className="font-mono text-slate-400">Tank #{tank.tankNumber}</span>
              </div>
              <div className="flex justify-between text-slate-400 font-mono">
                <span>Design Capacity Limit:</span>
                <span className="text-white font-bold">
                  {tank.capacityLitres.toLocaleString()} L{' '}
                  {tank.fuelType === 'HSD' && <span className="text-amber-400">(Strict Guard Enforced)</span>}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 font-mono">
                <span>Current Calibrated Stock:</span>
                <span className="text-amber-400 font-black text-base">
                  {tank.currentStockLitres.toLocaleString()} L
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL: CALIBRATE NOZZLE */}
      {editingNozzle && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-black text-white mb-1">
              Calibrate Nozzle #{editingNozzle.nozzleNumber} ({editingNozzle.fuelType})
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              {editingNozzle.machineName} • Current totalizer: {editingNozzle.lastTotalizer} L
            </p>

            <form onSubmit={handleSaveCalibration} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  New Totalizer Reading (Litres) *
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={newTotalizer}
                  onChange={(e) => setNewTotalizer(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-base font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingNozzle(null)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  Save to Firestore
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
