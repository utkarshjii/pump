import React, { useState, useEffect } from 'react';
import {
  Fuel,
  Droplet,
  IndianRupee,
  Users,
  Gauge,
  ArrowUpRight,
  Clock,
  AlertTriangle,
  Receipt,
  FileSpreadsheet,
  Layers,
  Thermometer,
  ShieldCheck,
  TrendingUp,
  CreditCard,
  QrCode,
  Banknote,
  Edit3,
  Check,
  Lock,
  CheckCircle2,
  X,
} from 'lucide-react';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import {
  Tank,
  MachineSaleRecord,
  Customer,
  Shift,
  Product,
  Staff,
  Voucher,
} from '../types/pump';
import { updateProduct } from '../services/firestoreService';

interface DashboardProps {
  tanks: Tank[];
  salesRecords: MachineSaleRecord[];
  customers: Customer[];
  shifts: Shift[];
  products: Product[];
  vouchers: Voucher[];
  currentStaff: Staff;
  onNavigate: (tabId: string) => void;
  onOpenOwnerAdmin: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  tanks,
  salesRecords,
  customers,
  shifts,
  products,
  vouchers,
  currentStaff,
  onNavigate,
  onOpenOwnerAdmin,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  // Role Checks
  const isAuthorizedAdmin = currentStaff.role === 'OWNER' || currentStaff.role === 'MANAGER';
  const isSalesman = currentStaff.role === 'SALESMAN';

  // Today's Sales
  const todaySales = salesRecords.filter((s) => s.date === todayStr);
  const totalSalesRevenue = todaySales.reduce((sum, s) => sum + (s.grossTotal || 0), 0);
  const totalPetrolLitres = todaySales.reduce((sum, s) => sum + (s.petrolLitres || 0), 0);
  const totalDieselLitres = todaySales.reduce((sum, s) => sum + (s.dieselLitres || 0), 0);
  const totalLubeRevenue = todaySales.reduce((sum, s) => sum + (s.lubeAmount || 0), 0);

  // Today's Payment Collections
  const todayCash = todaySales.reduce((sum, s) => sum + (s.cashAmount || 0), 0);
  const todayUpi = todaySales.reduce((sum, s) => sum + (s.upiAmount || 0), 0);
  const todayPos = todaySales.reduce((sum, s) => sum + (s.posAmount || 0), 0);
  const todayCredit = todaySales.reduce((sum, s) => sum + (s.creditAmount || 0), 0);

  // Tanks
  const dieselTank = tanks.find((t) => t.fuelType === 'HSD') || {
    capacityLitres: 20000,
    currentStockLitres: 14800,
    currentDipCm: 168.0,
  };
  const petrolTank = tanks.find((t) => t.fuelType === 'MS') || {
    capacityLitres: 15000,
    currentStockLitres: 11250,
    currentDipCm: 142.5,
  };

  const isDieselExceeded = dieselTank.currentStockLitres > 20000;
  const isDieselNearLimit = dieselTank.currentStockLitres >= 19000;

  // Customers Khata
  const totalKhataOutstanding = customers.reduce((sum, c) => sum + (c.currentBalance || 0), 0);
  const customersWithDue = customers.filter((c) => c.currentBalance > 0);

  // Active shift
  const activeShift = shifts.find((s) => s.status === 'OPEN') || {
    shiftName: 'Day Shift (06:00 - 18:00)',
    cashierName: 'Ajay (Manager)',
    openingCash: 15000,
  };

  // Fuel Products & Quick Rate Editor State
  const msProd = products.find((p) => p.fuelType === 'MS') || { id: 'prod-ms', price: PUMP_CONFIG.defaultRates.petrol };
  const hsdProd = products.find((p) => p.fuelType === 'HSD') || { id: 'prod-hsd', price: PUMP_CONFIG.defaultRates.diesel };

  const [isEditingRates, setIsEditingRates] = useState(false);
  const [newPetrolRate, setNewPetrolRate] = useState<number>(msProd.price);
  const [newDieselRate, setNewDieselRate] = useState<number>(hsdProd.price);
  const [isSavingRates, setIsSavingRates] = useState(false);
  const [rateFeedback, setRateFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [salesmanAlert, setSalesmanAlert] = useState<string>('');

  useEffect(() => {
    if (msProd.price) setNewPetrolRate(msProd.price);
  }, [msProd.price]);

  useEffect(() => {
    if (hsdProd.price) setNewDieselRate(hsdProd.price);
  }, [hsdProd.price]);

  const handleSaveRates = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthorizedAdmin) {
      setRateFeedback({ type: 'error', text: 'Unauthorized: Only Owner & Manager can update daily rates.' });
      return;
    }

    try {
      setIsSavingRates(true);
      setRateFeedback(null);
      if (msProd.id) {
        await updateProduct(msProd.id, { price: Number(newPetrolRate) });
      }
      if (hsdProd.id) {
        await updateProduct(hsdProd.id, { price: Number(newDieselRate) });
      }
      setRateFeedback({
        type: 'success',
        text: `Daily rates updated in Cloud Firestore! Petrol (MS): ₹${newPetrolRate.toFixed(2)}/L • Diesel (HSD): ₹${newDieselRate.toFixed(2)}/L`,
      });
      setIsEditingRates(false);
      setTimeout(() => setRateFeedback(null), 5000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to update rates';
      setRateFeedback({ type: 'error', text: msg });
    } finally {
      setIsSavingRates(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* STRICT DIESEL TANK GUARD NOTIFICATION */}
      {isDieselExceeded && (
        <div className="p-4 rounded-3xl bg-rose-500/20 border-2 border-rose-500 text-rose-200 flex items-start gap-3 shadow-xl">
          <AlertTriangle className="w-6 h-6 text-rose-400 shrink-0 animate-bounce mt-0.5" />
          <div>
            <h3 className="font-black text-sm uppercase tracking-wider text-white">
              STRICT GUARD VIOLATION: Diesel (HSD) Tank Limit Exceeded!
            </h3>
            <p className="text-xs text-rose-200 mt-1">
              Diesel stock is currently at <strong>{dieselTank.currentStockLitres.toLocaleString()} L</strong>, which breaches the strict limit of <strong>20,000 Litres</strong> for Tank 2!
            </p>
          </div>
        </div>
      )}

      {/* Salesman Access Restricted Notification */}
      {salesmanAlert && (
        <div className="p-4 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs sm:text-sm flex items-center justify-between shadow-xl">
          <div className="flex items-center gap-2.5">
            <Lock className="w-5 h-5 text-amber-400 shrink-0" />
            <span>{salesmanAlert}</span>
          </div>
          <button
            type="button"
            onClick={() => setSalesmanAlert('')}
            className="text-amber-400 hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Hero Station Banner & Rates Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-1 rounded-lg bg-amber-400 font-mono font-bold text-slate-950 text-xs tracking-wider">
                PUMP CODE: {PUMP_CONFIG.code}
              </span>
              <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Live Firestore ERP
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-2">
              {PUMP_CONFIG.name}
            </h2>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
              <span>Owner: <strong className="text-slate-200 font-semibold">{PUMP_CONFIG.owner}</strong></span>
              <span>•</span>
              <span>Manager: <strong className="text-slate-200 font-semibold">{PUMP_CONFIG.manager}</strong></span>
              <span>•</span>
              <span>Active Shift: <strong className="text-amber-400">{activeShift.shiftName}</strong></span>
            </p>
          </div>

          {/* Today's Fuel Rates Widgets + Quick Edit for Owner & Manager */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
            {/* Petrol (MS) Widget */}
            <div className="p-3 sm:p-4 rounded-2xl bg-slate-950 border border-emerald-500/30 text-right min-w-[145px]">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Petrol (MS)</span>
                <Fuel className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <p className="text-lg sm:text-xl font-mono font-black text-emerald-400">
                ₹{msProd.price.toFixed(2)}
              </p>
              <span className="text-[10px] text-slate-500 font-mono">per Litre</span>
            </div>

            {/* Diesel (HSD) Widget */}
            <div className="p-3 sm:p-4 rounded-2xl bg-slate-950 border border-blue-500/30 text-right min-w-[145px]">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Diesel (HSD)</span>
                <Droplet className="w-3.5 h-3.5 text-blue-400" />
              </div>
              <p className="text-lg sm:text-xl font-mono font-black text-blue-400">
                ₹{hsdProd.price.toFixed(2)}
              </p>
              <span className="text-[10px] text-slate-500 font-mono">per Litre</span>
            </div>

            {/* Quick Rate Change Button / Lock Indicator */}
            {isAuthorizedAdmin ? (
              <button
                type="button"
                onClick={() => setIsEditingRates(!isEditingRates)}
                className={`p-3 sm:p-4 rounded-2xl border text-center flex flex-col items-center justify-center transition min-w-[130px] ${
                  isEditingRates
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-lg shadow-amber-500/20'
                    : 'bg-slate-950/80 hover:bg-slate-800 text-amber-400 border-amber-500/40'
                }`}
                title="Quickly adjust daily Petrol and Diesel rates"
              >
                <Edit3 className="w-4 h-4 mb-1" />
                <span className="text-xs font-bold font-sans">
                  {isEditingRates ? 'Close Rates' : 'Update Rates'}
                </span>
                <span className="text-[9px] font-mono opacity-80">Owner / Manager</span>
              </button>
            ) : (
              <div className="p-3 rounded-2xl bg-slate-950/50 border border-slate-800 text-center flex flex-col items-center justify-center min-w-[130px]">
                <Lock className="w-4 h-4 text-slate-500 mb-1" />
                <span className="text-[11px] font-medium text-slate-400">Rates Locked</span>
                <span className="text-[9px] font-mono text-slate-600">Admin Managed</span>
              </div>
            )}
          </div>
        </div>

        {/* Feedback Alert for Rates */}
        {rateFeedback && (
          <div
            className={`mt-4 p-3.5 rounded-2xl text-xs flex items-center justify-between shadow-lg ${
              rateFeedback.type === 'success'
                ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
                : 'bg-rose-500/15 border border-rose-500/40 text-rose-300'
            }`}
          >
            <div className="flex items-center gap-2">
              {rateFeedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>{rateFeedback.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setRateFeedback(null)}
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* QUICK DAILY FUEL RATE UPDATE WIDGET (EXPANDED FORM FOR OWNER & MANAGER) */}
        {isEditingRates && isAuthorizedAdmin && (
          <form
            onSubmit={handleSaveRates}
            className="mt-5 p-4 sm:p-5 rounded-2xl bg-slate-950 border border-amber-500/50 shadow-2xl space-y-4 animate-fadeIn"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-white text-sm">
                  Quick Daily Fuel Rate Adjuster (Owner & Manager)
                </h3>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Effective immediately across all dispenser bills
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Petrol (MS) Rate Input */}
              <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/30">
                <label className="block text-[11px] font-mono uppercase text-emerald-400 font-bold mb-1">
                  Petrol (Motor Spirit - MS) Rate (₹ / Litre)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400 font-mono font-bold">₹</span>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    value={newPetrolRate}
                    onChange={(e) => setNewPetrolRate(parseFloat(e.target.value) || 0)}
                    className="w-full pl-7 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg font-mono font-bold text-white text-base focus:outline-none focus:border-emerald-400"
                  />
                </div>
                <div className="flex items-center gap-1.5 mt-2">
                  <button
                    type="button"
                    onClick={() => setNewPetrolRate((prev) => Number((prev + 0.1).toFixed(2)))}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    +0.10
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewPetrolRate((prev) => Number((prev - 0.1).toFixed(2)))}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    -0.10
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewPetrolRate((prev) => Number((prev + 0.5).toFixed(2)))}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    +0.50
                  </button>
                </div>
              </div>

              {/* Diesel (HSD) Rate Input */}
              <div className="p-3 rounded-xl bg-slate-900 border border-blue-500/30">
                <label className="block text-[11px] font-mono uppercase text-blue-400 font-bold mb-1">
                  Diesel (High Speed Diesel - HSD) Rate (₹ / Litre)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400 font-mono font-bold">₹</span>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    value={newDieselRate}
                    onChange={(e) => setNewDieselRate(parseFloat(e.target.value) || 0)}
                    className="w-full pl-7 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg font-mono font-bold text-white text-base focus:outline-none focus:border-blue-400"
                  />
                </div>
                <div className="flex items-center gap-1.5 mt-2">
                  <button
                    type="button"
                    onClick={() => setNewDieselRate((prev) => Number((prev + 0.1).toFixed(2)))}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    +0.10
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewDieselRate((prev) => Number((prev - 0.1).toFixed(2)))}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    -0.10
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewDieselRate((prev) => Number((prev + 0.5).toFixed(2)))}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    +0.50
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsEditingRates(false)}
                className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSavingRates}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 transition flex items-center gap-1.5 disabled:opacity-50"
              >
                {isSavingRates ? (
                  <span>Saving to Cloud Firestore...</span>
                ) : (
                  <>
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>Save Daily Rates</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* 4 Main Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {/* Today's Sales */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span className="font-mono uppercase text-[10px]">Today's Sales Revenue</span>
              <IndianRupee className="w-4 h-4 text-amber-400" />
            </div>
            <p className="text-2xl font-mono font-black text-amber-400 mt-2">
              ₹{totalSalesRevenue.toLocaleString()}
            </p>
            <p className="text-[11px] text-slate-500 font-mono mt-1">
              MS: {totalPetrolLitres.toFixed(1)} L • HSD: {totalDieselLitres.toFixed(1)} L
            </p>
          </div>

          {/* Cash In Hand / Drawer */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/30 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span className="font-mono uppercase text-[10px] text-emerald-400 font-bold">Today Cash In Drawer</span>
              <Banknote className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-2xl font-mono font-black text-emerald-400 mt-2">
              ₹{todayCash.toLocaleString()}
            </p>
            <p className="text-[11px] text-slate-500 font-mono mt-1">
              Float: ₹{(activeShift.openingCash || 0).toLocaleString()}
            </p>
          </div>

          {/* Digital UPI & POS Cards */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span className="font-mono uppercase text-[10px]">UPI & POS Digital</span>
              <QrCode className="w-4 h-4 text-blue-400" />
            </div>
            <p className="text-2xl font-mono font-black text-blue-400 mt-2">
              ₹{(todayUpi + todayPos).toLocaleString()}
            </p>
            <p className="text-[11px] text-slate-500 font-mono mt-1">
              UPI: ₹{todayUpi.toLocaleString()} • POS: ₹{todayPos.toLocaleString()}
            </p>
          </div>

          {/* Khata Outstanding */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span className="font-mono uppercase text-[10px] text-amber-300">Khata Outstanding</span>
              <Users className="w-4 h-4 text-amber-400" />
            </div>
            <p className="text-2xl font-mono font-black text-rose-400 mt-2">
              ₹{totalKhataOutstanding.toLocaleString()}
            </p>
            <p className="text-[11px] text-slate-500 font-mono mt-1">
              {customersWithDue.length} accounts with balance due
            </p>
          </div>
        </div>
      </div>

      {/* Live Tank Stock Telemetry (With Diesel 20,000L Strict Guard) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Tank 1: Petrol MS */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                <Fuel className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">Tank 1</span>
                <h3 className="font-bold text-white text-base">Petrol (Motor Spirit - MS)</h3>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Dip Level</span>
              <p className="font-mono font-bold text-emerald-400 text-base">{petrolTank.currentDipCm} cm</p>
            </div>
          </div>

          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Current Stock:</span>
              <span className="text-white font-bold">
                {petrolTank.currentStockLitres.toLocaleString()} L / {petrolTank.capacityLitres.toLocaleString()} L
              </span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-3.5 p-0.5 border border-slate-800 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all"
                style={{ width: `${Math.min(100, (petrolTank.currentStockLitres / petrolTank.capacityLitres) * 100)}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-500 font-mono">
              <span>{((petrolTank.currentStockLitres / petrolTank.capacityLitres) * 100).toFixed(1)}% Full</span>
              <span>Capacity: 15,000 L</span>
            </div>
          </div>
        </div>

        {/* Tank 2: Diesel HSD (Strict Guard 20k L) */}
        <div
          className={`bg-slate-900 border rounded-3xl p-6 shadow-xl ${
            isDieselExceeded
              ? 'border-rose-500 ring-2 ring-rose-500/50'
              : isDieselNearLimit
              ? 'border-amber-500/60'
              : 'border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-blue-500/15 text-blue-400 border border-blue-500/30">
                <Droplet className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-blue-400 font-bold uppercase">Tank 2</span>
                  <span className="text-[9px] font-mono font-black bg-rose-500/20 text-rose-300 border border-rose-500/30 px-1.5 py-0.5 rounded">
                    STRICT GUARD: 20k L
                  </span>
                </div>
                <h3 className="font-bold text-white text-base">Diesel (High Speed Diesel - HSD)</h3>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Dip Level</span>
              <p className="font-mono font-bold text-blue-400 text-base">{dieselTank.currentDipCm} cm</p>
            </div>
          </div>

          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Current Stock:</span>
              <span className={`font-bold ${isDieselExceeded ? 'text-rose-400 font-black' : 'text-white'}`}>
                {dieselTank.currentStockLitres.toLocaleString()} L / 20,000 L
              </span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-3.5 p-0.5 border border-slate-800 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${
                  isDieselExceeded ? 'bg-rose-500' : isDieselNearLimit ? 'bg-amber-400' : 'bg-blue-500'
                }`}
                style={{ width: `${Math.min(100, (dieselTank.currentStockLitres / 20000) * 100)}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-500 font-mono">
              <span>{((dieselTank.currentStockLitres / 20000) * 100).toFixed(1)}% Capacity</span>
              <span className="text-amber-400 font-bold">Strict Max Limit: 20,000 L</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Launchpad to All Station ERP Modules */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-4 font-bold">
          Station Operations Launchpad (Alag Modules)
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {[
            { id: 'daily-sales', label: 'Daily Sales Entry', icon: Receipt, desc: 'Tokheim & Midco DU', allowedForSalesman: true },
            { id: 'shift-salesman', label: 'Shift & Salesman', icon: Clock, desc: 'Cash Drawer & Shifts', allowedForSalesman: true },
            { id: 'stock-dips', label: 'Stock and Dips', icon: Gauge, desc: 'Tanks & Dip Chart', allowedForSalesman: false },
            { id: 'sales-billing', label: 'Sales & Billing', icon: FileSpreadsheet, desc: 'Bills & Invoice Memos', allowedForSalesman: false },
            { id: 'khata-udhar', label: 'Khata / Udhar', icon: Users, desc: 'Credit Ledger & WhatsApp', allowedForSalesman: false },
            { id: 'voucher-rates', label: 'Voucher & Rates', icon: IndianRupee, desc: 'Fuel Rates & Expenses', allowedForSalesman: false },
            { id: 'day-book-pnl', label: 'Day Book & P&L', icon: TrendingUp, desc: 'Roznamcha & Profit/Loss', allowedForSalesman: false },
            { id: 'density-decantation', label: 'Density & Tankers', icon: Thermometer, desc: '15°C Hydrometer & OMC', allowedForSalesman: false },
            { id: 'backup-masters', label: 'Backup & Masters', icon: Layers, desc: 'JSON Export & Calibrations', allowedForSalesman: false },
            { id: 'owner-admin', label: 'Owner Admin CRUD', icon: ShieldCheck, desc: 'Code: 331047 Master', allowedForSalesman: false },
          ].map((item) => {
            const Icon = item.icon;
            const isLocked = isSalesman && !item.allowedForSalesman;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  if (isLocked) {
                    setSalesmanAlert(
                      `Access Restricted: Salesman (${currentStaff.name}) can only access Dashboard, Daily Sales Entry, and Shift/Salesman sections. Administrative records and deletion are reserved for Manager and Owner.`
                    );
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    return;
                  }

                  if (item.id === 'owner-admin') {
                    onOpenOwnerAdmin();
                  } else {
                    onNavigate(item.id);
                  }
                }}
                className={`p-4 rounded-2xl border text-left transition group relative ${
                  isLocked
                    ? 'bg-slate-950/40 border-slate-900 opacity-60 hover:border-slate-800'
                    : 'bg-slate-950 border-slate-800/80 hover:border-amber-400/50 hover:bg-slate-800/40'
                }`}
              >
                {isLocked && (
                  <span className="absolute top-3 right-3 text-[9px] font-mono font-bold bg-slate-900 text-slate-500 border border-slate-800 px-1.5 py-0.5 rounded flex items-center gap-1">
                    <Lock className="w-2.5 h-2.5" /> Admin Only
                  </span>
                )}
                <div
                  className={`p-2 rounded-xl w-fit mb-2 transition ${
                    isLocked
                      ? 'bg-slate-900 text-slate-500'
                      : 'bg-slate-900 text-amber-400 group-hover:scale-110'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <h4
                  className={`font-bold text-xs sm:text-sm ${
                    isLocked ? 'text-slate-400' : 'text-white group-hover:text-amber-300'
                  }`}
                >
                  {item.label}
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5 truncate">{item.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent Activity Ticker */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="font-bold text-white text-base">Recent Dispenser Sales Bills</h3>
          <button
            type="button"
            onClick={() => onNavigate('sales-billing')}
            className="text-amber-400 hover:text-amber-300 text-xs font-bold underline"
          >
            View Full Sales Register
          </button>
        </div>

        <div className="space-y-2.5 mt-4">
          {salesRecords.slice(0, 5).map((sale) => (
            <div
              key={sale.id}
              className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{sale.machineName}</span>
                  <span className="text-[10px] font-mono text-slate-400">{sale.date}</span>
                  <span className="text-[10px] font-mono text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded">
                    By {sale.salesmanName}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 font-mono">
                  MS: {sale.petrolLitres} L • HSD: {sale.dieselLitres} L{' '}
                  {sale.creditAmount > 0 && `• Udhaar: ₹${sale.creditAmount} (${sale.customerName})`}
                </p>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-mono text-slate-500 uppercase">Gross Total</span>
                <p className="font-mono font-black text-amber-400 text-sm">
                  ₹{sale.grossTotal.toLocaleString()}
                </p>
              </div>
            </div>
          ))}

          {salesRecords.length === 0 && (
            <p className="text-xs text-slate-500 italic py-6 text-center">
              No machine sales entries logged yet.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
