import React, { useState, useEffect } from 'react';
import { StationHeader } from './components/StationHeader';
import { LoginScreen } from './components/LoginScreen';
import { Dashboard } from './components/Dashboard';
import { UnifiedSalesEntry } from './components/UnifiedSalesEntry';
import { TanksDips } from './components/TanksDips';
import { SalesBillingRegister } from './components/SalesBillingRegister';
import { ShiftSalesmanManagement } from './components/ShiftSalesmanManagement';
import { KhataLedger } from './components/KhataLedger';
import { VoucherAndRates } from './components/VoucherAndRates';
import { DayBookAndPnL } from './components/DayBookAndPnL';
import { DensityDecantation } from './components/DensityDecantation';
import { BackupAndMasters } from './components/BackupAndMasters';
import { OwnerAdminModal } from './components/OwnerAdminModal';
import { PUMP_CONFIG } from './constants/pumpConfig';
import {
  bootstrapFirestoreIfEmpty,
  subscribeToStaff,
  subscribeToTanks,
  subscribeToNozzles,
  subscribeToProducts,
  subscribeToSales,
  subscribeToCustomers,
  subscribeToCustomerLedger,
  subscribeToTankerReceipts,
  subscribeToDailyDips,
  subscribeToVouchers,
  subscribeToDensityRecords,
  subscribeToShifts,
} from './services/firestoreService';
import {
  Staff,
  Tank,
  Nozzle,
  Product,
  MachineSaleRecord,
  Customer,
  CustomerLedgerEntry,
  TankerReceipt,
  DailyDip,
  Voucher,
  DensityRecord,
  Shift,
} from './types/pump';
import { testConnection } from './lib/firebase';

export default function App() {
  const [currentStaff, setCurrentStaff] = useState<Staff | null>(null);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState<boolean>(false);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);

  // Live Firestore State Collections initialized with PUMP_CONFIG defaults
  const [staffList, setStaffList] = useState<Staff[]>(PUMP_CONFIG.defaultStaff);
  const [tanks, setTanks] = useState<Tank[]>(PUMP_CONFIG.tanks);
  const [nozzles, setNozzles] = useState<Nozzle[]>([]);
  const [products, setProducts] = useState<Product[]>(PUMP_CONFIG.defaultProducts);
  const [salesRecords, setSalesRecords] = useState<MachineSaleRecord[]>([]);
  const [customers, setCustomers] = useState<Customer[]>(PUMP_CONFIG.defaultCustomers);
  const [customerLedger, setCustomerLedger] = useState<CustomerLedgerEntry[]>([]);
  const [tankerReceipts, setTankerReceipts] = useState<TankerReceipt[]>([]);
  const [dailyDips, setDailyDips] = useState<DailyDip[]>([]);
  const [densityRecords, setDensityRecords] = useState<DensityRecord[]>([]);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);

  // Initialize and subscribe to Firestore
  useEffect(() => {
    let unsubs: (() => void)[] = [];

    async function initApp() {
      try {
        await testConnection();
        await bootstrapFirestoreIfEmpty();
      } catch (err) {
        console.warn('Initial bootstrap warning:', err);
      } finally {
        setIsInitializing(false);
      }

      try {
        unsubs.push(
          subscribeToStaff((data) => setStaffList(data)),
          subscribeToTanks((data) => setTanks(data)),
          subscribeToNozzles((data) => setNozzles(data)),
          subscribeToProducts((data) => setProducts(data)),
          subscribeToSales((data) => setSalesRecords(data)),
          subscribeToCustomers((data) => setCustomers(data)),
          subscribeToCustomerLedger(null, (data) => setCustomerLedger(data)),
          subscribeToTankerReceipts((data) => setTankerReceipts(data)),
          subscribeToDailyDips((data) => setDailyDips(data)),
          subscribeToDensityRecords((data) => setDensityRecords(data)),
          subscribeToVouchers((data) => setVouchers(data)),
          subscribeToShifts((data) => setShifts(data))
        );
      } catch (err) {
        console.error('Initialization error:', err);
      } finally {
        setIsInitializing(false);
      }
    }

    initApp();

    return () => {
      unsubs.forEach((unsub) => unsub());
    };
  }, []);

  // Diesel Tank live level for header telemetry & strict guard check
  const dieselTank = tanks.find((t) => t.fuelType === 'HSD') || { currentStockLitres: 14800 };

  const handleLogout = () => {
    setCurrentStaff(null);
  };

  // Strict RBAC Route Guard: Salesmen can only access Dashboard, Daily Sales, and Shift/Salesman
  useEffect(() => {
    if (currentStaff?.role === 'SALESMAN') {
      const allowedSalesmanTabs = ['dashboard', 'daily-sales', 'shift-salesman'];
      if (!allowedSalesmanTabs.includes(activeTab)) {
        setActiveTab('dashboard');
      }
    }
  }, [currentStaff, activeTab]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Station Header with all 11 explicit module navigation tabs */}
      <StationHeader
        currentStaff={currentStaff}
        onLogout={handleLogout}
        onOpenOwnerModal={() => setIsOwnerModalOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        dieselStock={dieselTank.currentStockLitres || 0}
      />

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
        {isInitializing ? (
          <div className="min-h-[60vh] flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 animate-spin">
              ⛽
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Jai Gurudev Kisan Seva Kendra</h2>
              <p className="text-xs text-slate-400 mt-1">
                Connecting to Cloud Firestore & Synchronizing Machine Totalizers...
              </p>
            </div>
          </div>
        ) : !currentStaff ? (
          <LoginScreen
            staffList={staffList}
            onLoginSuccess={(staff) => setCurrentStaff(staff)}
            isLoading={isInitializing}
          />
        ) : (
          <div className="animate-fadeIn">
            {/* 1. DASHBOARD */}
            {activeTab === 'dashboard' && (
              <Dashboard
                tanks={tanks}
                salesRecords={salesRecords}
                customers={customers}
                shifts={shifts}
                products={products}
                vouchers={vouchers}
                currentStaff={currentStaff}
                onNavigate={(tabId) => setActiveTab(tabId)}
                onOpenOwnerAdmin={() => setIsOwnerModalOpen(true)}
              />
            )}

            {/* 2. DAILY SALES ENTRY (WITH SHIFT METER AUTO-ROLLOVER) */}
            {activeTab === 'daily-sales' && (
              <UnifiedSalesEntry
                currentStaff={currentStaff}
                tanks={tanks}
                products={products}
                customers={customers}
                nozzles={nozzles}
                salesRecords={salesRecords}
              />
            )}


            {/* 3. STOCK AND DIPS */}
            {activeTab === 'stock-dips' && (
              <TanksDips
                tanks={tanks}
                nozzles={nozzles}
                dailyDips={dailyDips}
                currentStaff={currentStaff}
              />
            )}

            {/* 4. SALES & BILLING */}
            {activeTab === 'sales-billing' && (
              <SalesBillingRegister
                salesRecords={salesRecords}
                currentStaff={currentStaff}
              />
            )}

            {/* 5. SHIFT & SALESMAN */}
            {activeTab === 'shift-salesman' && (
              <ShiftSalesmanManagement
                shifts={shifts}
                staffList={staffList}
                salesRecords={salesRecords}
                nozzles={nozzles}
                currentStaff={currentStaff}
              />
            )}

            {/* 6. KHATA / UDHAR */}
            {activeTab === 'khata-udhar' && (
              <KhataLedger
                customers={customers}
                ledgerEntries={customerLedger}
                currentStaff={currentStaff}
              />
            )}

            {/* 7. VOUCHER AND RATES */}
            {activeTab === 'voucher-rates' && (
              <VoucherAndRates
                vouchers={vouchers}
                products={products}
                currentStaff={currentStaff}
              />
            )}

            {/* 8. DAY BOOK AND P&L */}
            {activeTab === 'day-book-pnl' && (
              <DayBookAndPnL
                salesRecords={salesRecords}
                vouchers={vouchers}
                customerLedger={customerLedger}
                shifts={shifts}
              />
            )}

            {/* 9. DENSITY & DECANTATION */}
            {activeTab === 'density-decantation' && (
              <DensityDecantation
                densityRecords={densityRecords}
                tankerReceipts={tankerReceipts}
                tanks={tanks}
                currentStaff={currentStaff}
              />
            )}

            {/* 10. BACKUP AND MASTERS */}
            {activeTab === 'backup-masters' && (
              <BackupAndMasters
                nozzles={nozzles}
                tanks={tanks}
                currentStaff={currentStaff}
              />
            )}
          </div>
        )}
      </main>

      {/* 11. OWNER / ADMIN CRUD MODAL (Code: 331047) */}
      <OwnerAdminModal
        isOpen={isOwnerModalOpen}
        onClose={() => setIsOwnerModalOpen(false)}
        staffList={staffList}
        products={products}
        nozzles={nozzles}
        salesRecords={salesRecords}
        tanks={tanks}
      />

      {/* Footer Branding */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 px-6 text-center text-xs text-slate-500">
        <p>
          © 2026 <strong>Jai Gurudev Kisan Seva Kendra</strong> (Pump Code: 331047) • Owner: Ranjit Singh • Manager: Ajay
        </p>
        <p className="text-[11px] text-slate-600 mt-0.5">
          Configured for Netlify Web Deployment • Cloud Firestore Real-Time Persistence Enabled
        </p>
      </footer>
    </div>
  );
}
