import {
  collection,
  doc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  onSnapshot,
  query,
  orderBy,
  runTransaction,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { PUMP_CONFIG } from '../constants/pumpConfig';
import {
  Staff,
  Tank,
  Nozzle,
  Product,
  Shift,
  Customer,
  CustomerLedgerEntry,
  MachineSaleRecord,
  TankerReceipt,
  DailyDip,
  Voucher,
  DensityRecord,
} from '../types/pump';

export const COLLECTIONS = {
  STAFF: 'staff',
  MACHINE_SALES: 'machine_sales',
  TANKS: 'tanks',
  NOZZLES: 'nozzles',
  PRODUCTS: 'products',
  SHIFTS: 'shifts',
  CUSTOMERS: 'customers',
  CUSTOMER_LEDGER: 'customer_ledger',
  TANKER_RECEIPTS: 'tanker_receipts',
  DAILY_DIPS: 'daily_dips',
  VOUCHERS: 'vouchers',
  DENSITY_RECORDS: 'density_records',
} as const;


/**
 * Initialize Firestore data if empty to ensure initial records are persisted in Firestore
 */
export async function bootstrapFirestoreIfEmpty() {
  try {
    // 1. Staff bootstrap
    const staffSnap = await getDocs(collection(db, COLLECTIONS.STAFF));
    if (staffSnap.empty) {
      for (const member of PUMP_CONFIG.defaultStaff) {
        await setDoc(doc(db, COLLECTIONS.STAFF, member.id), member);
      }
    }

    // 2. Tanks bootstrap
    const tanksSnap = await getDocs(collection(db, COLLECTIONS.TANKS));
    if (tanksSnap.empty) {
      for (const tank of PUMP_CONFIG.tanks) {
        await setDoc(doc(db, COLLECTIONS.TANKS, tank.id), tank);
      }
    }

    // 3. Products bootstrap
    const prodSnap = await getDocs(collection(db, COLLECTIONS.PRODUCTS));
    if (prodSnap.empty) {
      for (const prod of PUMP_CONFIG.defaultProducts) {
        await setDoc(doc(db, COLLECTIONS.PRODUCTS, prod.id), prod);
      }
    }

    // 4. Nozzles bootstrap
    const nozzleSnap = await getDocs(collection(db, COLLECTIONS.NOZZLES));
    if (nozzleSnap.empty) {
      const initialNozzles: Nozzle[] = [
        {
          id: 'nz-tokheim-ms',
          nozzleNumber: 1,
          machineId: 'tokheim-du1',
          machineName: 'Tokheim Front Bay DU-1',
          fuelType: 'MS',
          lastTotalizer: 412580.4,
          calibrationDate: '2026-10-01',
          status: 'ACTIVE',
        },
        {
          id: 'nz-tokheim-hsd',
          nozzleNumber: 2,
          machineId: 'tokheim-du1',
          machineName: 'Tokheim Front Bay DU-1',
          fuelType: 'HSD',
          lastTotalizer: 893420.2,
          calibrationDate: '2026-10-01',
          status: 'ACTIVE',
        },
        {
          id: 'nz-midco-ms',
          nozzleNumber: 3,
          machineId: 'midco-du2',
          machineName: 'Midco Rear Bay DU-2',
          fuelType: 'MS',
          lastTotalizer: 284190.8,
          calibrationDate: '2026-10-01',
          status: 'ACTIVE',
        },
        {
          id: 'nz-midco-hsd',
          nozzleNumber: 4,
          machineId: 'midco-du2',
          machineName: 'Midco Rear Bay DU-2',
          fuelType: 'HSD',
          lastTotalizer: 671230.5,
          calibrationDate: '2026-10-01',
          status: 'ACTIVE',
        },
      ];
      for (const nz of initialNozzles) {
        await setDoc(doc(db, COLLECTIONS.NOZZLES, nz.id), nz);
      }
    }

    // 5. Customers bootstrap
    const custSnap = await getDocs(collection(db, COLLECTIONS.CUSTOMERS));
    if (custSnap.empty) {
      for (const cust of PUMP_CONFIG.defaultCustomers) {
        await setDoc(doc(db, COLLECTIONS.CUSTOMERS, cust.id), cust);

        // Add initial ledger balance entry
        await addDoc(collection(db, COLLECTIONS.CUSTOMER_LEDGER), {
          customerId: cust.id,
          customerName: cust.name,
          customerPhone: cust.phone,
          type: 'ADJUSTMENT',
          amount: cust.currentBalance,
          balanceAfter: cust.currentBalance,
          date: new Date().toISOString().split('T')[0],
          notes: 'Opening Khata Balance migrated to Cloud Firestore',
          recordedBy: 'Ranjit Singh (Owner)',
          createdAt: new Date().toISOString(),
        } as CustomerLedgerEntry);
      }
    }

    // 6. Active shift bootstrap if none
    const shiftSnap = await getDocs(collection(db, COLLECTIONS.SHIFTS));
    if (shiftSnap.empty) {
      await setDoc(doc(db, COLLECTIONS.SHIFTS, 'shift-current'), {
        id: 'shift-current',
        shiftName: 'Day Shift (06:00 - 18:00)',
        date: new Date().toISOString().split('T')[0],
        cashierId: 'staff-ajay',
        cashierName: 'Ajay (Manager)',
        status: 'OPEN',
        openingCash: 15000,
        startTime: '06:00 AM',
      } as Shift);
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'bootstrap');
  }
}

// -------------------------------------------------------------
// REAL-TIME SUBSCRIBERS
// -------------------------------------------------------------

export function subscribeToStaff(callback: (staff: Staff[]) => void) {
  return onSnapshot(
    collection(db, COLLECTIONS.STAFF),
    (snapshot) => {
      const staffList = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Staff, 'id'>),
      }));
      callback(staffList);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.STAFF)
  );
}

export function subscribeToTanks(callback: (tanks: Tank[]) => void) {
  return onSnapshot(
    collection(db, COLLECTIONS.TANKS),
    (snapshot) => {
      const tanks = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Tank, 'id'>),
      }));
      callback(tanks);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.TANKS)
  );
}

export function subscribeToNozzles(callback: (nozzles: Nozzle[]) => void) {
  return onSnapshot(
    collection(db, COLLECTIONS.NOZZLES),
    (snapshot) => {
      const nozzles = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Nozzle, 'id'>),
      }));
      callback(nozzles);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.NOZZLES)
  );
}

export function subscribeToProducts(callback: (products: Product[]) => void) {
  return onSnapshot(
    collection(db, COLLECTIONS.PRODUCTS),
    (snapshot) => {
      const products = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Product, 'id'>),
      }));
      callback(products);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.PRODUCTS)
  );
}

export function subscribeToSales(callback: (sales: MachineSaleRecord[]) => void) {
  const q = query(collection(db, COLLECTIONS.MACHINE_SALES), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const sales = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<MachineSaleRecord, 'id'>),
      }));
      callback(sales);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.MACHINE_SALES)
  );
}

export function subscribeToCustomers(callback: (customers: Customer[]) => void) {
  return onSnapshot(
    collection(db, COLLECTIONS.CUSTOMERS),
    (snapshot) => {
      const customers = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Customer, 'id'>),
      }));
      callback(customers);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.CUSTOMERS)
  );
}

export function subscribeToCustomerLedger(customerId: string | null, callback: (ledger: CustomerLedgerEntry[]) => void) {
  const q = query(collection(db, COLLECTIONS.CUSTOMER_LEDGER), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      let entries = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<CustomerLedgerEntry, 'id'>),
      }));
      if (customerId) {
        entries = entries.filter((e) => e.customerId === customerId);
      }
      callback(entries);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.CUSTOMER_LEDGER)
  );
}

export function subscribeToShifts(callback: (shifts: Shift[]) => void) {
  return onSnapshot(
    collection(db, COLLECTIONS.SHIFTS),
    (snapshot) => {
      const shifts = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Shift, 'id'>),
      }));
      callback(shifts);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.SHIFTS)
  );
}

export function subscribeToTankerReceipts(callback: (receipts: TankerReceipt[]) => void) {
  const q = query(collection(db, COLLECTIONS.TANKER_RECEIPTS), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const receipts = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<TankerReceipt, 'id'>),
      }));
      callback(receipts);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.TANKER_RECEIPTS)
  );
}

export function subscribeToDailyDips(callback: (dips: DailyDip[]) => void) {
  const q = query(collection(db, COLLECTIONS.DAILY_DIPS), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const dips = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<DailyDip, 'id'>),
      }));
      callback(dips);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.DAILY_DIPS)
  );
}

export function subscribeToVouchers(callback: (vouchers: Voucher[]) => void) {
  const q = query(collection(db, COLLECTIONS.VOUCHERS), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const vouchers = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Voucher, 'id'>),
      }));
      callback(vouchers);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.VOUCHERS)
  );
}

// -------------------------------------------------------------
// TRANSACTION & MUTATION HELPERS
// -------------------------------------------------------------

/**
 * Record a Unified Machine Sales Entry
 * 1. Creates document in `machine_sales`
 * 2. Deducts fuel stock from `tanks`
 * 3. Updates `nozzles` totalizer closing readings
 * 4. Posts to `customer_ledger` and increments customer `currentBalance` if Credit > 0
 */
export async function submitMachineSale(sale: Omit<MachineSaleRecord, 'id'>) {
  try {
    return await runTransaction(db, async (transaction) => {
      // 1. Post sale doc
      const saleRef = doc(collection(db, COLLECTIONS.MACHINE_SALES));
      transaction.set(saleRef, sale);

      // 2. If credit sale, update customer balance & write ledger entry
      if (sale.creditAmount > 0 && sale.customerId) {
        const custRef = doc(db, COLLECTIONS.CUSTOMERS, sale.customerId);
        const custDoc = await transaction.get(custRef);
        
        let newBalance = sale.creditAmount;
        let custName = sale.customerName || 'Customer';
        let custPhone = sale.customerPhone || '';

        if (custDoc.exists()) {
          const cData = custDoc.data() as Customer;
          newBalance = (cData.currentBalance || 0) + sale.creditAmount;
          custName = cData.name;
          custPhone = cData.phone;
          transaction.update(custRef, {
            currentBalance: newBalance,
          });
        }

        const ledgerRef = doc(collection(db, COLLECTIONS.CUSTOMER_LEDGER));
        const ledgerEntry: CustomerLedgerEntry = {
          customerId: sale.customerId,
          customerName: custName,
          customerPhone: custPhone,
          type: 'CREDIT_SALE',
          amount: sale.creditAmount,
          balanceAfter: newBalance,
          date: sale.date,
          fuelType: sale.petrolLitres > 0 && sale.dieselLitres > 0 ? 'MS + HSD' : sale.petrolLitres > 0 ? 'MS' : 'HSD',
          litres: Number((sale.petrolLitres + sale.dieselLitres).toFixed(2)),
          vehicleNo: sale.vehicleNo || '',
          slipNo: sale.slipNo || `SLIP-${Date.now().toString().slice(-6)}`,
          notes: `Dispenser: ${sale.machineName}. Recorded by ${sale.salesmanName}`,
          recordedBy: sale.salesmanName,
          createdAt: new Date().toISOString(),
        };
        transaction.set(ledgerRef, ledgerEntry);
      }

      // 3. Update live tank stocks
      if (sale.petrolLitres > 0) {
        const msTankRef = doc(db, COLLECTIONS.TANKS, 'tank-1-petrol');
        const msDoc = await transaction.get(msTankRef);
        if (msDoc.exists()) {
          const current = (msDoc.data() as Tank).currentStockLitres || 0;
          transaction.update(msTankRef, {
            currentStockLitres: Math.max(0, Number((current - sale.petrolLitres).toFixed(2))),
            lastUpdated: new Date().toISOString(),
          });
        }
      }

      if (sale.dieselLitres > 0) {
        const hsdTankRef = doc(db, COLLECTIONS.TANKS, 'tank-2-diesel');
        const hsdDoc = await transaction.get(hsdTankRef);
        if (hsdDoc.exists()) {
          const current = (hsdDoc.data() as Tank).currentStockLitres || 0;
          transaction.update(hsdTankRef, {
            currentStockLitres: Math.max(0, Number((current - sale.dieselLitres).toFixed(2))),
            lastUpdated: new Date().toISOString(),
          });
        }
      }

      // 4. Update nozzle totalizers if meter readings provided
      if (sale.entryMode === 'meter') {
        const isDU1 = sale.machineId === 'tokheim-du1';
        const msNozzleId = isDU1 ? 'nz-tokheim-ms' : 'nz-midco-ms';
        const hsdNozzleId = isDU1 ? 'nz-tokheim-hsd' : 'nz-midco-hsd';

        if (sale.petrolClosing > 0) {
          const msNzRef = doc(db, COLLECTIONS.NOZZLES, msNozzleId);
          transaction.update(msNzRef, {
            lastTotalizer: sale.petrolClosing,
          });
        }
        if (sale.dieselClosing > 0) {
          const hsdNzRef = doc(db, COLLECTIONS.NOZZLES, hsdNozzleId);
          transaction.update(hsdNzRef, {
            lastTotalizer: sale.dieselClosing,
          });
        }
      }

      return saleRef.id;
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, COLLECTIONS.MACHINE_SALES);
    throw err;
  }
}

/**
 * Record a Khata settlement payment received
 */
export async function recordCustomerPayment(
  customerId: string,
  amount: number,
  paymentMode: 'CASH' | 'UPI' | 'CHEQUE' | 'BANK_TRANSFER',
  notes: string,
  recordedBy: string
) {
  try {
    return await runTransaction(db, async (transaction) => {
      const custRef = doc(db, COLLECTIONS.CUSTOMERS, customerId);
      const custDoc = await transaction.get(custRef);
      if (!custDoc.exists()) {
        throw new Error('Customer account not found');
      }

      const custData = custDoc.data() as Customer;
      const current = custData.currentBalance || 0;
      const newBalance = Math.max(0, current - amount);

      transaction.update(custRef, {
        currentBalance: newBalance,
        lastPaymentDate: new Date().toISOString().split('T')[0],
      });

      const ledgerRef = doc(collection(db, COLLECTIONS.CUSTOMER_LEDGER));
      const entry: CustomerLedgerEntry = {
        customerId,
        customerName: custData.name,
        customerPhone: custData.phone,
        type: 'PAYMENT_RECEIVED',
        amount,
        balanceAfter: newBalance,
        date: new Date().toISOString().split('T')[0],
        paymentMode,
        notes: notes || `Payment received via ${paymentMode}`,
        recordedBy,
        createdAt: new Date().toISOString(),
      };
      transaction.set(ledgerRef, entry);
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, COLLECTIONS.CUSTOMER_LEDGER);
    throw err;
  }
}

/**
 * Add / Update Customer Khata
 */
export async function saveCustomer(customer: Omit<Customer, 'id'>, id?: string) {
  try {
    if (id) {
      await updateDoc(doc(db, COLLECTIONS.CUSTOMERS, id), customer as Partial<Customer>);
      return id;
    } else {
      const ref = await addDoc(collection(db, COLLECTIONS.CUSTOMERS), customer);
      return ref.id;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, COLLECTIONS.CUSTOMERS);
  }
}

/**
 * Delete Customer
 */
export async function deleteCustomer(id: string) {
  try {
    await deleteDoc(doc(db, COLLECTIONS.CUSTOMERS, id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, COLLECTIONS.CUSTOMERS);
  }
}

/**
 * Staff CRUD
 */
export async function saveStaff(staff: Omit<Staff, 'id'>, id?: string) {
  try {
    if (id) {
      await updateDoc(doc(db, COLLECTIONS.STAFF, id), staff as Partial<Staff>);
      return id;
    } else {
      const ref = await addDoc(collection(db, COLLECTIONS.STAFF), {
        ...staff,
        createdAt: new Date().toISOString(),
      });
      return ref.id;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, COLLECTIONS.STAFF);
  }
}

export async function deleteStaff(id: string) {
  try {
    await deleteDoc(doc(db, COLLECTIONS.STAFF, id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, COLLECTIONS.STAFF);
  }
}

/**
 * Update Fuel Rates (MS / HSD) & Products
 */
export async function updateProduct(id: string, updates: Partial<Product>) {
  try {
    await updateDoc(doc(db, COLLECTIONS.PRODUCTS, id), updates);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, COLLECTIONS.PRODUCTS);
  }
}

export async function addProduct(product: Omit<Product, 'id'>) {
  try {
    const ref = await addDoc(collection(db, COLLECTIONS.PRODUCTS), product);
    return ref.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, COLLECTIONS.PRODUCTS);
  }
}

export async function deleteProduct(id: string) {
  try {
    await deleteDoc(doc(db, COLLECTIONS.PRODUCTS, id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, COLLECTIONS.PRODUCTS);
  }
}

/**
 * Update Tank / Dip
 * Enforces STRICT GUARD: Diesel Tank capacity must NOT exceed 20,000 Litres
 */
export async function updateTankStock(tankId: string, litres: number, dipCm?: number) {
  try {
    const tankRef = doc(db, COLLECTIONS.TANKS, tankId);
    // Diesel strict guard
    if (tankId === 'tank-2-diesel' && litres > 20000) {
      throw new Error('STRICT GUARD VIOLATION: Diesel (HSD) Tank capacity is limited to maximum 20,000 Litres. Value provided: ' + litres + ' L');
    }

    const payload: Partial<Tank> = {
      currentStockLitres: litres,
      lastUpdated: new Date().toISOString(),
    };
    if (dipCm !== undefined) {
      payload.currentDipCm = dipCm;
    }

    await updateDoc(tankRef, payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, COLLECTIONS.TANKS);
  }
}

/**
 * Nozzle calibration update
 */
export async function updateNozzle(nozzleId: string, updates: Partial<Nozzle>) {
  try {
    await updateDoc(doc(db, COLLECTIONS.NOZZLES, nozzleId), updates);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, COLLECTIONS.NOZZLES);
  }
}

/**
 * Past Transaction Bill Register - Edit / Delete
 */
export async function updateSaleRecord(saleId: string, updates: Partial<MachineSaleRecord>) {
  try {
    await updateDoc(doc(db, COLLECTIONS.MACHINE_SALES, saleId), updates);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, COLLECTIONS.MACHINE_SALES);
  }
}

export async function deleteSaleRecord(saleId: string) {
  try {
    await deleteDoc(doc(db, COLLECTIONS.MACHINE_SALES, saleId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, COLLECTIONS.MACHINE_SALES);
  }
}

/**
 * Decantation Tanker Receipts
 */
export async function addTankerReceipt(receipt: Omit<TankerReceipt, 'id'>) {
  try {
    // Check Diesel strict guard if unloading to diesel tank
    if (receipt.fuelType === 'HSD') {
      const hsdRef = doc(db, COLLECTIONS.TANKS, 'tank-2-diesel');
      const hsdDoc = await getDocs(collection(db, COLLECTIONS.TANKS));
      const dieselTank = hsdDoc.docs.find((d) => d.id === 'tank-2-diesel')?.data() as Tank | undefined;
      const projected = (dieselTank?.currentStockLitres || 0) + receipt.receivedLitres;
      if (projected > 20000) {
        console.warn(`WARNING: High Speed Diesel Tank projected stock (${projected}L) exceeds 20,000L capacity limit!`);
      }
    }

    const ref = await addDoc(collection(db, COLLECTIONS.TANKER_RECEIPTS), receipt);
    
    // Automatically add decanted stock to tank
    const tankTargetId = receipt.fuelType === 'MS' ? 'tank-1-petrol' : 'tank-2-diesel';
    const targetRef = doc(db, COLLECTIONS.TANKS, tankTargetId);
    await runTransaction(db, async (txn) => {
      const tDoc = await txn.get(targetRef);
      if (tDoc.exists()) {
        const cur = (tDoc.data() as Tank).currentStockLitres || 0;
        const newStock = Number((cur + receipt.receivedLitres).toFixed(2));
        txn.update(targetRef, {
          currentStockLitres: newStock,
          currentDipCm: receipt.postDipCm || tDoc.data().currentDipCm,
          lastUpdated: new Date().toISOString(),
        });
      }
    });

    return ref.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, COLLECTIONS.TANKER_RECEIPTS);
  }
}

/**
 * Daily Dip Record
 */
export async function addDailyDip(dip: Omit<DailyDip, 'id'>) {
  try {
    const ref = await addDoc(collection(db, COLLECTIONS.DAILY_DIPS), dip);
    return ref.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, COLLECTIONS.DAILY_DIPS);
  }
}

/**
 * Cash / Expense Voucher
 */
export async function addVoucher(voucher: Omit<Voucher, 'id'>) {
  try {
    const ref = await addDoc(collection(db, COLLECTIONS.VOUCHERS), voucher);
    return ref.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, COLLECTIONS.VOUCHERS);
  }
}

export async function deleteVoucher(voucherId: string) {
  try {
    await deleteDoc(doc(db, COLLECTIONS.VOUCHERS, voucherId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, COLLECTIONS.VOUCHERS);
  }
}

/**
 * Density Records Subscriber & CRUD
 */
export function subscribeToDensityRecords(callback: (records: DensityRecord[]) => void) {
  const q = query(collection(db, COLLECTIONS.DENSITY_RECORDS), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const records = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<DensityRecord, 'id'>),
      }));
      callback(records);
    },
    (err) => handleFirestoreError(err, OperationType.GET, COLLECTIONS.DENSITY_RECORDS)
  );
}

export async function addDensityRecord(record: Omit<DensityRecord, 'id'>) {
  try {
    const ref = await addDoc(collection(db, COLLECTIONS.DENSITY_RECORDS), record);
    return ref.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, COLLECTIONS.DENSITY_RECORDS);
  }
}

export async function deleteDensityRecord(id: string) {
  try {
    await deleteDoc(doc(db, COLLECTIONS.DENSITY_RECORDS, id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, COLLECTIONS.DENSITY_RECORDS);
  }
}

/**
 * Shift Management
 */
export async function saveShift(shift: Omit<Shift, 'id'>, id?: string) {
  try {
    if (id) {
      await setDoc(doc(db, COLLECTIONS.SHIFTS, id), shift, { merge: true });
      return id;
    } else {
      const ref = await addDoc(collection(db, COLLECTIONS.SHIFTS), shift);
      return ref.id;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, COLLECTIONS.SHIFTS);
  }
}

export async function closeShift(shiftId: string, closingCash: number, totalSales: number) {
  try {
    await updateDoc(doc(db, COLLECTIONS.SHIFTS, shiftId), {
      status: 'CLOSED',
      closingCash,
      totalSales,
      endTime: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, COLLECTIONS.SHIFTS);
  }
}

/**
 * Backup & Masters: Full JSON Database Export & Import
 */
export async function exportAllFirestoreData() {
  const exportData: Record<string, any[]> = {};
  for (const [key, collName] of Object.entries(COLLECTIONS)) {
    try {
      const snap = await getDocs(collection(db, collName));
      exportData[key] = snap.docs.map((d) => ({ _id: d.id, ...d.data() }));
    } catch {
      exportData[key] = [];
    }
  }
  return {
    pumpCode: PUMP_CONFIG.code,
    pumpName: PUMP_CONFIG.name,
    exportedAt: new Date().toISOString(),
    collections: exportData,
  };
}

export async function importFirestoreData(jsonData: any) {
  if (!jsonData?.collections) throw new Error('Invalid backup file format');
  for (const [key, collName] of Object.entries(COLLECTIONS)) {
    const docsToImport = jsonData.collections[key];
    if (Array.isArray(docsToImport)) {
      for (const item of docsToImport) {
        const { _id, ...docData } = item;
        if (_id) {
          await setDoc(doc(db, collName, _id), docData, { merge: true });
        } else {
          await addDoc(collection(db, collName), docData);
        }
      }
    }
  }
}

