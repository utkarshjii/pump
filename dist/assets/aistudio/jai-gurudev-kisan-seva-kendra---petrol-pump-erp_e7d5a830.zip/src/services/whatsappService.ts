import { Customer } from '../types/pump';
import { PUMP_CONFIG } from '../constants/pumpConfig';

export interface ReminderPayload {
  customerId: string;
  customerName: string;
  phone: string;
  balance: number;
  message: string;
  whatsappUrl: string;
  smsUrl: string;
}

/**
 * Generate formatted WhatsApp reminder message with station name and pump code
 */
export function generateReminderMessage(customer: Customer, language: 'HINDI' | 'PUNJABI' | 'ENGLISH' = 'HINDI'): string {
  const formattedBalance = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(customer.currentBalance);

  const dateStr = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  if (language === 'HINDI') {
    return `🙏 *श्री ${customer.name} जी,*
सादर प्रणाम।

यह *${PUMP_CONFIG.name}* (पंप कोड: *${PUMP_CONFIG.code}*) की तरफ से आपके खाता (Khata) का बकाया विवरण है:

📌 *कुल बकाया राशि:* *${formattedBalance}*
📅 *दिनांक:* ${dateStr}
⛽ *स्थान:* ${PUMP_CONFIG.location}

कृपया अपनी सुविधानुसार समय पर भुगतान करने की कृपा करें।
भुगतान हेतु UPI / Bank Transfer या काउंटर पर संपर्क करें।

*प्रबंधन:*
मालिक: ${PUMP_CONFIG.owner}
मैनेजर: ${PUMP_CONFIG.manager} (संपर्क: 9876543211)
धन्यवाद!`;
  }

  if (language === 'PUNJABI') {
    return `🙏 *ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ਜੀ ${customer.name},*

ਇਹ *${PUMP_CONFIG.name}* (ਪੰਪ ਕੋਡ: *${PUMP_CONFIG.code}*) ਵੱਲੋਂ ਤੁਹਾਡੇ ਖਾਤੇ ਦੇ ਬਕਾਏ ਦੀ ਸੂਚਨਾ ਹੈ:

📌 *ਕੁੱਲ ਬਕਾਇਆ ਰਕਮ:* *${formattedBalance}*
📅 *ਮਿਤੀ:* ${dateStr}

ਕਿਰਪਾ ਕਰਕੇ ਸਮੇਂ ਸਿਰ ਭੁਗਤਾਨ ਕਰਕੇ ਸਹਿਯੋਗ ਦਿਓ ਜੀ।

*ਪ੍ਰਬੰਧਕ:*
ਮਾਲਕ: ${PUMP_CONFIG.owner}
ਮੈਨੇਜਰ: ${PUMP_CONFIG.manager}
ਧੰਨਵਾਦ!`;
  }

  // ENGLISH
  return `Dear *${customer.name}*,

Greetings from *${PUMP_CONFIG.name}* (Pump Code: *${PUMP_CONFIG.code}*).

This is a gentle reminder regarding your outstanding credit ledger balance:
📌 *Total Amount Due:* *${formattedBalance}*
📅 *As of:* ${dateStr}

Kindly clear the balance at your earliest convenience via Cash / UPI or at our station counter.

*Contact:*
Owner: ${PUMP_CONFIG.owner}
Manager: ${PUMP_CONFIG.manager}
Thank you for your valued patronage!`;
}

/**
 * Generate click-to-chat WhatsApp link
 */
export function getWhatsAppDirectLink(phone: string, message: string): string {
  // Normalize 10-digit Indian phone
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const fullPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
  const encodedText = encodeURIComponent(message);
  return `https://wa.me/${fullPhone}?text=${encodedText}`;
}

/**
 * Generate SMS link (works across mobile OS)
 */
export function getSmsDirectLink(phone: string, message: string): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  return `sms:${cleanPhone}?body=${encodeURIComponent(message)}`;
}

/**
 * Trigger batch automated reminders via backend API or webhook
 */
export async function triggerDailyAutomatedReminders(customersWithDue: Customer[]) {
  const items: ReminderPayload[] = customersWithDue.map((cust) => {
    const message = generateReminderMessage(cust, 'HINDI');
    return {
      customerId: cust.id,
      customerName: cust.name,
      phone: cust.phone,
      balance: cust.currentBalance,
      message,
      whatsappUrl: getWhatsAppDirectLink(cust.phone, message),
      smsUrl: getSmsDirectLink(cust.phone, message),
    };
  });

  try {
    // Attempt webhook or backend dispatch
    const response = await fetch('/api/reminders/send-daily', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        station: PUMP_CONFIG.name,
        pumpCode: PUMP_CONFIG.code,
        scheduledSlot: '09:00 AM IST',
        recipients: items,
      }),
    });

    if (response.ok) {
      return { success: true, count: items.length, serverDispatched: true };
    }
  } catch {
    // Graceful fallback for client-side direct WhatsApp automation
  }

  return { success: true, count: items.length, serverDispatched: false, items };
}
