export type UserRole = 'OWNER' | 'MANAGER' | 'SALESMAN';

export interface Staff {
  id: string;
  name: string;
  role: UserRole;
  phone: string;
  pin: string;
  active: boolean;
  createdAt?: string;
}

export type FuelType = 'MS' | 'HSD'; // MS = Petrol, HSD = High Speed Diesel

export interface DispenserMachine {
  id: 'tokheim-du1' | 'midco-du2';
  name: string;
  bay: string;
  model: 'Tokheim' | 'Midco';
  code: string;
  nozzles: {
    msNozzleId: string;
    msNozzleNumber: number;
    hsdNozzleId: string;
    hsdNozzleNumber: number;
  };
}

export interface MachineSaleRecord {
  id?: string;
  machineId: 'tokheim-du1' | 'midco-du2';
  machineName: string;
  date: string;
  shiftId: string;
  salesmanId: string;
  salesmanName: string;
  entryMode: 'meter' | 'direct';
  
  // Petrol (MS)
  petrolOpening: number;
  petrolClosing: number;
  petrolTesting: number; // 5L weights & measures deduction
  petrolLitres: number;
  petrolRate: number;
  petrolAmount: number;

  // Diesel (HSD)
  dieselOpening: number;
  dieselClosing: number;
  dieselTesting: number; // 5L weights & measures deduction
  dieselLitres: number;
  dieselRate: number;
  dieselAmount: number;

  // Lubricants
  lubeAmount: number;
  lubeDetails: {
    productId: string;
    productName: string;
    quantity: number;
    rate: number;
    amount: number;
  }[];

  // Grand Total & Smart Plus-Minus Payment Deduction
  grossTotal: number;
  cashAmount: number;
  upiAmount: number;
  posAmount: number;
  creditAmount: number;

  // Khata Customer link if credit > 0
  customerId?: string;
  customerName?: string;
  customerPhone?: string;
  vehicleNo?: string;
  slipNo?: string;

  notes?: string;
  createdAt: string;
}

export interface Tank {
  id: string;
  tankNumber: number;
  fuelType: FuelType;
  fuelName: string;
  capacityLitres: number; // Max 20,000L strict guard for Diesel
  currentStockLitres: number;
  currentDipCm: number;
  lastUpdated: string;
}

export interface Nozzle {
  id: string;
  nozzleNumber: number;
  machineId: string;
  machineName: string;
  fuelType: FuelType;
  lastTotalizer: number;
  calibrationDate: string;
  status: 'ACTIVE' | 'CALIBRATION' | 'INACTIVE';
}

export interface Product {
  id: string;
  name: string;
  category: 'FUEL' | 'LUBRICANT';
  fuelType?: FuelType;
  price: number;
  unit: string;
  stockQuantity: number;
  minStockAlert: number;
}

export interface Shift {
  id: string;
  shiftName: string; // e.g. 'Day Shift (06:00 - 18:00)', 'Night Shift (18:00 - 06:00)'
  date: string;
  cashierId: string;
  cashierName: string;
  status: 'OPEN' | 'CLOSED';
  openingCash: number;
  closingCash?: number;
  startTime: string;
  endTime?: string;
  totalSales?: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  vehicleNumbers: string; // Comma-separated
  creditLimit: number;
  currentBalance: number;
  address?: string;
  status: 'ACTIVE' | 'BLOCKED';
  lastPaymentDate?: string;
  createdAt: string;
}

export type LedgerEntryType = 'CREDIT_SALE' | 'PAYMENT_RECEIVED' | 'ADJUSTMENT';

export interface CustomerLedgerEntry {
  id?: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  type: LedgerEntryType;
  amount: number;
  balanceAfter: number;
  date: string;
  fuelType?: string;
  litres?: number;
  vehicleNo?: string;
  slipNo?: string;
  notes?: string;
  paymentMode?: 'CASH' | 'UPI' | 'CHEQUE' | 'BANK_TRANSFER';
  recordedBy: string;
  createdAt: string;
}

export interface TankerReceipt {
  id?: string;
  date: string;
  invoiceNo: string;
  tankerNo: string;
  company: 'IOCL' | 'BPCL' | 'HPCL' | 'OTHER';
  fuelType: FuelType;
  tankId: string;
  invoiceLitres: number;
  preDipCm: number;
  postDipCm: number;
  receivedLitres: number;
  density15C: number;
  waterTestResult: 'NEGATIVE' | 'POSITIVE';
  receivedBy: string;
  notes?: string;
  createdAt: string;
}

export interface DailyDip {
  id?: string;
  date: string;
  timeSlot: 'MORNING' | 'EVENING';
  tankNumber: number;
  fuelType: FuelType;
  dipCm: number;
  physicalLitres: number;
  bookStockLitres: number;
  varianceLitres: number; // physical - book
  auditedBy: string;
  createdAt: string;
}

export interface Voucher {
  id?: string;
  voucherNumber: string;
  date: string;
  type: 'EXPENSE' | 'BANK_DEPOSIT' | 'SALARY' | 'OTHER';
  title: string;
  amount: number;
  paidTo: string;
  authorizedBy: string;
  notes?: string;
  createdAt: string;
}

export interface WhatsAppReminderQueue {
  id?: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  balance: number;
  scheduledTime: string;
  status: 'QUEUED' | 'SENT' | 'FAILED';
  sentAt?: string;
  messageText: string;
}

export interface DensityRecord {
  id?: string;
  date: string;
  timeSlot: 'MORNING' | 'EVENING';
  fuelType: FuelType;
  tankNumber: number;
  observedDensity: number; // kg/m³
  temperatureC: number;    // °C
  convertedDensity15C: number; // Converted to 15°C using ASTM-53B table
  invoiceDensity: number;  // From OMC tanker invoice
  variation: number;       // Must be within ±3.0 kg/m³
  waterPasteTest: 'NEGATIVE' | 'POSITIVE';
  testedBy: string;
  remarks?: string;
  createdAt: string;
}

export interface ShiftAssignment {
  id?: string;
  shiftId: string;
  salesmanId: string;
  salesmanName: string;
  machineId: 'tokheim-du1' | 'midco-du2';
  assignedNozzles: string[];
  startingCashFloat: number;
  closingCashCollected: number;
  totalLitresSold: number;
  totalAmountSold: number;
  status: 'ACTIVE' | 'SETTLED';
}

