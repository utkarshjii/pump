import { Handler, HandlerEvent, HandlerContext, schedule } from '@netlify/functions';

/**
 * Netlify Scheduled Serverless Function
 * Runs daily at 09:00 AM IST (which is 03:30 AM UTC: cron '30 3 * * *')
 * Dispatches automated Khata balance credit due reminders for
 * "Jai Gurudev Kisan Seva Kendra" (Pump Code: 331047).
 */
const dailyReminderHandler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  console.log('⏰ Triggering 09:00 AM IST Automated Khata Credit Reminder Cron');
  console.log('Station: Jai Gurudev Kisan Seva Kendra | Pump Code: 331047');

  try {
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        station: 'Jai Gurudev Kisan Seva Kendra',
        pumpCode: '331047',
        scheduledSlot: '09:00 AM IST',
        timestamp: new Date().toISOString(),
        message: 'Daily credit due reminders dispatched successfully.',
      }),
    };
  } catch (error: any) {
    console.error('Error dispatching automated reminders:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};

// Netlify scheduled cron expression for 03:30 UTC = 09:00 IST
export const handler = schedule('30 3 * * *', dailyReminderHandler);
